?��prompt PL/SQL Developer Export Tables for user SYSTEM
prompt Created by Evyatar on יום שני 10 אוגוסט 2020
set feedback off
set define off

prompt Creating WORKER_TEMP_B...
create table WORKER_TEMP_B
(
  workerid         NUMBER(9),
  workername       VARCHAR2(50),
  birthdate        DATE,
  itsboss_workerid NUMBER(9),
  startdate        DATE,
  enddate          DATE,
  type             INTEGER,
  citizenid        INTEGER,
  salary           FLOAT
)
tablespace SYSTEM
  pctfree 10
  pctused 40
  initrans 1
  maxtrans 255
  storage
  (
    initial 64K
    next 1M
    minextents 1
    maxextents unlimited
  );

prompt Disabling triggers for WORKER_TEMP_B...
alter table WORKER_TEMP_B disable all triggers;
prompt Deleting WORKER_TEMP_B...
delete from WORKER_TEMP_B;
prompt Loading WORKER_TEMP_B...
insert into WORKER_TEMP_B (workerid, workername, birthdate, itsboss_workerid, startdate, enddate, type, citizenid, salary)
values (531238815, 'Diamond Olson', to_date('20-01-2000', 'dd-mm-yyyy'), 531238815, to_date('02-11-2014', 'dd-mm-yyyy'), to_date('21-10-2034', 'dd-mm-yyyy'), 2, 708262840, 7193.7596372454696051453084116320744309);
insert into WORKER_TEMP_B (workerid, workername, birthdate, itsboss_workerid, startdate, enddate, type, citizenid, salary)
values (648956315, 'Maritza Marks', to_date('25-08-1957', 'dd-mm-yyyy'), 648956315, to_date('01-03-1990', 'dd-mm-yyyy'), to_date('20-09-2031', 'dd-mm-yyyy'), 2, 189811489, 4547.2499370067526057095599731283344926);
insert into WORKER_TEMP_B (workerid, workername, birthdate, itsboss_workerid, startdate, enddate, type, citizenid, salary)
values (71932811, 'Kennedy Chen', to_date('09-09-1992', 'dd-mm-yyyy'), 71932811, to_date('16-01-1986', 'dd-mm-yyyy'), to_date('16-06-2027', 'dd-mm-yyyy'), 2, 467351472, 12245.820781237282969721313479352891147);
insert into WORKER_TEMP_B (workerid, workername, birthdate, itsboss_workerid, startdate, enddate, type, citizenid, salary)
values (311466467, 'Anthony Davila', to_date('16-05-1976', 'dd-mm-yyyy'), 311466467, to_date('06-07-1991', 'dd-mm-yyyy'), to_date('11-03-2032', 'dd-mm-yyyy'), 1, 152874477, 10123.104432592657786518412647065175376);
insert into WORKER_TEMP_B (workerid, workername, birthdate, itsboss_workerid, startdate, enddate, type, citizenid, salary)
values (214019947, 'Payton Sloan', to_date('02-01-1989', 'dd-mm-yyyy'), 214019947, to_date('14-03-2005', 'dd-mm-yyyy'), to_date('28-08-2039', 'dd-mm-yyyy'), 2, 590564086, 18989.055674760710289403734265547087453);
insert into WORKER_TEMP_B (workerid, workername, birthdate, itsboss_workerid, startdate, enddate, type, citizenid, salary)
values (655611592, 'Jeramiah Yu', to_date('22-08-1971', 'dd-mm-yyyy'), 655611592, to_date('22-09-2000', 'dd-mm-yyyy'), to_date('17-11-2029', 'dd-mm-yyyy'), 2, 945582077, 39596.085480982379762273500702525719362);
insert into WORKER_TEMP_B (workerid, workername, birthdate, itsboss_workerid, startdate, enddate, type, citizenid, salary)
values (267895569, 'Gloria Hoffman', to_date('22-08-1979', 'dd-mm-yyyy'), 267895569, to_date('25-08-2015', 'dd-mm-yyyy'), to_date('29-12-2038', 'dd-mm-yyyy'), 2, 79504732, 6487.4317804515096351504438521999174571);
insert into WORKER_TEMP_B (workerid, workername, birthdate, itsboss_workerid, startdate, enddate, type, citizenid, salary)
values (475822438, 'Abel Hansen', to_date('03-06-1960', 'dd-mm-yyyy'), 475822438, to_date('29-10-2014', 'dd-mm-yyyy'), to_date('03-03-2039', 'dd-mm-yyyy'), 2, 780946586, 18051.505999537516462217637124448039488);
insert into WORKER_TEMP_B (workerid, workername, birthdate, itsboss_workerid, startdate, enddate, type, citizenid, salary)
values (608832283, 'Amiya Drake', to_date('02-09-1964', 'dd-mm-yyyy'), 608832283, to_date('10-08-1991', 'dd-mm-yyyy'), to_date('30-08-2035', 'dd-mm-yyyy'), 2, 375972455, 10593.470807684383769414882934596318601);
insert into WORKER_TEMP_B (workerid, workername, birthdate, itsboss_workerid, startdate, enddate, type, citizenid, salary)
values (871947790, 'Anna Velez', to_date('31-01-1971', 'dd-mm-yyyy'), 871947790, to_date('21-09-2013', 'dd-mm-yyyy'), to_date('29-11-2022', 'dd-mm-yyyy'), 1, 971633137, 21502.634339758894989629511816286735318);
insert into WORKER_TEMP_B (workerid, workername, birthdate, itsboss_workerid, startdate, enddate, type, citizenid, salary)
values (156552498, 'Iyana Meza', to_date('16-10-1977', 'dd-mm-yyyy'), 871947790, to_date('26-02-1994', 'dd-mm-yyyy'), to_date('19-11-2034', 'dd-mm-yyyy'), 1, 202710130, 22521.800095756694693993672391109579987);
insert into WORKER_TEMP_B (workerid, workername, birthdate, itsboss_workerid, startdate, enddate, type, citizenid, salary)
values (154508569, 'Johnathon Barnes', to_date('07-06-1964', 'dd-mm-yyyy'), 531238815, to_date('02-09-2004', 'dd-mm-yyyy'), to_date('21-10-2040', 'dd-mm-yyyy'), 1, 936814527, 18683.09838010407941803621799340611937);
insert into WORKER_TEMP_B (workerid, workername, birthdate, itsboss_workerid, startdate, enddate, type, citizenid, salary)
values (918926951, 'Shaniya Dominguez', to_date('04-06-1987', 'dd-mm-yyyy'), 531238815, to_date('19-08-1990', 'dd-mm-yyyy'), to_date('12-08-2026', 'dd-mm-yyyy'), 1, 618144212, 5527.2472532013900638231638276644546918);
insert into WORKER_TEMP_B (workerid, workername, birthdate, itsboss_workerid, startdate, enddate, type, citizenid, salary)
values (867688554, 'Bentley Hunter', to_date('28-12-1956', 'dd-mm-yyyy'), 648956315, to_date('30-11-2001', 'dd-mm-yyyy'), to_date('30-07-2040', 'dd-mm-yyyy'), 1, 330927664, 12411.57154890866186247814953667192144);
insert into WORKER_TEMP_B (workerid, workername, birthdate, itsboss_workerid, startdate, enddate, type, citizenid, salary)
values (684228936, 'Madyson Bradley', to_date('30-01-1969', 'dd-mm-yyyy'), 648956315, to_date('08-03-1995', 'dd-mm-yyyy'), to_date('20-12-2035', 'dd-mm-yyyy'), 1, 850965499, 31812.115212824405256295674188405513522);
insert into WORKER_TEMP_B (workerid, workername, birthdate, itsboss_workerid, startdate, enddate, type, citizenid, salary)
values (518625103, 'Aiyana Hahn', to_date('10-06-1961', 'dd-mm-yyyy'), 71932811, to_date('03-09-2008', 'dd-mm-yyyy'), to_date('02-08-2021', 'dd-mm-yyyy'), 2, 121670810, 34166.357218549151365650857644184895062);
insert into WORKER_TEMP_B (workerid, workername, birthdate, itsboss_workerid, startdate, enddate, type, citizenid, salary)
values (950758028, 'Zechariah Moran', to_date('30-11-1983', 'dd-mm-yyyy'), 71932811, to_date('23-07-1980', 'dd-mm-yyyy'), to_date('07-06-2038', 'dd-mm-yyyy'), 1, 591829232, 19755.506494434295094752658067931273738);
insert into WORKER_TEMP_B (workerid, workername, birthdate, itsboss_workerid, startdate, enddate, type, citizenid, salary)
values (520553314, 'Eliza Smith', to_date('18-06-1963', 'dd-mm-yyyy'), 311466467, to_date('23-07-2013', 'dd-mm-yyyy'), to_date('18-06-2027', 'dd-mm-yyyy'), 2, 523479830, 4631.4718721260296535829916726909260256);
insert into WORKER_TEMP_B (workerid, workername, birthdate, itsboss_workerid, startdate, enddate, type, citizenid, salary)
values (505111071, 'Janae Nicholson', to_date('27-03-1996', 'dd-mm-yyyy'), 311466467, to_date('07-08-2019', 'dd-mm-yyyy'), to_date('05-03-2027', 'dd-mm-yyyy'), 2, 972999281, 6023.0450664950185299579002100587358276);
insert into WORKER_TEMP_B (workerid, workername, birthdate, itsboss_workerid, startdate, enddate, type, citizenid, salary)
values (65914345, 'Sarahi Wagner', to_date('22-05-1961', 'dd-mm-yyyy'), 214019947, to_date('30-05-2009', 'dd-mm-yyyy'), to_date('18-12-2020', 'dd-mm-yyyy'), 2, 869593414, 3847.8553990739666741264802027573271985);
insert into WORKER_TEMP_B (workerid, workername, birthdate, itsboss_workerid, startdate, enddate, type, citizenid, salary)
values (102975751, 'Fatima Livingston', to_date('30-04-1985', 'dd-mm-yyyy'), 214019947, to_date('01-06-2006', 'dd-mm-yyyy'), to_date('27-01-2024', 'dd-mm-yyyy'), 1, 364323076, 24579.483214587329792050768892866422153);
insert into WORKER_TEMP_B (workerid, workername, birthdate, itsboss_workerid, startdate, enddate, type, citizenid, salary)
values (97370635, 'Ashleigh Winters', to_date('08-12-1989', 'dd-mm-yyyy'), 655611592, to_date('14-03-1994', 'dd-mm-yyyy'), to_date('28-11-2032', 'dd-mm-yyyy'), 1, 456295284, 12236.758972410173226705988615457270453);
insert into WORKER_TEMP_B (workerid, workername, birthdate, itsboss_workerid, startdate, enddate, type, citizenid, salary)
values (157985841, 'Clayton Shah', to_date('25-07-1997', 'dd-mm-yyyy'), 655611592, to_date('23-02-2002', 'dd-mm-yyyy'), to_date('18-05-2034', 'dd-mm-yyyy'), 1, 486877093, 21747.900785242351748545850008377907998);
insert into WORKER_TEMP_B (workerid, workername, birthdate, itsboss_workerid, startdate, enddate, type, citizenid, salary)
values (702948713, 'Emilia Bautista', to_date('20-02-1963', 'dd-mm-yyyy'), 267895569, to_date('04-03-2014', 'dd-mm-yyyy'), to_date('03-02-2022', 'dd-mm-yyyy'), 2, 850636732, 39621.889320670332161947782704975355249);
insert into WORKER_TEMP_B (workerid, workername, birthdate, itsboss_workerid, startdate, enddate, type, citizenid, salary)
values (167848962, 'Martin Hodges', to_date('31-08-1973', 'dd-mm-yyyy'), 267895569, to_date('22-01-1988', 'dd-mm-yyyy'), to_date('28-10-2026', 'dd-mm-yyyy'), 1, 670150291, 14348.126072820369877648575241527349857);
insert into WORKER_TEMP_B (workerid, workername, birthdate, itsboss_workerid, startdate, enddate, type, citizenid, salary)
values (477713169, 'Carlie Avery', to_date('12-12-1989', 'dd-mm-yyyy'), 475822438, to_date('09-12-1983', 'dd-mm-yyyy'), to_date('22-09-2025', 'dd-mm-yyyy'), 1, 345108322, 12781.213320782928144818265584354158782);
insert into WORKER_TEMP_B (workerid, workername, birthdate, itsboss_workerid, startdate, enddate, type, citizenid, salary)
values (475432614, 'Mayra Mcgee', to_date('11-04-1985', 'dd-mm-yyyy'), 475822438, to_date('10-12-1985', 'dd-mm-yyyy'), to_date('02-12-2035', 'dd-mm-yyyy'), 1, 49629406, 36955.290758696916432087768881494026537);
insert into WORKER_TEMP_B (workerid, workername, birthdate, itsboss_workerid, startdate, enddate, type, citizenid, salary)
values (960371044, 'Messiah Mercer', to_date('12-09-1956', 'dd-mm-yyyy'), 608832283, to_date('21-03-2017', 'dd-mm-yyyy'), to_date('03-01-2027', 'dd-mm-yyyy'), 1, 482818846, 14830.125203834257539303072854687949088);
insert into WORKER_TEMP_B (workerid, workername, birthdate, itsboss_workerid, startdate, enddate, type, citizenid, salary)
values (125805491, 'Libby Brady', to_date('18-01-2000', 'dd-mm-yyyy'), 871947790, to_date('07-01-1986', 'dd-mm-yyyy'), to_date('11-11-2040', 'dd-mm-yyyy'), 1, 385892708, 6460.6917386018365141892021229344162595);
insert into WORKER_TEMP_B (workerid, workername, birthdate, itsboss_workerid, startdate, enddate, type, citizenid, salary)
values (882503173, 'Reynaldo Lucero', to_date('27-06-1961', 'dd-mm-yyyy'), 871947790, to_date('05-07-2016', 'dd-mm-yyyy'), to_date('28-10-2021', 'dd-mm-yyyy'), 2, 113899307, 12728.015897118626541714532106451552137);
insert into WORKER_TEMP_B (workerid, workername, birthdate, itsboss_workerid, startdate, enddate, type, citizenid, salary)
values (90523324, 'Rowan Walters', to_date('15-04-1952', 'dd-mm-yyyy'), 531238815, to_date('12-09-2010', 'dd-mm-yyyy'), to_date('31-10-2022', 'dd-mm-yyyy'), 1, 19214993, 18261.812510769191954938105957862318251);
insert into WORKER_TEMP_B (workerid, workername, birthdate, itsboss_workerid, startdate, enddate, type, citizenid, salary)
values (62842027, 'Rohan Patel', to_date('19-03-1993', 'dd-mm-yyyy'), 531238815, to_date('07-06-2010', 'dd-mm-yyyy'), to_date('17-05-2036', 'dd-mm-yyyy'), 2, 640808719, 10434.454257578915755385362224099575086);
insert into WORKER_TEMP_B (workerid, workername, birthdate, itsboss_workerid, startdate, enddate, type, citizenid, salary)
values (85099344, 'Paxton Rogers', to_date('14-04-1982', 'dd-mm-yyyy'), 648956315, to_date('24-01-2008', 'dd-mm-yyyy'), to_date('31-03-2035', 'dd-mm-yyyy'), 2, 464600526, 9853.403967293084590582143920445108082);
insert into WORKER_TEMP_B (workerid, workername, birthdate, itsboss_workerid, startdate, enddate, type, citizenid, salary)
values (585949230, 'Alexis Bean', to_date('03-02-1958', 'dd-mm-yyyy'), 648956315, to_date('18-01-1984', 'dd-mm-yyyy'), to_date('24-03-2029', 'dd-mm-yyyy'), 1, 191386480, 7714.7260423594859552218516347632124306);
insert into WORKER_TEMP_B (workerid, workername, birthdate, itsboss_workerid, startdate, enddate, type, citizenid, salary)
values (663022089, 'Tiara Wilkinson', to_date('04-03-1987', 'dd-mm-yyyy'), 71932811, to_date('09-05-2005', 'dd-mm-yyyy'), to_date('04-11-2032', 'dd-mm-yyyy'), 1, 287878005, 39167.889428843641046185937952811934385);
insert into WORKER_TEMP_B (workerid, workername, birthdate, itsboss_workerid, startdate, enddate, type, citizenid, salary)
values (138808687, 'Taniya Best', to_date('24-08-1965', 'dd-mm-yyyy'), 71932811, to_date('15-03-1994', 'dd-mm-yyyy'), to_date('28-09-2027', 'dd-mm-yyyy'), 1, 754030724, 31129.151891849221022929140965258406548);
insert into WORKER_TEMP_B (workerid, workername, birthdate, itsboss_workerid, startdate, enddate, type, citizenid, salary)
values (115866959, 'Kristian Perkins', to_date('18-05-1989', 'dd-mm-yyyy'), 311466467, to_date('03-07-2010', 'dd-mm-yyyy'), to_date('19-05-2025', 'dd-mm-yyyy'), 1, 698473099, 15588.741084621821838545872266386900386);
insert into WORKER_TEMP_B (workerid, workername, birthdate, itsboss_workerid, startdate, enddate, type, citizenid, salary)
values (67162927, 'Daniella Ballard', to_date('24-12-1984', 'dd-mm-yyyy'), 311466467, to_date('31-01-1991', 'dd-mm-yyyy'), to_date('29-04-2036', 'dd-mm-yyyy'), 1, 111413768, 33188.263086764325995175719588662869881);
insert into WORKER_TEMP_B (workerid, workername, birthdate, itsboss_workerid, startdate, enddate, type, citizenid, salary)
values (726182643, 'Bridger Nicholson', to_date('19-11-1985', 'dd-mm-yyyy'), 214019947, to_date('24-06-2001', 'dd-mm-yyyy'), to_date('22-11-2026', 'dd-mm-yyyy'), 1, 671660675, 32517.830645086015711877284143543331748);
insert into WORKER_TEMP_B (workerid, workername, birthdate, itsboss_workerid, startdate, enddate, type, citizenid, salary)
values (867117574, 'Tanner Velazquez', to_date('16-07-1966', 'dd-mm-yyyy'), 214019947, to_date('19-07-2014', 'dd-mm-yyyy'), to_date('18-04-2028', 'dd-mm-yyyy'), 1, 892580017, 17376.763206248971829201311658047671638);
insert into WORKER_TEMP_B (workerid, workername, birthdate, itsboss_workerid, startdate, enddate, type, citizenid, salary)
values (468320988, 'Kadyn Parker', to_date('18-02-1984', 'dd-mm-yyyy'), 655611592, to_date('17-03-2007', 'dd-mm-yyyy'), to_date('26-05-2028', 'dd-mm-yyyy'), 1, 903626083, 11676.340616349901055793545222959078207);
insert into WORKER_TEMP_B (workerid, workername, birthdate, itsboss_workerid, startdate, enddate, type, citizenid, salary)
values (845532748, 'Ernesto Crane', to_date('21-10-1962', 'dd-mm-yyyy'), 655611592, to_date('19-02-1992', 'dd-mm-yyyy'), to_date('19-09-2022', 'dd-mm-yyyy'), 1, 620937216, 21739.588129962336816369746995687492643);
insert into WORKER_TEMP_B (workerid, workername, birthdate, itsboss_workerid, startdate, enddate, type, citizenid, salary)
values (979100171, 'Alma Benson', to_date('16-07-1986', 'dd-mm-yyyy'), 267895569, to_date('10-09-2014', 'dd-mm-yyyy'), to_date('07-11-2020', 'dd-mm-yyyy'), 1, 908000615, 27679.506123549729835394206571691660808);
insert into WORKER_TEMP_B (workerid, workername, birthdate, itsboss_workerid, startdate, enddate, type, citizenid, salary)
values (202306184, 'Marie Barton', to_date('20-09-1961', 'dd-mm-yyyy'), 267895569, to_date('19-04-2009', 'dd-mm-yyyy'), to_date('26-12-2036', 'dd-mm-yyyy'), 2, 724134639, 20960.752650473838233188729706028847661);
insert into WORKER_TEMP_B (workerid, workername, birthdate, itsboss_workerid, startdate, enddate, type, citizenid, salary)
values (660108450, 'Lilyana Lamb', to_date('06-07-1999', 'dd-mm-yyyy'), 475822438, to_date('01-10-1990', 'dd-mm-yyyy'), to_date('17-01-2037', 'dd-mm-yyyy'), 2, 985907107, 26600.397393218656988940044750147364545);
insert into WORKER_TEMP_B (workerid, workername, birthdate, itsboss_workerid, startdate, enddate, type, citizenid, salary)
values (481022444, 'Lewis Stewart', to_date('06-06-1983', 'dd-mm-yyyy'), 475822438, to_date('24-11-1982', 'dd-mm-yyyy'), to_date('06-07-2033', 'dd-mm-yyyy'), 1, 726919780, 7238.2208864002012034252513399468941752);
insert into WORKER_TEMP_B (workerid, workername, birthdate, itsboss_workerid, startdate, enddate, type, citizenid, salary)
values (41216358, 'Alonso Washington', to_date('28-11-1994', 'dd-mm-yyyy'), 608832283, to_date('16-06-2019', 'dd-mm-yyyy'), to_date('27-10-2020', 'dd-mm-yyyy'), 1, 412079807, 22651.43973872660246913438829773307608);
insert into WORKER_TEMP_B (workerid, workername, birthdate, itsboss_workerid, startdate, enddate, type, citizenid, salary)
values (325294143, 'Aiyana Russo', to_date('18-09-1991', 'dd-mm-yyyy'), 608832283, to_date('11-03-2018', 'dd-mm-yyyy'), to_date('12-01-2037', 'dd-mm-yyyy'), 1, 709915279, 19694.658117820459809147561947362397598);
insert into WORKER_TEMP_B (workerid, workername, birthdate, itsboss_workerid, startdate, enddate, type, citizenid, salary)
values (803833678, 'Jaylon Mills', to_date('02-05-1971', 'dd-mm-yyyy'), 871947790, to_date('20-12-2016', 'dd-mm-yyyy'), to_date('30-08-2026', 'dd-mm-yyyy'), 2, 434940113, 23181.265674227473594426017095445360792);
insert into WORKER_TEMP_B (workerid, workername, birthdate, itsboss_workerid, startdate, enddate, type, citizenid, salary)
values (608473425, 'Drew Love', to_date('12-01-1966', 'dd-mm-yyyy'), 871947790, to_date('26-06-1995', 'dd-mm-yyyy'), to_date('20-05-2021', 'dd-mm-yyyy'), 2, 291741163, 12165.918119916798176692095577910680859);
insert into WORKER_TEMP_B (workerid, workername, birthdate, itsboss_workerid, startdate, enddate, type, citizenid, salary)
values (109416098, 'Denisse Ball', to_date('10-07-1982', 'dd-mm-yyyy'), 531238815, to_date('17-12-2018', 'dd-mm-yyyy'), to_date('30-01-2039', 'dd-mm-yyyy'), 1, 426148194, 16681.405509343493785367082629876807);
insert into WORKER_TEMP_B (workerid, workername, birthdate, itsboss_workerid, startdate, enddate, type, citizenid, salary)
values (881549786, 'Lia Michael', to_date('14-04-1973', 'dd-mm-yyyy'), 531238815, to_date('29-10-2008', 'dd-mm-yyyy'), to_date('26-01-2030', 'dd-mm-yyyy'), 2, 64526097, 33353.797024546135018522627723471387936);
insert into WORKER_TEMP_B (workerid, workername, birthdate, itsboss_workerid, startdate, enddate, type, citizenid, salary)
values (869554266, 'Esteban Frederick', to_date('11-09-1990', 'dd-mm-yyyy'), 648956315, to_date('05-12-2006', 'dd-mm-yyyy'), to_date('13-05-2028', 'dd-mm-yyyy'), 2, 603338542, 36653.010788535970377331561897593965882);
insert into WORKER_TEMP_B (workerid, workername, birthdate, itsboss_workerid, startdate, enddate, type, citizenid, salary)
values (325939163, 'Addyson Farley', to_date('16-11-1961', 'dd-mm-yyyy'), 648956315, to_date('04-04-1998', 'dd-mm-yyyy'), to_date('26-03-2030', 'dd-mm-yyyy'), 2, 784600813, 9134.3423898980260701787097975103273226);
insert into WORKER_TEMP_B (workerid, workername, birthdate, itsboss_workerid, startdate, enddate, type, citizenid, salary)
values (599701445, 'Peyton Griffith', to_date('22-10-1951', 'dd-mm-yyyy'), 71932811, to_date('25-11-1982', 'dd-mm-yyyy'), to_date('17-08-2020', 'dd-mm-yyyy'), 2, 70822249, 18541.885710065839482793883653159424288);
insert into WORKER_TEMP_B (workerid, workername, birthdate, itsboss_workerid, startdate, enddate, type, citizenid, salary)
values (720256910, 'Ronan Holmes', to_date('23-02-1956', 'dd-mm-yyyy'), 71932811, to_date('06-02-1994', 'dd-mm-yyyy'), to_date('11-06-2037', 'dd-mm-yyyy'), 2, 70831716, 14328.463257789680750527825557482493274);
insert into WORKER_TEMP_B (workerid, workername, birthdate, itsboss_workerid, startdate, enddate, type, citizenid, salary)
values (42734252, 'Heidy Cruz', to_date('15-03-1986', 'dd-mm-yyyy'), 311466467, to_date('27-12-1991', 'dd-mm-yyyy'), to_date('18-05-2022', 'dd-mm-yyyy'), 2, 751988735, 9201.1115399341994018090823608469176845);
insert into WORKER_TEMP_B (workerid, workername, birthdate, itsboss_workerid, startdate, enddate, type, citizenid, salary)
values (371691541, 'Miracle Gould', to_date('30-11-1984', 'dd-mm-yyyy'), 311466467, to_date('20-12-2019', 'dd-mm-yyyy'), to_date('27-06-2035', 'dd-mm-yyyy'), 1, 365963339, 37217.522537981871169600617740971584758);
insert into WORKER_TEMP_B (workerid, workername, birthdate, itsboss_workerid, startdate, enddate, type, citizenid, salary)
values (42464775, 'Gunnar Barr', to_date('09-06-1997', 'dd-mm-yyyy'), 214019947, to_date('03-06-2002', 'dd-mm-yyyy'), to_date('30-08-2025', 'dd-mm-yyyy'), 2, 648911084, 30819.180878594967828706807120235036541);
insert into WORKER_TEMP_B (workerid, workername, birthdate, itsboss_workerid, startdate, enddate, type, citizenid, salary)
values (212036071, 'Chana Meadows', to_date('18-01-1959', 'dd-mm-yyyy'), 214019947, to_date('30-09-2006', 'dd-mm-yyyy'), to_date('29-09-2029', 'dd-mm-yyyy'), 1, 185000152, 6056.7772195842162764627028254601356215);
insert into WORKER_TEMP_B (workerid, workername, birthdate, itsboss_workerid, startdate, enddate, type, citizenid, salary)
values (558483801, 'Olivia Duncan', to_date('09-08-1973', 'dd-mm-yyyy'), 655611592, to_date('29-02-2012', 'dd-mm-yyyy'), to_date('25-10-2040', 'dd-mm-yyyy'), 2, 710935253, 16215.447677570136176864975958651469595);
insert into WORKER_TEMP_B (workerid, workername, birthdate, itsboss_workerid, startdate, enddate, type, citizenid, salary)
values (833381050, 'Kolten Clarke', to_date('27-02-1964', 'dd-mm-yyyy'), 655611592, to_date('11-07-2005', 'dd-mm-yyyy'), to_date('01-01-2021', 'dd-mm-yyyy'), 2, 293713935, 33313.318510306708417155743082310357739);
insert into WORKER_TEMP_B (workerid, workername, birthdate, itsboss_workerid, startdate, enddate, type, citizenid, salary)
values (944474945, 'Milagros Hill', to_date('05-01-1994', 'dd-mm-yyyy'), 267895569, to_date('15-01-1982', 'dd-mm-yyyy'), to_date('14-01-2031', 'dd-mm-yyyy'), 1, 63271602, 18027.925065263299524800245158695893687);
insert into WORKER_TEMP_B (workerid, workername, birthdate, itsboss_workerid, startdate, enddate, type, citizenid, salary)
values (948300705, 'Libby Dickson', to_date('03-02-1961', 'dd-mm-yyyy'), 267895569, to_date('15-10-2001', 'dd-mm-yyyy'), to_date('27-02-2038', 'dd-mm-yyyy'), 2, 326413904, 28356.0383070519795802116557367318434);
insert into WORKER_TEMP_B (workerid, workername, birthdate, itsboss_workerid, startdate, enddate, type, citizenid, salary)
values (572710466, 'Kiley Compton', to_date('25-02-1989', 'dd-mm-yyyy'), 475822438, to_date('15-03-1998', 'dd-mm-yyyy'), to_date('10-02-2023', 'dd-mm-yyyy'), 2, 360147273, 27236.526138116180649215524025872792418);
insert into WORKER_TEMP_B (workerid, workername, birthdate, itsboss_workerid, startdate, enddate, type, citizenid, salary)
values (36653768, 'Taryn Bridges', to_date('19-08-1968', 'dd-mm-yyyy'), 608832283, to_date('01-11-2004', 'dd-mm-yyyy'), to_date('10-05-2034', 'dd-mm-yyyy'), 2, 642196831, 33656.39914505061108675230479292286124);
insert into WORKER_TEMP_B (workerid, workername, birthdate, itsboss_workerid, startdate, enddate, type, citizenid, salary)
values (609838404, 'Elsie Black', to_date('19-11-1971', 'dd-mm-yyyy'), 608832283, to_date('03-06-1992', 'dd-mm-yyyy'), to_date('17-12-2024', 'dd-mm-yyyy'), 1, 187988627, 25000.312633530483701024021803058821825);
insert into WORKER_TEMP_B (workerid, workername, birthdate, itsboss_workerid, startdate, enddate, type, citizenid, salary)
values (74246556, 'Bruce Meyer', to_date('18-03-1996', 'dd-mm-yyyy'), 871947790, to_date('08-04-2006', 'dd-mm-yyyy'), to_date('19-04-2031', 'dd-mm-yyyy'), 1, 211681471, 25000.378299588731251471393777068383402);
insert into WORKER_TEMP_B (workerid, workername, birthdate, itsboss_workerid, startdate, enddate, type, citizenid, salary)
values (69683187, 'Teagan Fritz', to_date('22-09-1951', 'dd-mm-yyyy'), 871947790, to_date('27-02-1990', 'dd-mm-yyyy'), to_date('24-06-2028', 'dd-mm-yyyy'), 2, 503126262, 26684.18786363516707752814178772822681);
insert into WORKER_TEMP_B (workerid, workername, birthdate, itsboss_workerid, startdate, enddate, type, citizenid, salary)
values (772049123, 'Alfredo Cline', to_date('16-06-1994', 'dd-mm-yyyy'), 531238815, to_date('08-02-2015', 'dd-mm-yyyy'), to_date('24-09-2025', 'dd-mm-yyyy'), 2, 437511476, 34132.269700683266923953969725978945376);
insert into WORKER_TEMP_B (workerid, workername, birthdate, itsboss_workerid, startdate, enddate, type, citizenid, salary)
values (9637682, 'Alvin Alvarez', to_date('06-02-1994', 'dd-mm-yyyy'), 531238815, to_date('07-10-2000', 'dd-mm-yyyy'), to_date('12-11-2035', 'dd-mm-yyyy'), 2, 991978392, 13307.812488475930709376536895650004232);
insert into WORKER_TEMP_B (workerid, workername, birthdate, itsboss_workerid, startdate, enddate, type, citizenid, salary)
values (894659176, 'Cayden Henry', to_date('16-04-1968', 'dd-mm-yyyy'), 648956315, to_date('26-09-1991', 'dd-mm-yyyy'), to_date('22-11-2029', 'dd-mm-yyyy'), 1, 897773040, 24762.633196457355346327647205746228471);
insert into WORKER_TEMP_B (workerid, workername, birthdate, itsboss_workerid, startdate, enddate, type, citizenid, salary)
values (420691439, 'Haiden Shepard', to_date('17-06-1964', 'dd-mm-yyyy'), 71932811, to_date('20-09-1995', 'dd-mm-yyyy'), to_date('23-01-2020', 'dd-mm-yyyy'), 1, 779945885, 28527.361522623696509520686774448988006);
insert into WORKER_TEMP_B (workerid, workername, birthdate, itsboss_workerid, startdate, enddate, type, citizenid, salary)
values (93706212, 'Braden Summers', to_date('06-07-1993', 'dd-mm-yyyy'), 71932811, to_date('13-12-2004', 'dd-mm-yyyy'), to_date('15-12-2028', 'dd-mm-yyyy'), 2, 726563582, 5540.2358650611680252394985988952698139);
insert into WORKER_TEMP_B (workerid, workername, birthdate, itsboss_workerid, startdate, enddate, type, citizenid, salary)
values (227081707, 'James Nichols', to_date('03-02-1960', 'dd-mm-yyyy'), 311466467, to_date('16-01-2005', 'dd-mm-yyyy'), to_date('22-11-2026', 'dd-mm-yyyy'), 1, 156171593, 35837.156365628830215646033365604634997);
insert into WORKER_TEMP_B (workerid, workername, birthdate, itsboss_workerid, startdate, enddate, type, citizenid, salary)
values (670519313, 'Joselyn Chan', to_date('22-04-1964', 'dd-mm-yyyy'), 214019947, to_date('03-04-1986', 'dd-mm-yyyy'), to_date('10-11-2022', 'dd-mm-yyyy'), 1, 388283660, 25986.121671642552951971101348324802173);
insert into WORKER_TEMP_B (workerid, workername, birthdate, itsboss_workerid, startdate, enddate, type, citizenid, salary)
values (135594200, 'Serena Klein', to_date('14-12-1970', 'dd-mm-yyyy'), 214019947, to_date('28-11-1980', 'dd-mm-yyyy'), to_date('21-05-2032', 'dd-mm-yyyy'), 2, 18795929, 22273.329059396934631082171002708431329);
insert into WORKER_TEMP_B (workerid, workername, birthdate, itsboss_workerid, startdate, enddate, type, citizenid, salary)
values (829823516, 'Kiana Jimenez', to_date('24-09-1993', 'dd-mm-yyyy'), 655611592, to_date('03-06-2007', 'dd-mm-yyyy'), to_date('18-05-2021', 'dd-mm-yyyy'), 2, 173006051, 31042.784190640829686796137188889747455);
insert into WORKER_TEMP_B (workerid, workername, birthdate, itsboss_workerid, startdate, enddate, type, citizenid, salary)
values (163199704, 'Tamia Mercado', to_date('03-11-1951', 'dd-mm-yyyy'), 267895569, to_date('18-01-2006', 'dd-mm-yyyy'), to_date('29-01-2037', 'dd-mm-yyyy'), 2, 840454690, 32962.478995010401739244282679799519574);
insert into WORKER_TEMP_B (workerid, workername, birthdate, itsboss_workerid, startdate, enddate, type, citizenid, salary)
values (651653039, 'Ariel Little', to_date('26-04-1955', 'dd-mm-yyyy'), 475822438, to_date('09-10-1994', 'dd-mm-yyyy'), to_date('22-01-2032', 'dd-mm-yyyy'), 2, 55937608, 9121.2088786137146087798644594047073959);
insert into WORKER_TEMP_B (workerid, workername, birthdate, itsboss_workerid, startdate, enddate, type, citizenid, salary)
values (334482803, 'Nolan Orozco', to_date('18-05-1988', 'dd-mm-yyyy'), 475822438, to_date('06-08-2013', 'dd-mm-yyyy'), to_date('18-06-2023', 'dd-mm-yyyy'), 1, 719978224, 6775.8236147327071684492877237832163822);
insert into WORKER_TEMP_B (workerid, workername, birthdate, itsboss_workerid, startdate, enddate, type, citizenid, salary)
values (590390539, 'George Maldonado', to_date('05-11-1984', 'dd-mm-yyyy'), 608832283, to_date('14-07-1984', 'dd-mm-yyyy'), to_date('26-10-2032', 'dd-mm-yyyy'), 2, 834214215, 8183.9222283803925578257005781593370243);
insert into WORKER_TEMP_B (workerid, workername, birthdate, itsboss_workerid, startdate, enddate, type, citizenid, salary)
values (930997789, 'Leonel Joseph', to_date('07-03-1963', 'dd-mm-yyyy'), 871947790, to_date('07-01-1984', 'dd-mm-yyyy'), to_date('19-09-2023', 'dd-mm-yyyy'), 1, 988386543, 3113.7025271378068915207640205283821411);
insert into WORKER_TEMP_B (workerid, workername, birthdate, itsboss_workerid, startdate, enddate, type, citizenid, salary)
values (264181465, 'Koen Finley', to_date('09-02-1999', 'dd-mm-yyyy'), 871947790, to_date('12-10-1987', 'dd-mm-yyyy'), to_date('05-07-2038', 'dd-mm-yyyy'), 2, 129407872, 18862.35828701665261189324190396187946);
insert into WORKER_TEMP_B (workerid, workername, birthdate, itsboss_workerid, startdate, enddate, type, citizenid, salary)
values (675443623, 'Noelle Butler', to_date('22-10-1999', 'dd-mm-yyyy'), 531238815, to_date('02-09-2002', 'dd-mm-yyyy'), to_date('14-03-2025', 'dd-mm-yyyy'), 1, 742852779, 33803.698220835031437731989611021742538);
insert into WORKER_TEMP_B (workerid, workername, birthdate, itsboss_workerid, startdate, enddate, type, citizenid, salary)
values (98795350, 'Saul Leonard', to_date('22-09-1962', 'dd-mm-yyyy'), 648956315, to_date('11-08-2016', 'dd-mm-yyyy'), to_date('01-05-2037', 'dd-mm-yyyy'), 2, 592650513, 21762.91751536859650591318778158206836);
insert into WORKER_TEMP_B (workerid, workername, birthdate, itsboss_workerid, startdate, enddate, type, citizenid, salary)
values (291975656, 'Haley Howe', to_date('25-08-1989', 'dd-mm-yyyy'), 648956315, to_date('09-07-2003', 'dd-mm-yyyy'), to_date('06-12-2037', 'dd-mm-yyyy'), 1, 448291127, 16054.515507227283992391226281292025767);
insert into WORKER_TEMP_B (workerid, workername, birthdate, itsboss_workerid, startdate, enddate, type, citizenid, salary)
values (832411481, 'Josie Mcfarland', to_date('19-04-1978', 'dd-mm-yyyy'), 71932811, to_date('31-05-1985', 'dd-mm-yyyy'), to_date('07-07-2031', 'dd-mm-yyyy'), 1, 653961350, 4932.2485803413571248224693757347971888);
insert into WORKER_TEMP_B (workerid, workername, birthdate, itsboss_workerid, startdate, enddate, type, citizenid, salary)
values (821772864, 'Yazmin Oconnell', to_date('31-10-1963', 'dd-mm-yyyy'), 311466467, to_date('28-02-2002', 'dd-mm-yyyy'), to_date('16-05-2035', 'dd-mm-yyyy'), 1, 64729682, 29987.070307438608874892745073046970926);
insert into WORKER_TEMP_B (workerid, workername, birthdate, itsboss_workerid, startdate, enddate, type, citizenid, salary)
values (927420065, 'Declan Wilson', to_date('09-09-1990', 'dd-mm-yyyy'), 214019947, to_date('21-09-1981', 'dd-mm-yyyy'), to_date('12-12-2020', 'dd-mm-yyyy'), 1, 685600354, 34185.92911143343729939184379071854217);
insert into WORKER_TEMP_B (workerid, workername, birthdate, itsboss_workerid, startdate, enddate, type, citizenid, salary)
values (694973824, 'Iyana Paul', to_date('15-08-1953', 'dd-mm-yyyy'), 648956315, to_date('09-02-2004', 'dd-mm-yyyy'), to_date('25-10-2021', 'dd-mm-yyyy'), 1, 206683768, 28804.18876219195801541084822503836998);
insert into WORKER_TEMP_B (workerid, workername, birthdate, itsboss_workerid, startdate, enddate, type, citizenid, salary)
values (460241027, 'Damien Hess', to_date('22-12-1968', 'dd-mm-yyyy'), 311466467, to_date('18-08-2013', 'dd-mm-yyyy'), to_date('01-12-2022', 'dd-mm-yyyy'), 1, 171910180, 26501.58159707103441233146267097322762);
insert into WORKER_TEMP_B (workerid, workername, birthdate, itsboss_workerid, startdate, enddate, type, citizenid, salary)
values (390209868, 'Sammy Bonilla', to_date('04-11-1956', 'dd-mm-yyyy'), 655611592, to_date('05-06-2001', 'dd-mm-yyyy'), to_date('21-04-2037', 'dd-mm-yyyy'), 1, 856592056, 10545.755710349315236677529302239225436);
insert into WORKER_TEMP_B (workerid, workername, birthdate, itsboss_workerid, startdate, enddate, type, citizenid, salary)
values (47750333, 'Chanel Raymond', to_date('27-04-1973', 'dd-mm-yyyy'), 267895569, to_date('12-12-2012', 'dd-mm-yyyy'), to_date('25-03-2028', 'dd-mm-yyyy'), 2, 677761715, 5732.8015133009514094129673947795150378);
insert into WORKER_TEMP_B (workerid, workername, birthdate, itsboss_workerid, startdate, enddate, type, citizenid, salary)
values (777271072, 'Valery Leach', to_date('17-06-1959', 'dd-mm-yyyy'), 608832283, to_date('20-01-1980', 'dd-mm-yyyy'), to_date('16-08-2037', 'dd-mm-yyyy'), 2, 434932129, 35912.866754466081705009069248831870624);
insert into WORKER_TEMP_B (workerid, workername, birthdate, itsboss_workerid, startdate, enddate, type, citizenid, salary)
values (904309366, 'Marshall Barton', to_date('24-11-1993', 'dd-mm-yyyy'), 531238815, to_date('13-12-1980', 'dd-mm-yyyy'), to_date('26-06-2037', 'dd-mm-yyyy'), 1, 452323355, 36590.575938910057280591902941905546397);
insert into WORKER_TEMP_B (workerid, workername, birthdate, itsboss_workerid, startdate, enddate, type, citizenid, salary)
values (659346126, 'Emmy Strong', to_date('09-09-1973', 'dd-mm-yyyy'), 71932811, to_date('04-05-1996', 'dd-mm-yyyy'), to_date('16-06-2025', 'dd-mm-yyyy'), 1, 18645918, 21335.905268600340922146511364614522048);
insert into WORKER_TEMP_B (workerid, workername, birthdate, itsboss_workerid, startdate, enddate, type, citizenid, salary)
values (813408967, 'Zaniyah Reese', to_date('19-01-1997', 'dd-mm-yyyy'), 311466467, to_date('14-07-1999', 'dd-mm-yyyy'), to_date('17-03-2035', 'dd-mm-yyyy'), 1, 955095939, 5961.0652840043219342127515090876694865);
insert into WORKER_TEMP_B (workerid, workername, birthdate, itsboss_workerid, startdate, enddate, type, citizenid, salary)
values (978976997, 'Kelly Murphy', to_date('03-06-1983', 'dd-mm-yyyy'), 608832283, to_date('16-06-2008', 'dd-mm-yyyy'), to_date('18-04-2023', 'dd-mm-yyyy'), 2, 996662084, 30094.418105389213383082205093906409382);
insert into WORKER_TEMP_B (workerid, workername, birthdate, itsboss_workerid, startdate, enddate, type, citizenid, salary)
values (151713573, 'Phoenix Mcdowell', to_date('20-11-1994', 'dd-mm-yyyy'), 475822438, to_date('10-01-1990', 'dd-mm-yyyy'), to_date('26-08-2032', 'dd-mm-yyyy'), 2, 792958079, 17850.987808947720464222155946218053754);
prompt 100 records loaded
prompt Enabling triggers for WORKER_TEMP_B...
alter table WORKER_TEMP_B enable all triggers;

set feedback on
set define on
prompt Done
