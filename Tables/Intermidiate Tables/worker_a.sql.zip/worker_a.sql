?��prompt PL/SQL Developer Export Tables for user SYSTEM
prompt Created by Evyatar on יום שני 10 אוגוסט 2020
set feedback off
set define off

prompt Creating WORKER_A...
create table WORKER_A
(
  workerid  INTEGER not null,
  startdate DATE not null,
  enddate   DATE not null,
  salary    FLOAT not null,
  type      INTEGER not null,
  citizenid INTEGER not null
)
tablespace SYSTEM
  pctfree 10
  pctused 40
  initrans 1
  maxtrans 255
  storage
  (
    initial 64K
    next 1M
    minextents 1
    maxextents unlimited
  );
alter table WORKER_A
  add primary key (WORKERID)
  using index 
  tablespace SYSTEM
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 64K
    next 1M
    minextents 1
    maxextents unlimited
  );
alter table WORKER_A
  add foreign key (CITIZENID)
  references CITIZEN (CITIZENID);

prompt Disabling triggers for WORKER_A...
alter table WORKER_A disable all triggers;
prompt Disabling foreign key constraints for WORKER_A...
alter table WORKER_A disable constraint SYS_C007451;
prompt Deleting WORKER_A...
delete from WORKER_A;
prompt Loading WORKER_A...
insert into WORKER_A (workerid, startdate, enddate, salary, type, citizenid)
values (5000, to_date('04-01-2020', 'dd-mm-yyyy'), to_date('19-10-2020', 'dd-mm-yyyy'), 16769, 1, 166);
insert into WORKER_A (workerid, startdate, enddate, salary, type, citizenid)
values (5001, to_date('08-04-2020', 'dd-mm-yyyy'), to_date('02-06-2020', 'dd-mm-yyyy'), 6845, 2, 503);
insert into WORKER_A (workerid, startdate, enddate, salary, type, citizenid)
values (5002, to_date('18-04-2009', 'dd-mm-yyyy'), to_date('03-04-2021', 'dd-mm-yyyy'), 6350, 2, 627);
insert into WORKER_A (workerid, startdate, enddate, salary, type, citizenid)
values (5003, to_date('16-04-2008', 'dd-mm-yyyy'), to_date('23-01-2025', 'dd-mm-yyyy'), 6202, 2, 387);
insert into WORKER_A (workerid, startdate, enddate, salary, type, citizenid)
values (5004, to_date('13-05-2017', 'dd-mm-yyyy'), to_date('13-01-2025', 'dd-mm-yyyy'), 14382, 2, 920);
insert into WORKER_A (workerid, startdate, enddate, salary, type, citizenid)
values (5005, to_date('16-12-2019', 'dd-mm-yyyy'), to_date('05-11-2025', 'dd-mm-yyyy'), 21384, 2, 878);
insert into WORKER_A (workerid, startdate, enddate, salary, type, citizenid)
values (5006, to_date('27-01-2013', 'dd-mm-yyyy'), to_date('03-08-2024', 'dd-mm-yyyy'), 5463, 1, 404);
insert into WORKER_A (workerid, startdate, enddate, salary, type, citizenid)
values (5007, to_date('25-07-2015', 'dd-mm-yyyy'), to_date('04-04-2025', 'dd-mm-yyyy'), 18894, 2, 848);
insert into WORKER_A (workerid, startdate, enddate, salary, type, citizenid)
values (5008, to_date('05-08-2016', 'dd-mm-yyyy'), to_date('09-04-2023', 'dd-mm-yyyy'), 6122, 2, 316);
insert into WORKER_A (workerid, startdate, enddate, salary, type, citizenid)
values (5009, to_date('30-12-2016', 'dd-mm-yyyy'), to_date('23-07-2024', 'dd-mm-yyyy'), 19384, 2, 360);
insert into WORKER_A (workerid, startdate, enddate, salary, type, citizenid)
values (5010, to_date('04-01-2008', 'dd-mm-yyyy'), to_date('30-07-2020', 'dd-mm-yyyy'), 8672, 2, 676);
insert into WORKER_A (workerid, startdate, enddate, salary, type, citizenid)
values (5011, to_date('16-05-2015', 'dd-mm-yyyy'), to_date('25-12-2024', 'dd-mm-yyyy'), 10591, 2, 731);
insert into WORKER_A (workerid, startdate, enddate, salary, type, citizenid)
values (5012, to_date('20-10-2011', 'dd-mm-yyyy'), to_date('21-12-2024', 'dd-mm-yyyy'), 20722, 2, 14);
insert into WORKER_A (workerid, startdate, enddate, salary, type, citizenid)
values (5013, to_date('17-05-2015', 'dd-mm-yyyy'), to_date('05-07-2024', 'dd-mm-yyyy'), 18032, 2, 853);
insert into WORKER_A (workerid, startdate, enddate, salary, type, citizenid)
values (5014, to_date('29-03-2009', 'dd-mm-yyyy'), to_date('30-08-2022', 'dd-mm-yyyy'), 21995, 1, 642);
insert into WORKER_A (workerid, startdate, enddate, salary, type, citizenid)
values (5015, to_date('11-06-2016', 'dd-mm-yyyy'), to_date('13-06-2023', 'dd-mm-yyyy'), 12747, 1, 103);
insert into WORKER_A (workerid, startdate, enddate, salary, type, citizenid)
values (5016, to_date('14-04-2008', 'dd-mm-yyyy'), to_date('03-08-2020', 'dd-mm-yyyy'), 21494, 2, 325);
insert into WORKER_A (workerid, startdate, enddate, salary, type, citizenid)
values (5017, to_date('20-01-2013', 'dd-mm-yyyy'), to_date('16-01-2022', 'dd-mm-yyyy'), 4779, 2, 877);
insert into WORKER_A (workerid, startdate, enddate, salary, type, citizenid)
values (5018, to_date('01-11-2011', 'dd-mm-yyyy'), to_date('29-10-2023', 'dd-mm-yyyy'), 11830, 1, 914);
insert into WORKER_A (workerid, startdate, enddate, salary, type, citizenid)
values (5019, to_date('10-07-2017', 'dd-mm-yyyy'), to_date('22-11-2022', 'dd-mm-yyyy'), 12855, 1, 578);
insert into WORKER_A (workerid, startdate, enddate, salary, type, citizenid)
values (5020, to_date('05-04-2020', 'dd-mm-yyyy'), to_date('21-09-2020', 'dd-mm-yyyy'), 10439, 1, 175);
insert into WORKER_A (workerid, startdate, enddate, salary, type, citizenid)
values (5021, to_date('01-07-2011', 'dd-mm-yyyy'), to_date('21-07-2021', 'dd-mm-yyyy'), 9929, 2, 257);
insert into WORKER_A (workerid, startdate, enddate, salary, type, citizenid)
values (5022, to_date('25-12-2016', 'dd-mm-yyyy'), to_date('11-07-2024', 'dd-mm-yyyy'), 16873, 1, 341);
insert into WORKER_A (workerid, startdate, enddate, salary, type, citizenid)
values (5023, to_date('26-11-2013', 'dd-mm-yyyy'), to_date('06-01-2022', 'dd-mm-yyyy'), 9141, 2, 155);
insert into WORKER_A (workerid, startdate, enddate, salary, type, citizenid)
values (5024, to_date('03-11-2013', 'dd-mm-yyyy'), to_date('24-06-2022', 'dd-mm-yyyy'), 20223, 1, 331);
insert into WORKER_A (workerid, startdate, enddate, salary, type, citizenid)
values (5025, to_date('20-08-2016', 'dd-mm-yyyy'), to_date('16-10-2024', 'dd-mm-yyyy'), 14283, 2, 732);
insert into WORKER_A (workerid, startdate, enddate, salary, type, citizenid)
values (5026, to_date('04-04-2016', 'dd-mm-yyyy'), to_date('22-12-2021', 'dd-mm-yyyy'), 14454, 1, 732);
insert into WORKER_A (workerid, startdate, enddate, salary, type, citizenid)
values (5027, to_date('11-11-2010', 'dd-mm-yyyy'), to_date('27-11-2024', 'dd-mm-yyyy'), 9317, 1, 352);
insert into WORKER_A (workerid, startdate, enddate, salary, type, citizenid)
values (5028, to_date('29-12-2016', 'dd-mm-yyyy'), to_date('24-11-2021', 'dd-mm-yyyy'), 20730, 1, 8);
insert into WORKER_A (workerid, startdate, enddate, salary, type, citizenid)
values (5029, to_date('28-04-2013', 'dd-mm-yyyy'), to_date('17-11-2021', 'dd-mm-yyyy'), 9948, 2, 280);
insert into WORKER_A (workerid, startdate, enddate, salary, type, citizenid)
values (5030, to_date('17-01-2008', 'dd-mm-yyyy'), to_date('06-09-2021', 'dd-mm-yyyy'), 20254, 1, 736);
insert into WORKER_A (workerid, startdate, enddate, salary, type, citizenid)
values (5031, to_date('22-11-2008', 'dd-mm-yyyy'), to_date('07-08-2025', 'dd-mm-yyyy'), 14712, 2, 56);
insert into WORKER_A (workerid, startdate, enddate, salary, type, citizenid)
values (5032, to_date('30-12-2012', 'dd-mm-yyyy'), to_date('27-03-2025', 'dd-mm-yyyy'), 5439, 1, 193);
insert into WORKER_A (workerid, startdate, enddate, salary, type, citizenid)
values (5033, to_date('20-12-2009', 'dd-mm-yyyy'), to_date('19-12-2022', 'dd-mm-yyyy'), 14895, 2, 214);
insert into WORKER_A (workerid, startdate, enddate, salary, type, citizenid)
values (5034, to_date('15-12-2011', 'dd-mm-yyyy'), to_date('15-01-2022', 'dd-mm-yyyy'), 4878, 2, 344);
insert into WORKER_A (workerid, startdate, enddate, salary, type, citizenid)
values (5035, to_date('12-08-2015', 'dd-mm-yyyy'), to_date('26-09-2024', 'dd-mm-yyyy'), 17652, 1, 750);
insert into WORKER_A (workerid, startdate, enddate, salary, type, citizenid)
values (5036, to_date('30-01-2019', 'dd-mm-yyyy'), to_date('28-06-2024', 'dd-mm-yyyy'), 5319, 2, 322);
insert into WORKER_A (workerid, startdate, enddate, salary, type, citizenid)
values (5037, to_date('20-06-2017', 'dd-mm-yyyy'), to_date('03-11-2025', 'dd-mm-yyyy'), 8360, 2, 341);
insert into WORKER_A (workerid, startdate, enddate, salary, type, citizenid)
values (5038, to_date('03-09-2012', 'dd-mm-yyyy'), to_date('24-06-2024', 'dd-mm-yyyy'), 7259, 1, 758);
insert into WORKER_A (workerid, startdate, enddate, salary, type, citizenid)
values (5039, to_date('11-03-2018', 'dd-mm-yyyy'), to_date('27-06-2024', 'dd-mm-yyyy'), 8416, 2, 48);
insert into WORKER_A (workerid, startdate, enddate, salary, type, citizenid)
values (5040, to_date('07-04-2010', 'dd-mm-yyyy'), to_date('10-03-2021', 'dd-mm-yyyy'), 16463, 1, 156);
insert into WORKER_A (workerid, startdate, enddate, salary, type, citizenid)
values (5041, to_date('18-09-2015', 'dd-mm-yyyy'), to_date('16-08-2022', 'dd-mm-yyyy'), 10690, 1, 729);
insert into WORKER_A (workerid, startdate, enddate, salary, type, citizenid)
values (5042, to_date('06-03-2016', 'dd-mm-yyyy'), to_date('09-10-2022', 'dd-mm-yyyy'), 19329, 2, 607);
insert into WORKER_A (workerid, startdate, enddate, salary, type, citizenid)
values (5043, to_date('13-09-2014', 'dd-mm-yyyy'), to_date('17-11-2021', 'dd-mm-yyyy'), 10613, 2, 708);
insert into WORKER_A (workerid, startdate, enddate, salary, type, citizenid)
values (5044, to_date('21-05-2009', 'dd-mm-yyyy'), to_date('21-11-2021', 'dd-mm-yyyy'), 12189, 2, 955);
insert into WORKER_A (workerid, startdate, enddate, salary, type, citizenid)
values (5045, to_date('16-10-2013', 'dd-mm-yyyy'), to_date('30-09-2021', 'dd-mm-yyyy'), 13718, 1, 880);
insert into WORKER_A (workerid, startdate, enddate, salary, type, citizenid)
values (5046, to_date('07-07-2019', 'dd-mm-yyyy'), to_date('26-03-2021', 'dd-mm-yyyy'), 12979, 2, 747);
insert into WORKER_A (workerid, startdate, enddate, salary, type, citizenid)
values (5047, to_date('20-07-2019', 'dd-mm-yyyy'), to_date('31-01-2022', 'dd-mm-yyyy'), 6330, 1, 547);
insert into WORKER_A (workerid, startdate, enddate, salary, type, citizenid)
values (5048, to_date('27-06-2009', 'dd-mm-yyyy'), to_date('03-04-2025', 'dd-mm-yyyy'), 16830, 1, 339);
insert into WORKER_A (workerid, startdate, enddate, salary, type, citizenid)
values (5049, to_date('08-03-2015', 'dd-mm-yyyy'), to_date('01-10-2023', 'dd-mm-yyyy'), 12266, 1, 365);
insert into WORKER_A (workerid, startdate, enddate, salary, type, citizenid)
values (5050, to_date('26-09-2008', 'dd-mm-yyyy'), to_date('29-05-2021', 'dd-mm-yyyy'), 16725, 2, 131);
insert into WORKER_A (workerid, startdate, enddate, salary, type, citizenid)
values (5051, to_date('17-01-2011', 'dd-mm-yyyy'), to_date('19-01-2022', 'dd-mm-yyyy'), 12890, 2, 920);
insert into WORKER_A (workerid, startdate, enddate, salary, type, citizenid)
values (5052, to_date('04-08-2018', 'dd-mm-yyyy'), to_date('05-11-2021', 'dd-mm-yyyy'), 6909, 2, 410);
insert into WORKER_A (workerid, startdate, enddate, salary, type, citizenid)
values (5053, to_date('13-08-2012', 'dd-mm-yyyy'), to_date('25-09-2024', 'dd-mm-yyyy'), 13869, 2, 201);
insert into WORKER_A (workerid, startdate, enddate, salary, type, citizenid)
values (5054, to_date('01-12-2015', 'dd-mm-yyyy'), to_date('27-03-2024', 'dd-mm-yyyy'), 10085, 2, 479);
insert into WORKER_A (workerid, startdate, enddate, salary, type, citizenid)
values (5055, to_date('11-08-2015', 'dd-mm-yyyy'), to_date('05-04-2022', 'dd-mm-yyyy'), 19565, 1, 700);
insert into WORKER_A (workerid, startdate, enddate, salary, type, citizenid)
values (5056, to_date('30-11-2010', 'dd-mm-yyyy'), to_date('05-09-2023', 'dd-mm-yyyy'), 21948, 1, 26);
insert into WORKER_A (workerid, startdate, enddate, salary, type, citizenid)
values (5057, to_date('24-04-2016', 'dd-mm-yyyy'), to_date('25-04-2022', 'dd-mm-yyyy'), 16316, 1, 527);
insert into WORKER_A (workerid, startdate, enddate, salary, type, citizenid)
values (5058, to_date('19-05-2008', 'dd-mm-yyyy'), to_date('23-07-2023', 'dd-mm-yyyy'), 20117, 1, 727);
insert into WORKER_A (workerid, startdate, enddate, salary, type, citizenid)
values (5059, to_date('08-05-2017', 'dd-mm-yyyy'), to_date('30-05-2025', 'dd-mm-yyyy'), 19088, 1, 920);
insert into WORKER_A (workerid, startdate, enddate, salary, type, citizenid)
values (5060, to_date('09-09-2018', 'dd-mm-yyyy'), to_date('09-09-2024', 'dd-mm-yyyy'), 7602, 2, 310);
insert into WORKER_A (workerid, startdate, enddate, salary, type, citizenid)
values (5061, to_date('04-09-2010', 'dd-mm-yyyy'), to_date('09-07-2022', 'dd-mm-yyyy'), 19092, 1, 386);
insert into WORKER_A (workerid, startdate, enddate, salary, type, citizenid)
values (5062, to_date('26-09-2019', 'dd-mm-yyyy'), to_date('27-12-2023', 'dd-mm-yyyy'), 17085, 1, 511);
insert into WORKER_A (workerid, startdate, enddate, salary, type, citizenid)
values (5063, to_date('09-11-2017', 'dd-mm-yyyy'), to_date('18-03-2021', 'dd-mm-yyyy'), 13308, 2, 499);
insert into WORKER_A (workerid, startdate, enddate, salary, type, citizenid)
values (5064, to_date('07-05-2018', 'dd-mm-yyyy'), to_date('08-08-2023', 'dd-mm-yyyy'), 16368, 1, 776);
insert into WORKER_A (workerid, startdate, enddate, salary, type, citizenid)
values (5065, to_date('01-09-2010', 'dd-mm-yyyy'), to_date('16-04-2025', 'dd-mm-yyyy'), 13330, 1, 628);
insert into WORKER_A (workerid, startdate, enddate, salary, type, citizenid)
values (5066, to_date('17-07-2016', 'dd-mm-yyyy'), to_date('27-09-2022', 'dd-mm-yyyy'), 20745, 2, 144);
insert into WORKER_A (workerid, startdate, enddate, salary, type, citizenid)
values (5067, to_date('19-08-2015', 'dd-mm-yyyy'), to_date('17-11-2024', 'dd-mm-yyyy'), 20834, 1, 731);
insert into WORKER_A (workerid, startdate, enddate, salary, type, citizenid)
values (5068, to_date('02-10-2012', 'dd-mm-yyyy'), to_date('30-03-2024', 'dd-mm-yyyy'), 9540, 2, 660);
insert into WORKER_A (workerid, startdate, enddate, salary, type, citizenid)
values (5069, to_date('20-11-2019', 'dd-mm-yyyy'), to_date('08-05-2023', 'dd-mm-yyyy'), 7354, 2, 272);
insert into WORKER_A (workerid, startdate, enddate, salary, type, citizenid)
values (5070, to_date('06-09-2015', 'dd-mm-yyyy'), to_date('23-09-2024', 'dd-mm-yyyy'), 5185, 2, 835);
insert into WORKER_A (workerid, startdate, enddate, salary, type, citizenid)
values (5071, to_date('03-10-2012', 'dd-mm-yyyy'), to_date('22-08-2020', 'dd-mm-yyyy'), 10997, 1, 456);
insert into WORKER_A (workerid, startdate, enddate, salary, type, citizenid)
values (5072, to_date('22-02-2019', 'dd-mm-yyyy'), to_date('07-11-2024', 'dd-mm-yyyy'), 20694, 1, 340);
insert into WORKER_A (workerid, startdate, enddate, salary, type, citizenid)
values (5073, to_date('12-02-2018', 'dd-mm-yyyy'), to_date('16-09-2022', 'dd-mm-yyyy'), 5417, 1, 843);
insert into WORKER_A (workerid, startdate, enddate, salary, type, citizenid)
values (5074, to_date('01-08-2014', 'dd-mm-yyyy'), to_date('18-02-2022', 'dd-mm-yyyy'), 4722, 2, 138);
insert into WORKER_A (workerid, startdate, enddate, salary, type, citizenid)
values (5075, to_date('21-08-2010', 'dd-mm-yyyy'), to_date('07-10-2025', 'dd-mm-yyyy'), 17007, 2, 75);
insert into WORKER_A (workerid, startdate, enddate, salary, type, citizenid)
values (5076, to_date('04-09-2010', 'dd-mm-yyyy'), to_date('27-10-2025', 'dd-mm-yyyy'), 5352, 1, 924);
insert into WORKER_A (workerid, startdate, enddate, salary, type, citizenid)
values (5077, to_date('03-01-2010', 'dd-mm-yyyy'), to_date('22-12-2021', 'dd-mm-yyyy'), 5708, 2, 488);
insert into WORKER_A (workerid, startdate, enddate, salary, type, citizenid)
values (5078, to_date('06-09-2019', 'dd-mm-yyyy'), to_date('19-09-2021', 'dd-mm-yyyy'), 17794, 2, 845);
insert into WORKER_A (workerid, startdate, enddate, salary, type, citizenid)
values (5079, to_date('06-05-2009', 'dd-mm-yyyy'), to_date('12-02-2023', 'dd-mm-yyyy'), 19605, 2, 850);
insert into WORKER_A (workerid, startdate, enddate, salary, type, citizenid)
values (5080, to_date('18-07-2011', 'dd-mm-yyyy'), to_date('18-07-2025', 'dd-mm-yyyy'), 20107, 2, 396);
insert into WORKER_A (workerid, startdate, enddate, salary, type, citizenid)
values (5081, to_date('06-03-2008', 'dd-mm-yyyy'), to_date('22-11-2022', 'dd-mm-yyyy'), 16258, 2, 932);
insert into WORKER_A (workerid, startdate, enddate, salary, type, citizenid)
values (5082, to_date('05-08-2014', 'dd-mm-yyyy'), to_date('22-12-2025', 'dd-mm-yyyy'), 12343, 2, 840);
insert into WORKER_A (workerid, startdate, enddate, salary, type, citizenid)
values (5083, to_date('08-10-2015', 'dd-mm-yyyy'), to_date('01-04-2025', 'dd-mm-yyyy'), 7093, 1, 141);
insert into WORKER_A (workerid, startdate, enddate, salary, type, citizenid)
values (5084, to_date('26-12-2014', 'dd-mm-yyyy'), to_date('28-06-2025', 'dd-mm-yyyy'), 10869, 2, 910);
insert into WORKER_A (workerid, startdate, enddate, salary, type, citizenid)
values (5085, to_date('17-06-2013', 'dd-mm-yyyy'), to_date('15-03-2023', 'dd-mm-yyyy'), 19795, 2, 551);
insert into WORKER_A (workerid, startdate, enddate, salary, type, citizenid)
values (5086, to_date('07-08-2010', 'dd-mm-yyyy'), to_date('12-09-2020', 'dd-mm-yyyy'), 16637, 1, 614);
insert into WORKER_A (workerid, startdate, enddate, salary, type, citizenid)
values (5087, to_date('02-05-2019', 'dd-mm-yyyy'), to_date('18-10-2020', 'dd-mm-yyyy'), 10063, 1, 521);
insert into WORKER_A (workerid, startdate, enddate, salary, type, citizenid)
values (5088, to_date('28-03-2017', 'dd-mm-yyyy'), to_date('19-06-2022', 'dd-mm-yyyy'), 6513, 1, 94);
insert into WORKER_A (workerid, startdate, enddate, salary, type, citizenid)
values (5089, to_date('21-04-2008', 'dd-mm-yyyy'), to_date('14-06-2022', 'dd-mm-yyyy'), 21176, 2, 118);
insert into WORKER_A (workerid, startdate, enddate, salary, type, citizenid)
values (5090, to_date('04-10-2014', 'dd-mm-yyyy'), to_date('08-12-2022', 'dd-mm-yyyy'), 14015, 2, 446);
insert into WORKER_A (workerid, startdate, enddate, salary, type, citizenid)
values (5091, to_date('18-09-2008', 'dd-mm-yyyy'), to_date('26-04-2024', 'dd-mm-yyyy'), 21671, 2, 921);
insert into WORKER_A (workerid, startdate, enddate, salary, type, citizenid)
values (5092, to_date('27-09-2016', 'dd-mm-yyyy'), to_date('17-03-2023', 'dd-mm-yyyy'), 6584, 1, 479);
insert into WORKER_A (workerid, startdate, enddate, salary, type, citizenid)
values (5093, to_date('14-11-2019', 'dd-mm-yyyy'), to_date('01-07-2022', 'dd-mm-yyyy'), 9479, 1, 29);
insert into WORKER_A (workerid, startdate, enddate, salary, type, citizenid)
values (5094, to_date('05-10-2014', 'dd-mm-yyyy'), to_date('19-06-2021', 'dd-mm-yyyy'), 12508, 1, 486);
insert into WORKER_A (workerid, startdate, enddate, salary, type, citizenid)
values (5095, to_date('05-05-2019', 'dd-mm-yyyy'), to_date('19-03-2022', 'dd-mm-yyyy'), 6805, 2, 243);
insert into WORKER_A (workerid, startdate, enddate, salary, type, citizenid)
values (5096, to_date('01-03-2017', 'dd-mm-yyyy'), to_date('20-12-2022', 'dd-mm-yyyy'), 8330, 1, 410);
insert into WORKER_A (workerid, startdate, enddate, salary, type, citizenid)
values (5097, to_date('08-05-2014', 'dd-mm-yyyy'), to_date('26-08-2022', 'dd-mm-yyyy'), 13336, 2, 31);
insert into WORKER_A (workerid, startdate, enddate, salary, type, citizenid)
values (5098, to_date('03-04-2008', 'dd-mm-yyyy'), to_date('12-11-2022', 'dd-mm-yyyy'), 16821, 1, 209);
insert into WORKER_A (workerid, startdate, enddate, salary, type, citizenid)
values (5099, to_date('31-03-2018', 'dd-mm-yyyy'), to_date('03-12-2021', 'dd-mm-yyyy'), 10003, 1, 107);
insert into WORKER_A (workerid, startdate, enddate, salary, type, citizenid)
values (5100, to_date('10-12-2013', 'dd-mm-yyyy'), to_date('06-02-2025', 'dd-mm-yyyy'), 10748, 1, 49);
insert into WORKER_A (workerid, startdate, enddate, salary, type, citizenid)
values (5101, to_date('20-05-2020', 'dd-mm-yyyy'), to_date('15-11-2021', 'dd-mm-yyyy'), 18621, 1, 772);
insert into WORKER_A (workerid, startdate, enddate, salary, type, citizenid)
values (5102, to_date('09-03-2008', 'dd-mm-yyyy'), to_date('14-04-2021', 'dd-mm-yyyy'), 12636, 2, 985);
insert into WORKER_A (workerid, startdate, enddate, salary, type, citizenid)
values (5103, to_date('17-06-2019', 'dd-mm-yyyy'), to_date('27-02-2022', 'dd-mm-yyyy'), 16430, 2, 648);
insert into WORKER_A (workerid, startdate, enddate, salary, type, citizenid)
values (5104, to_date('25-01-2009', 'dd-mm-yyyy'), to_date('25-09-2023', 'dd-mm-yyyy'), 17881, 1, 321);
insert into WORKER_A (workerid, startdate, enddate, salary, type, citizenid)
values (5105, to_date('15-07-2013', 'dd-mm-yyyy'), to_date('26-03-2025', 'dd-mm-yyyy'), 8072, 1, 712);
insert into WORKER_A (workerid, startdate, enddate, salary, type, citizenid)
values (5106, to_date('10-06-2008', 'dd-mm-yyyy'), to_date('16-02-2024', 'dd-mm-yyyy'), 5701, 1, 755);
insert into WORKER_A (workerid, startdate, enddate, salary, type, citizenid)
values (5107, to_date('04-05-2019', 'dd-mm-yyyy'), to_date('25-10-2024', 'dd-mm-yyyy'), 16787, 1, 548);
insert into WORKER_A (workerid, startdate, enddate, salary, type, citizenid)
values (5108, to_date('10-03-2015', 'dd-mm-yyyy'), to_date('22-10-2023', 'dd-mm-yyyy'), 14078, 2, 930);
insert into WORKER_A (workerid, startdate, enddate, salary, type, citizenid)
values (5109, to_date('26-06-2015', 'dd-mm-yyyy'), to_date('23-02-2025', 'dd-mm-yyyy'), 8952, 2, 188);
insert into WORKER_A (workerid, startdate, enddate, salary, type, citizenid)
values (5110, to_date('19-11-2008', 'dd-mm-yyyy'), to_date('23-06-2021', 'dd-mm-yyyy'), 18686, 1, 26);
insert into WORKER_A (workerid, startdate, enddate, salary, type, citizenid)
values (5111, to_date('12-08-2014', 'dd-mm-yyyy'), to_date('13-10-2020', 'dd-mm-yyyy'), 11497, 1, 715);
insert into WORKER_A (workerid, startdate, enddate, salary, type, citizenid)
values (5112, to_date('12-02-2013', 'dd-mm-yyyy'), to_date('05-05-2023', 'dd-mm-yyyy'), 14427, 2, 783);
insert into WORKER_A (workerid, startdate, enddate, salary, type, citizenid)
values (5113, to_date('07-03-2008', 'dd-mm-yyyy'), to_date('14-05-2024', 'dd-mm-yyyy'), 21333, 1, 684);
insert into WORKER_A (workerid, startdate, enddate, salary, type, citizenid)
values (5114, to_date('10-11-2015', 'dd-mm-yyyy'), to_date('16-02-2023', 'dd-mm-yyyy'), 7259, 2, 702);
insert into WORKER_A (workerid, startdate, enddate, salary, type, citizenid)
values (5115, to_date('05-02-2009', 'dd-mm-yyyy'), to_date('09-11-2022', 'dd-mm-yyyy'), 17991, 1, 275);
insert into WORKER_A (workerid, startdate, enddate, salary, type, citizenid)
values (5116, to_date('08-03-2016', 'dd-mm-yyyy'), to_date('13-10-2023', 'dd-mm-yyyy'), 10101, 2, 455);
insert into WORKER_A (workerid, startdate, enddate, salary, type, citizenid)
values (5117, to_date('08-03-2011', 'dd-mm-yyyy'), to_date('26-10-2023', 'dd-mm-yyyy'), 10096, 1, 603);
insert into WORKER_A (workerid, startdate, enddate, salary, type, citizenid)
values (5118, to_date('30-08-2011', 'dd-mm-yyyy'), to_date('14-12-2025', 'dd-mm-yyyy'), 21374, 1, 448);
insert into WORKER_A (workerid, startdate, enddate, salary, type, citizenid)
values (5119, to_date('08-06-2017', 'dd-mm-yyyy'), to_date('22-11-2024', 'dd-mm-yyyy'), 5448, 1, 825);
insert into WORKER_A (workerid, startdate, enddate, salary, type, citizenid)
values (5120, to_date('08-02-2013', 'dd-mm-yyyy'), to_date('24-01-2024', 'dd-mm-yyyy'), 10815, 2, 528);
insert into WORKER_A (workerid, startdate, enddate, salary, type, citizenid)
values (5121, to_date('24-05-2015', 'dd-mm-yyyy'), to_date('11-09-2022', 'dd-mm-yyyy'), 4259, 2, 84);
insert into WORKER_A (workerid, startdate, enddate, salary, type, citizenid)
values (5122, to_date('10-12-2013', 'dd-mm-yyyy'), to_date('06-06-2021', 'dd-mm-yyyy'), 6200, 1, 601);
insert into WORKER_A (workerid, startdate, enddate, salary, type, citizenid)
values (5123, to_date('04-03-2015', 'dd-mm-yyyy'), to_date('02-09-2024', 'dd-mm-yyyy'), 9847, 1, 81);
insert into WORKER_A (workerid, startdate, enddate, salary, type, citizenid)
values (5124, to_date('26-02-2011', 'dd-mm-yyyy'), to_date('01-05-2022', 'dd-mm-yyyy'), 13120, 1, 938);
insert into WORKER_A (workerid, startdate, enddate, salary, type, citizenid)
values (5125, to_date('02-01-2016', 'dd-mm-yyyy'), to_date('23-09-2023', 'dd-mm-yyyy'), 9698, 2, 667);
insert into WORKER_A (workerid, startdate, enddate, salary, type, citizenid)
values (5126, to_date('09-09-2013', 'dd-mm-yyyy'), to_date('07-08-2020', 'dd-mm-yyyy'), 9717, 2, 852);
insert into WORKER_A (workerid, startdate, enddate, salary, type, citizenid)
values (5127, to_date('13-03-2011', 'dd-mm-yyyy'), to_date('09-11-2025', 'dd-mm-yyyy'), 20645, 1, 377);
insert into WORKER_A (workerid, startdate, enddate, salary, type, citizenid)
values (5128, to_date('20-06-2019', 'dd-mm-yyyy'), to_date('29-10-2022', 'dd-mm-yyyy'), 15761, 2, 671);
insert into WORKER_A (workerid, startdate, enddate, salary, type, citizenid)
values (5129, to_date('10-11-2017', 'dd-mm-yyyy'), to_date('13-03-2021', 'dd-mm-yyyy'), 21882, 2, 850);
insert into WORKER_A (workerid, startdate, enddate, salary, type, citizenid)
values (5130, to_date('05-04-2018', 'dd-mm-yyyy'), to_date('21-10-2024', 'dd-mm-yyyy'), 20387, 1, 177);
insert into WORKER_A (workerid, startdate, enddate, salary, type, citizenid)
values (5131, to_date('28-10-2011', 'dd-mm-yyyy'), to_date('19-04-2025', 'dd-mm-yyyy'), 8953, 1, 668);
insert into WORKER_A (workerid, startdate, enddate, salary, type, citizenid)
values (5132, to_date('11-05-2014', 'dd-mm-yyyy'), to_date('18-06-2024', 'dd-mm-yyyy'), 9801, 1, 432);
insert into WORKER_A (workerid, startdate, enddate, salary, type, citizenid)
values (5133, to_date('22-11-2013', 'dd-mm-yyyy'), to_date('07-04-2023', 'dd-mm-yyyy'), 15691, 2, 831);
insert into WORKER_A (workerid, startdate, enddate, salary, type, citizenid)
values (5134, to_date('26-02-2019', 'dd-mm-yyyy'), to_date('29-09-2022', 'dd-mm-yyyy'), 12908, 2, 761);
insert into WORKER_A (workerid, startdate, enddate, salary, type, citizenid)
values (5135, to_date('15-01-2009', 'dd-mm-yyyy'), to_date('01-03-2021', 'dd-mm-yyyy'), 21539, 1, 963);
insert into WORKER_A (workerid, startdate, enddate, salary, type, citizenid)
values (5136, to_date('22-03-2018', 'dd-mm-yyyy'), to_date('03-11-2024', 'dd-mm-yyyy'), 19748, 1, 131);
insert into WORKER_A (workerid, startdate, enddate, salary, type, citizenid)
values (5137, to_date('06-10-2014', 'dd-mm-yyyy'), to_date('25-12-2021', 'dd-mm-yyyy'), 9942, 2, 985);
insert into WORKER_A (workerid, startdate, enddate, salary, type, citizenid)
values (5138, to_date('30-11-2017', 'dd-mm-yyyy'), to_date('20-02-2023', 'dd-mm-yyyy'), 10520, 2, 896);
insert into WORKER_A (workerid, startdate, enddate, salary, type, citizenid)
values (5139, to_date('19-10-2016', 'dd-mm-yyyy'), to_date('26-12-2022', 'dd-mm-yyyy'), 17502, 2, 361);
insert into WORKER_A (workerid, startdate, enddate, salary, type, citizenid)
values (5140, to_date('14-03-2017', 'dd-mm-yyyy'), to_date('11-08-2024', 'dd-mm-yyyy'), 6387, 2, 310);
insert into WORKER_A (workerid, startdate, enddate, salary, type, citizenid)
values (5141, to_date('22-05-2012', 'dd-mm-yyyy'), to_date('08-03-2021', 'dd-mm-yyyy'), 20679, 2, 881);
insert into WORKER_A (workerid, startdate, enddate, salary, type, citizenid)
values (5142, to_date('06-07-2010', 'dd-mm-yyyy'), to_date('23-02-2022', 'dd-mm-yyyy'), 12802, 2, 82);
insert into WORKER_A (workerid, startdate, enddate, salary, type, citizenid)
values (5143, to_date('20-06-2008', 'dd-mm-yyyy'), to_date('21-09-2023', 'dd-mm-yyyy'), 10965, 1, 111);
insert into WORKER_A (workerid, startdate, enddate, salary, type, citizenid)
values (5144, to_date('13-12-2016', 'dd-mm-yyyy'), to_date('07-02-2024', 'dd-mm-yyyy'), 4552, 2, 862);
insert into WORKER_A (workerid, startdate, enddate, salary, type, citizenid)
values (5145, to_date('10-05-2011', 'dd-mm-yyyy'), to_date('20-08-2021', 'dd-mm-yyyy'), 9848, 1, 869);
insert into WORKER_A (workerid, startdate, enddate, salary, type, citizenid)
values (5146, to_date('18-02-2020', 'dd-mm-yyyy'), to_date('03-09-2023', 'dd-mm-yyyy'), 20457, 1, 831);
insert into WORKER_A (workerid, startdate, enddate, salary, type, citizenid)
values (5147, to_date('26-12-2008', 'dd-mm-yyyy'), to_date('28-10-2023', 'dd-mm-yyyy'), 7635, 2, 372);
insert into WORKER_A (workerid, startdate, enddate, salary, type, citizenid)
values (5148, to_date('24-06-2017', 'dd-mm-yyyy'), to_date('10-03-2022', 'dd-mm-yyyy'), 9542, 2, 651);
insert into WORKER_A (workerid, startdate, enddate, salary, type, citizenid)
values (5149, to_date('05-02-2017', 'dd-mm-yyyy'), to_date('15-08-2020', 'dd-mm-yyyy'), 12451, 2, 545);
insert into WORKER_A (workerid, startdate, enddate, salary, type, citizenid)
values (5150, to_date('14-07-2010', 'dd-mm-yyyy'), to_date('11-08-2025', 'dd-mm-yyyy'), 15045, 1, 886);
insert into WORKER_A (workerid, startdate, enddate, salary, type, citizenid)
values (5151, to_date('22-11-2014', 'dd-mm-yyyy'), to_date('30-06-2025', 'dd-mm-yyyy'), 19560, 2, 585);
insert into WORKER_A (workerid, startdate, enddate, salary, type, citizenid)
values (5152, to_date('29-11-2013', 'dd-mm-yyyy'), to_date('24-04-2023', 'dd-mm-yyyy'), 12403, 1, 898);
insert into WORKER_A (workerid, startdate, enddate, salary, type, citizenid)
values (5153, to_date('08-05-2009', 'dd-mm-yyyy'), to_date('28-01-2023', 'dd-mm-yyyy'), 17746, 1, 644);
insert into WORKER_A (workerid, startdate, enddate, salary, type, citizenid)
values (5154, to_date('31-10-2011', 'dd-mm-yyyy'), to_date('13-06-2020', 'dd-mm-yyyy'), 8132, 2, 857);
insert into WORKER_A (workerid, startdate, enddate, salary, type, citizenid)
values (5155, to_date('16-05-2014', 'dd-mm-yyyy'), to_date('22-12-2022', 'dd-mm-yyyy'), 14932, 1, 639);
insert into WORKER_A (workerid, startdate, enddate, salary, type, citizenid)
values (5156, to_date('05-02-2009', 'dd-mm-yyyy'), to_date('30-09-2020', 'dd-mm-yyyy'), 12811, 2, 438);
insert into WORKER_A (workerid, startdate, enddate, salary, type, citizenid)
values (5157, to_date('12-05-2019', 'dd-mm-yyyy'), to_date('03-09-2023', 'dd-mm-yyyy'), 12621, 2, 146);
insert into WORKER_A (workerid, startdate, enddate, salary, type, citizenid)
values (5158, to_date('08-09-2011', 'dd-mm-yyyy'), to_date('21-12-2020', 'dd-mm-yyyy'), 8818, 2, 503);
insert into WORKER_A (workerid, startdate, enddate, salary, type, citizenid)
values (5159, to_date('30-01-2010', 'dd-mm-yyyy'), to_date('17-06-2021', 'dd-mm-yyyy'), 6301, 1, 251);
insert into WORKER_A (workerid, startdate, enddate, salary, type, citizenid)
values (5160, to_date('04-07-2014', 'dd-mm-yyyy'), to_date('24-08-2020', 'dd-mm-yyyy'), 4749, 2, 210);
insert into WORKER_A (workerid, startdate, enddate, salary, type, citizenid)
values (5161, to_date('23-06-2010', 'dd-mm-yyyy'), to_date('29-03-2021', 'dd-mm-yyyy'), 5714, 1, 654);
insert into WORKER_A (workerid, startdate, enddate, salary, type, citizenid)
values (5162, to_date('19-12-2011', 'dd-mm-yyyy'), to_date('31-08-2022', 'dd-mm-yyyy'), 15126, 1, 140);
insert into WORKER_A (workerid, startdate, enddate, salary, type, citizenid)
values (5163, to_date('07-11-2012', 'dd-mm-yyyy'), to_date('08-12-2023', 'dd-mm-yyyy'), 17003, 2, 223);
insert into WORKER_A (workerid, startdate, enddate, salary, type, citizenid)
values (5164, to_date('03-02-2019', 'dd-mm-yyyy'), to_date('29-11-2021', 'dd-mm-yyyy'), 6715, 2, 581);
insert into WORKER_A (workerid, startdate, enddate, salary, type, citizenid)
values (5165, to_date('29-06-2009', 'dd-mm-yyyy'), to_date('15-02-2022', 'dd-mm-yyyy'), 17381, 1, 331);
insert into WORKER_A (workerid, startdate, enddate, salary, type, citizenid)
values (5166, to_date('07-09-2008', 'dd-mm-yyyy'), to_date('07-06-2022', 'dd-mm-yyyy'), 13207, 2, 921);
insert into WORKER_A (workerid, startdate, enddate, salary, type, citizenid)
values (5167, to_date('03-07-2014', 'dd-mm-yyyy'), to_date('20-05-2021', 'dd-mm-yyyy'), 12182, 2, 508);
insert into WORKER_A (workerid, startdate, enddate, salary, type, citizenid)
values (5168, to_date('04-03-2008', 'dd-mm-yyyy'), to_date('19-10-2024', 'dd-mm-yyyy'), 14671, 1, 379);
insert into WORKER_A (workerid, startdate, enddate, salary, type, citizenid)
values (5169, to_date('28-05-2008', 'dd-mm-yyyy'), to_date('06-01-2024', 'dd-mm-yyyy'), 7096, 1, 953);
insert into WORKER_A (workerid, startdate, enddate, salary, type, citizenid)
values (5170, to_date('11-01-2016', 'dd-mm-yyyy'), to_date('21-10-2024', 'dd-mm-yyyy'), 8843, 1, 952);
insert into WORKER_A (workerid, startdate, enddate, salary, type, citizenid)
values (5171, to_date('12-05-2013', 'dd-mm-yyyy'), to_date('09-04-2023', 'dd-mm-yyyy'), 11230, 1, 261);
insert into WORKER_A (workerid, startdate, enddate, salary, type, citizenid)
values (5172, to_date('28-02-2018', 'dd-mm-yyyy'), to_date('22-03-2025', 'dd-mm-yyyy'), 12461, 1, 732);
insert into WORKER_A (workerid, startdate, enddate, salary, type, citizenid)
values (5173, to_date('05-09-2015', 'dd-mm-yyyy'), to_date('19-06-2023', 'dd-mm-yyyy'), 20397, 2, 861);
insert into WORKER_A (workerid, startdate, enddate, salary, type, citizenid)
values (5174, to_date('12-02-2010', 'dd-mm-yyyy'), to_date('23-01-2024', 'dd-mm-yyyy'), 12201, 1, 507);
insert into WORKER_A (workerid, startdate, enddate, salary, type, citizenid)
values (5175, to_date('02-02-2020', 'dd-mm-yyyy'), to_date('18-06-2021', 'dd-mm-yyyy'), 8998, 1, 274);
insert into WORKER_A (workerid, startdate, enddate, salary, type, citizenid)
values (5176, to_date('09-06-2017', 'dd-mm-yyyy'), to_date('13-09-2025', 'dd-mm-yyyy'), 16903, 1, 75);
insert into WORKER_A (workerid, startdate, enddate, salary, type, citizenid)
values (5177, to_date('16-09-2018', 'dd-mm-yyyy'), to_date('22-08-2024', 'dd-mm-yyyy'), 13944, 1, 875);
insert into WORKER_A (workerid, startdate, enddate, salary, type, citizenid)
values (5178, to_date('02-12-2018', 'dd-mm-yyyy'), to_date('19-07-2024', 'dd-mm-yyyy'), 9324, 1, 795);
insert into WORKER_A (workerid, startdate, enddate, salary, type, citizenid)
values (5179, to_date('04-11-2011', 'dd-mm-yyyy'), to_date('09-03-2022', 'dd-mm-yyyy'), 21616, 2, 496);
insert into WORKER_A (workerid, startdate, enddate, salary, type, citizenid)
values (5180, to_date('19-02-2015', 'dd-mm-yyyy'), to_date('13-10-2022', 'dd-mm-yyyy'), 13285, 1, 933);
insert into WORKER_A (workerid, startdate, enddate, salary, type, citizenid)
values (5181, to_date('12-06-2019', 'dd-mm-yyyy'), to_date('29-09-2022', 'dd-mm-yyyy'), 9814, 2, 454);
insert into WORKER_A (workerid, startdate, enddate, salary, type, citizenid)
values (5182, to_date('05-09-2016', 'dd-mm-yyyy'), to_date('05-07-2023', 'dd-mm-yyyy'), 12312, 2, 37);
insert into WORKER_A (workerid, startdate, enddate, salary, type, citizenid)
values (5183, to_date('16-11-2016', 'dd-mm-yyyy'), to_date('26-02-2025', 'dd-mm-yyyy'), 19269, 2, 539);
insert into WORKER_A (workerid, startdate, enddate, salary, type, citizenid)
values (5184, to_date('02-02-2008', 'dd-mm-yyyy'), to_date('01-06-2021', 'dd-mm-yyyy'), 19484, 2, 352);
insert into WORKER_A (workerid, startdate, enddate, salary, type, citizenid)
values (5185, to_date('30-03-2010', 'dd-mm-yyyy'), to_date('25-07-2020', 'dd-mm-yyyy'), 10594, 2, 659);
insert into WORKER_A (workerid, startdate, enddate, salary, type, citizenid)
values (5186, to_date('08-11-2016', 'dd-mm-yyyy'), to_date('28-06-2021', 'dd-mm-yyyy'), 14675, 2, 832);
insert into WORKER_A (workerid, startdate, enddate, salary, type, citizenid)
values (5187, to_date('17-04-2018', 'dd-mm-yyyy'), to_date('05-12-2025', 'dd-mm-yyyy'), 16769, 2, 353);
insert into WORKER_A (workerid, startdate, enddate, salary, type, citizenid)
values (5188, to_date('08-07-2012', 'dd-mm-yyyy'), to_date('14-02-2022', 'dd-mm-yyyy'), 17415, 1, 61);
insert into WORKER_A (workerid, startdate, enddate, salary, type, citizenid)
values (5189, to_date('10-07-2008', 'dd-mm-yyyy'), to_date('04-12-2020', 'dd-mm-yyyy'), 11396, 1, 703);
insert into WORKER_A (workerid, startdate, enddate, salary, type, citizenid)
values (5190, to_date('28-09-2015', 'dd-mm-yyyy'), to_date('13-11-2020', 'dd-mm-yyyy'), 6819, 1, 34);
insert into WORKER_A (workerid, startdate, enddate, salary, type, citizenid)
values (5191, to_date('26-03-2014', 'dd-mm-yyyy'), to_date('22-11-2023', 'dd-mm-yyyy'), 21278, 2, 484);
insert into WORKER_A (workerid, startdate, enddate, salary, type, citizenid)
values (5192, to_date('13-01-2008', 'dd-mm-yyyy'), to_date('26-01-2023', 'dd-mm-yyyy'), 17042, 1, 757);
insert into WORKER_A (workerid, startdate, enddate, salary, type, citizenid)
values (5193, to_date('22-02-2011', 'dd-mm-yyyy'), to_date('31-10-2022', 'dd-mm-yyyy'), 17366, 1, 150);
insert into WORKER_A (workerid, startdate, enddate, salary, type, citizenid)
values (5194, to_date('03-03-2013', 'dd-mm-yyyy'), to_date('04-08-2024', 'dd-mm-yyyy'), 13131, 2, 641);
insert into WORKER_A (workerid, startdate, enddate, salary, type, citizenid)
values (5195, to_date('19-04-2016', 'dd-mm-yyyy'), to_date('08-05-2025', 'dd-mm-yyyy'), 9005, 2, 592);
insert into WORKER_A (workerid, startdate, enddate, salary, type, citizenid)
values (5196, to_date('16-05-2009', 'dd-mm-yyyy'), to_date('16-10-2024', 'dd-mm-yyyy'), 18662, 2, 94);
insert into WORKER_A (workerid, startdate, enddate, salary, type, citizenid)
values (5197, to_date('07-01-2018', 'dd-mm-yyyy'), to_date('30-07-2022', 'dd-mm-yyyy'), 15788, 2, 47);
insert into WORKER_A (workerid, startdate, enddate, salary, type, citizenid)
values (5198, to_date('27-12-2016', 'dd-mm-yyyy'), to_date('28-09-2020', 'dd-mm-yyyy'), 8644, 1, 423);
insert into WORKER_A (workerid, startdate, enddate, salary, type, citizenid)
values (5199, to_date('23-05-2019', 'dd-mm-yyyy'), to_date('28-05-2021', 'dd-mm-yyyy'), 17246, 2, 154);
insert into WORKER_A (workerid, startdate, enddate, salary, type, citizenid)
values (5200, to_date('04-11-2012', 'dd-mm-yyyy'), to_date('09-01-2021', 'dd-mm-yyyy'), 21688, 2, 252);
insert into WORKER_A (workerid, startdate, enddate, salary, type, citizenid)
values (5201, to_date('16-12-2016', 'dd-mm-yyyy'), to_date('05-08-2022', 'dd-mm-yyyy'), 18386, 2, 547);
insert into WORKER_A (workerid, startdate, enddate, salary, type, citizenid)
values (5202, to_date('27-07-2015', 'dd-mm-yyyy'), to_date('11-09-2023', 'dd-mm-yyyy'), 9737, 1, 269);
insert into WORKER_A (workerid, startdate, enddate, salary, type, citizenid)
values (5203, to_date('09-06-2016', 'dd-mm-yyyy'), to_date('16-02-2022', 'dd-mm-yyyy'), 10582, 2, 513);
insert into WORKER_A (workerid, startdate, enddate, salary, type, citizenid)
values (5204, to_date('16-04-2014', 'dd-mm-yyyy'), to_date('06-01-2022', 'dd-mm-yyyy'), 16635, 1, 189);
insert into WORKER_A (workerid, startdate, enddate, salary, type, citizenid)
values (5205, to_date('05-01-2011', 'dd-mm-yyyy'), to_date('05-03-2024', 'dd-mm-yyyy'), 5899, 1, 809);
insert into WORKER_A (workerid, startdate, enddate, salary, type, citizenid)
values (5206, to_date('04-07-2017', 'dd-mm-yyyy'), to_date('28-08-2020', 'dd-mm-yyyy'), 7845, 2, 500);
insert into WORKER_A (workerid, startdate, enddate, salary, type, citizenid)
values (5207, to_date('23-07-2010', 'dd-mm-yyyy'), to_date('07-07-2023', 'dd-mm-yyyy'), 12616, 2, 703);
insert into WORKER_A (workerid, startdate, enddate, salary, type, citizenid)
values (5208, to_date('19-01-2013', 'dd-mm-yyyy'), to_date('01-01-2024', 'dd-mm-yyyy'), 9549, 2, 940);
insert into WORKER_A (workerid, startdate, enddate, salary, type, citizenid)
values (5209, to_date('11-04-2011', 'dd-mm-yyyy'), to_date('30-09-2020', 'dd-mm-yyyy'), 7541, 1, 230);
insert into WORKER_A (workerid, startdate, enddate, salary, type, citizenid)
values (5210, to_date('10-06-2012', 'dd-mm-yyyy'), to_date('27-07-2025', 'dd-mm-yyyy'), 13655, 2, 613);
insert into WORKER_A (workerid, startdate, enddate, salary, type, citizenid)
values (5211, to_date('19-05-2017', 'dd-mm-yyyy'), to_date('22-12-2024', 'dd-mm-yyyy'), 9049, 2, 727);
insert into WORKER_A (workerid, startdate, enddate, salary, type, citizenid)
values (5212, to_date('21-10-2018', 'dd-mm-yyyy'), to_date('23-03-2024', 'dd-mm-yyyy'), 6580, 1, 566);
insert into WORKER_A (workerid, startdate, enddate, salary, type, citizenid)
values (5213, to_date('13-03-2008', 'dd-mm-yyyy'), to_date('30-11-2020', 'dd-mm-yyyy'), 12421, 1, 298);
insert into WORKER_A (workerid, startdate, enddate, salary, type, citizenid)
values (5214, to_date('13-05-2020', 'dd-mm-yyyy'), to_date('20-12-2024', 'dd-mm-yyyy'), 15736, 1, 212);
insert into WORKER_A (workerid, startdate, enddate, salary, type, citizenid)
values (5215, to_date('01-05-2016', 'dd-mm-yyyy'), to_date('11-04-2021', 'dd-mm-yyyy'), 14479, 1, 192);
insert into WORKER_A (workerid, startdate, enddate, salary, type, citizenid)
values (5216, to_date('04-03-2019', 'dd-mm-yyyy'), to_date('14-12-2025', 'dd-mm-yyyy'), 16921, 2, 616);
insert into WORKER_A (workerid, startdate, enddate, salary, type, citizenid)
values (5217, to_date('15-12-2011', 'dd-mm-yyyy'), to_date('31-10-2025', 'dd-mm-yyyy'), 8545, 2, 631);
insert into WORKER_A (workerid, startdate, enddate, salary, type, citizenid)
values (5218, to_date('17-02-2015', 'dd-mm-yyyy'), to_date('20-07-2020', 'dd-mm-yyyy'), 4100, 1, 97);
insert into WORKER_A (workerid, startdate, enddate, salary, type, citizenid)
values (5219, to_date('09-03-2011', 'dd-mm-yyyy'), to_date('13-07-2022', 'dd-mm-yyyy'), 15734, 2, 494);
insert into WORKER_A (workerid, startdate, enddate, salary, type, citizenid)
values (5220, to_date('10-02-2018', 'dd-mm-yyyy'), to_date('02-12-2023', 'dd-mm-yyyy'), 10845, 1, 214);
insert into WORKER_A (workerid, startdate, enddate, salary, type, citizenid)
values (5221, to_date('07-09-2019', 'dd-mm-yyyy'), to_date('22-10-2020', 'dd-mm-yyyy'), 17457, 1, 967);
insert into WORKER_A (workerid, startdate, enddate, salary, type, citizenid)
values (5222, to_date('07-11-2019', 'dd-mm-yyyy'), to_date('02-11-2022', 'dd-mm-yyyy'), 15636, 2, 745);
insert into WORKER_A (workerid, startdate, enddate, salary, type, citizenid)
values (5223, to_date('14-11-2015', 'dd-mm-yyyy'), to_date('03-05-2023', 'dd-mm-yyyy'), 13112, 2, 958);
insert into WORKER_A (workerid, startdate, enddate, salary, type, citizenid)
values (5224, to_date('11-11-2009', 'dd-mm-yyyy'), to_date('24-07-2023', 'dd-mm-yyyy'), 8039, 2, 122);
insert into WORKER_A (workerid, startdate, enddate, salary, type, citizenid)
values (5225, to_date('04-11-2018', 'dd-mm-yyyy'), to_date('02-10-2025', 'dd-mm-yyyy'), 15146, 2, 187);
insert into WORKER_A (workerid, startdate, enddate, salary, type, citizenid)
values (5226, to_date('26-02-2017', 'dd-mm-yyyy'), to_date('10-11-2024', 'dd-mm-yyyy'), 18901, 1, 676);
insert into WORKER_A (workerid, startdate, enddate, salary, type, citizenid)
values (5227, to_date('03-01-2008', 'dd-mm-yyyy'), to_date('20-02-2022', 'dd-mm-yyyy'), 7344, 1, 615);
insert into WORKER_A (workerid, startdate, enddate, salary, type, citizenid)
values (5228, to_date('21-01-2017', 'dd-mm-yyyy'), to_date('18-11-2025', 'dd-mm-yyyy'), 7969, 2, 401);
insert into WORKER_A (workerid, startdate, enddate, salary, type, citizenid)
values (5229, to_date('20-10-2014', 'dd-mm-yyyy'), to_date('28-06-2021', 'dd-mm-yyyy'), 12288, 2, 641);
insert into WORKER_A (workerid, startdate, enddate, salary, type, citizenid)
values (5230, to_date('02-06-2015', 'dd-mm-yyyy'), to_date('20-02-2025', 'dd-mm-yyyy'), 18237, 1, 430);
insert into WORKER_A (workerid, startdate, enddate, salary, type, citizenid)
values (5231, to_date('06-11-2019', 'dd-mm-yyyy'), to_date('28-10-2025', 'dd-mm-yyyy'), 18649, 1, 538);
insert into WORKER_A (workerid, startdate, enddate, salary, type, citizenid)
values (5232, to_date('11-05-2014', 'dd-mm-yyyy'), to_date('17-11-2022', 'dd-mm-yyyy'), 18488, 2, 516);
insert into WORKER_A (workerid, startdate, enddate, salary, type, citizenid)
values (5233, to_date('25-11-2011', 'dd-mm-yyyy'), to_date('03-09-2022', 'dd-mm-yyyy'), 13442, 2, 339);
insert into WORKER_A (workerid, startdate, enddate, salary, type, citizenid)
values (5234, to_date('08-06-2019', 'dd-mm-yyyy'), to_date('12-08-2025', 'dd-mm-yyyy'), 5675, 2, 145);
insert into WORKER_A (workerid, startdate, enddate, salary, type, citizenid)
values (5235, to_date('20-02-2018', 'dd-mm-yyyy'), to_date('21-08-2020', 'dd-mm-yyyy'), 12699, 2, 896);
insert into WORKER_A (workerid, startdate, enddate, salary, type, citizenid)
values (5236, to_date('24-12-2008', 'dd-mm-yyyy'), to_date('03-12-2021', 'dd-mm-yyyy'), 11401, 1, 3);
insert into WORKER_A (workerid, startdate, enddate, salary, type, citizenid)
values (5237, to_date('01-11-2016', 'dd-mm-yyyy'), to_date('23-03-2022', 'dd-mm-yyyy'), 11260, 2, 801);
insert into WORKER_A (workerid, startdate, enddate, salary, type, citizenid)
values (5238, to_date('30-01-2017', 'dd-mm-yyyy'), to_date('23-10-2020', 'dd-mm-yyyy'), 5602, 2, 962);
insert into WORKER_A (workerid, startdate, enddate, salary, type, citizenid)
values (5239, to_date('10-06-2009', 'dd-mm-yyyy'), to_date('11-11-2025', 'dd-mm-yyyy'), 8869, 2, 165);
insert into WORKER_A (workerid, startdate, enddate, salary, type, citizenid)
values (5240, to_date('02-10-2018', 'dd-mm-yyyy'), to_date('09-01-2024', 'dd-mm-yyyy'), 16225, 2, 56);
insert into WORKER_A (workerid, startdate, enddate, salary, type, citizenid)
values (5241, to_date('05-03-2012', 'dd-mm-yyyy'), to_date('16-12-2024', 'dd-mm-yyyy'), 14340, 2, 603);
insert into WORKER_A (workerid, startdate, enddate, salary, type, citizenid)
values (5242, to_date('30-08-2009', 'dd-mm-yyyy'), to_date('08-11-2023', 'dd-mm-yyyy'), 11650, 1, 760);
insert into WORKER_A (workerid, startdate, enddate, salary, type, citizenid)
values (5243, to_date('15-03-2016', 'dd-mm-yyyy'), to_date('23-04-2024', 'dd-mm-yyyy'), 20585, 1, 162);
insert into WORKER_A (workerid, startdate, enddate, salary, type, citizenid)
values (5244, to_date('11-04-2014', 'dd-mm-yyyy'), to_date('14-10-2021', 'dd-mm-yyyy'), 9833, 1, 641);
insert into WORKER_A (workerid, startdate, enddate, salary, type, citizenid)
values (5245, to_date('28-04-2012', 'dd-mm-yyyy'), to_date('11-12-2020', 'dd-mm-yyyy'), 21793, 1, 937);
insert into WORKER_A (workerid, startdate, enddate, salary, type, citizenid)
values (5246, to_date('24-06-2017', 'dd-mm-yyyy'), to_date('21-08-2025', 'dd-mm-yyyy'), 15790, 1, 926);
insert into WORKER_A (workerid, startdate, enddate, salary, type, citizenid)
values (5247, to_date('26-10-2018', 'dd-mm-yyyy'), to_date('13-11-2022', 'dd-mm-yyyy'), 4124, 2, 814);
insert into WORKER_A (workerid, startdate, enddate, salary, type, citizenid)
values (5248, to_date('02-12-2018', 'dd-mm-yyyy'), to_date('13-12-2022', 'dd-mm-yyyy'), 20233, 1, 996);
insert into WORKER_A (workerid, startdate, enddate, salary, type, citizenid)
values (5249, to_date('04-06-2019', 'dd-mm-yyyy'), to_date('29-02-2024', 'dd-mm-yyyy'), 6121, 1, 702);
prompt 250 records loaded
prompt Enabling foreign key constraints for WORKER_A...
alter table WORKER_A enable constraint SYS_C007451;
prompt Enabling triggers for WORKER_A...
alter table WORKER_A enable all triggers;

set feedback on
set define on
prompt Done
