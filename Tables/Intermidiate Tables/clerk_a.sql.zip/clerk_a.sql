?��prompt PL/SQL Developer Export Tables for user SYSTEM
prompt Created by Evyatar on יום שני 10 אוגוסט 2020
set feedback off
set define off

prompt Creating CLERK_A...
create table CLERK_A
(
  salary    FLOAT not null,
  bossid    INTEGER not null,
  hireyear  DATE not null,
  rating    INTEGER not null,
  areaid    INTEGER not null,
  clerkname VARCHAR2(32) not null,
  clerkid   INTEGER not null
)
tablespace SYSTEM
  pctfree 10
  pctused 40
  initrans 1
  maxtrans 255
  storage
  (
    initial 64K
    next 1M
    minextents 1
    maxextents unlimited
  );
alter table CLERK_A
  add primary key (CLERKID)
  disable
  novalidate;
alter table CLERK_A
  add foreign key (AREAID)
  references AREA (AREAID)
  disable
  novalidate;

prompt Disabling triggers for CLERK_A...
alter table CLERK_A disable all triggers;
prompt Deleting CLERK_A...
delete from CLERK_A;
prompt Loading CLERK_A...
insert into CLERK_A (salary, bossid, hireyear, rating, areaid, clerkname, clerkid)
values (7293, 20006, to_date('25-07-2008', 'dd-mm-yyyy'), 6, 21, 'Emily Farrow', 1);
insert into CLERK_A (salary, bossid, hireyear, rating, areaid, clerkname, clerkid)
values (7866, 20009, to_date('24-02-2018', 'dd-mm-yyyy'), 6, 22, 'Arnold Singletary', 2);
insert into CLERK_A (salary, bossid, hireyear, rating, areaid, clerkname, clerkid)
values (11702, 20001, to_date('23-12-2008', 'dd-mm-yyyy'), 6, 23, 'Rose Mraz', 3);
insert into CLERK_A (salary, bossid, hireyear, rating, areaid, clerkname, clerkid)
values (9295, 20001, to_date('05-09-2018', 'dd-mm-yyyy'), 10, 24, 'Melanie Michael', 4);
insert into CLERK_A (salary, bossid, hireyear, rating, areaid, clerkname, clerkid)
values (10445, 20001, to_date('26-05-2011', 'dd-mm-yyyy'), 6, 25, 'Bobbi Loveless', 5);
insert into CLERK_A (salary, bossid, hireyear, rating, areaid, clerkname, clerkid)
values (7531, 20004, to_date('02-08-2012', 'dd-mm-yyyy'), 4, 26, 'Ernie Parm', 6);
insert into CLERK_A (salary, bossid, hireyear, rating, areaid, clerkname, clerkid)
values (8295, 20008, to_date('30-10-2018', 'dd-mm-yyyy'), 7, 27, 'Spike Stiles', 7);
insert into CLERK_A (salary, bossid, hireyear, rating, areaid, clerkname, clerkid)
values (5737, 20003, to_date('11-11-2012', 'dd-mm-yyyy'), 4, 28, 'Danni Santana', 8);
insert into CLERK_A (salary, bossid, hireyear, rating, areaid, clerkname, clerkid)
values (9848, 20005, to_date('10-05-2011', 'dd-mm-yyyy'), 5, 29, 'Billy Schwimmer', 9);
insert into CLERK_A (salary, bossid, hireyear, rating, areaid, clerkname, clerkid)
values (5766, 20010, to_date('23-10-2015', 'dd-mm-yyyy'), 4, 30, 'Daryle Downie', 10);
prompt 10 records loaded
prompt Enabling triggers for CLERK_A...
alter table CLERK_A enable all triggers;

set feedback on
set define on
prompt Done
