?��prompt PL/SQL Developer Export Tables for user SYSTEM
prompt Created by Evyatar on יום שני 10 אוגוסט 2020
set feedback off
set define off

prompt Creating CITIZEN_B...
create table CITIZEN_B
(
  citizenid   NUMBER(9) not null,
  citizenname VARCHAR2(50) not null,
  phonenumber VARCHAR2(15) not null,
  address     VARCHAR2(50) not null,
  cityid      NUMBER(3) not null
)
tablespace SYSTEM
  pctfree 10
  pctused 40
  initrans 1
  maxtrans 255
  storage
  (
    initial 64K
    next 1M
    minextents 1
    maxextents unlimited
  );
alter table CITIZEN_B
  add primary key (CITIZENID)
  using index 
  tablespace SYSTEM
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 64K
    next 1M
    minextents 1
    maxextents unlimited
  );
alter table CITIZEN_B
  add foreign key (CITYID)
  references CITY_B (CITYID);

prompt Disabling triggers for CITIZEN_B...
alter table CITIZEN_B disable all triggers;
prompt Disabling foreign key constraints for CITIZEN_B...
alter table CITIZEN_B disable constraint SYS_C007328;
prompt Deleting CITIZEN_B...
delete from CITIZEN_B;
prompt Loading CITIZEN_B...
insert into CITIZEN_B (citizenid, citizenname, phonenumber, address, cityid)
values (708262840, 'Diamond Olson', '(681) 485-9113', '61 Beach Avenue', 100);
insert into CITIZEN_B (citizenid, citizenname, phonenumber, address, cityid)
values (189811489, 'Maritza Marks', '(640) 612-8540', '107 Pegasus Street', 101);
insert into CITIZEN_B (citizenid, citizenname, phonenumber, address, cityid)
values (467351472, 'Kennedy Chen', '(887) 507-7157', '82 Judge Avenue', 102);
insert into CITIZEN_B (citizenid, citizenname, phonenumber, address, cityid)
values (152874477, 'Anthony Davila', '(640) 927-4303', '25 Mason Row', 103);
insert into CITIZEN_B (citizenid, citizenname, phonenumber, address, cityid)
values (590564086, 'Payton Sloan', '(363) 800-8519', '14 Hope Row', 104);
insert into CITIZEN_B (citizenid, citizenname, phonenumber, address, cityid)
values (945582077, 'Jeramiah Yu', '(322) 423-4859', '84 Penrose Route', 105);
insert into CITIZEN_B (citizenid, citizenname, phonenumber, address, cityid)
values (79504732, 'Gloria Hoffman', '(953) 773-4315', '113 Barley Row', 106);
insert into CITIZEN_B (citizenid, citizenname, phonenumber, address, cityid)
values (780946586, 'Abel Hansen', '(889) 938-3601', '39 Peace Route', 107);
insert into CITIZEN_B (citizenid, citizenname, phonenumber, address, cityid)
values (375972455, 'Amiya Drake', '(915) 878-9537', '47 Hazelnut Avenue', 108);
insert into CITIZEN_B (citizenid, citizenname, phonenumber, address, cityid)
values (971633137, 'Anna Velez', '(326) 862-3195', '3 Noble Avenue', 109);
insert into CITIZEN_B (citizenid, citizenname, phonenumber, address, cityid)
values (202710130, 'Iyana Meza', '(635) 461-7619', '73 Medieval Lane', 110);
insert into CITIZEN_B (citizenid, citizenname, phonenumber, address, cityid)
values (936814527, 'Johnathon Barnes', '(511) 920-0300', '113 Ivy Avenue', 111);
insert into CITIZEN_B (citizenid, citizenname, phonenumber, address, cityid)
values (618144212, 'Shaniya Dominguez', '(761) 894-1572', '77 Fox Street', 112);
insert into CITIZEN_B (citizenid, citizenname, phonenumber, address, cityid)
values (330927664, 'Bentley Hunter', '(544) 903-0344', '111 Lily Route', 113);
insert into CITIZEN_B (citizenid, citizenname, phonenumber, address, cityid)
values (850965499, 'Madyson Bradley', '(305) 897-2762', '77 Bright Passage', 114);
insert into CITIZEN_B (citizenid, citizenname, phonenumber, address, cityid)
values (121670810, 'Aiyana Hahn', '(874) 698-3483', '57 Storm Lane', 115);
insert into CITIZEN_B (citizenid, citizenname, phonenumber, address, cityid)
values (591829232, 'Zechariah Moran', '(362) 629-4653', '45 Seaview Passage', 116);
insert into CITIZEN_B (citizenid, citizenname, phonenumber, address, cityid)
values (523479830, 'Eliza Smith', '(897) 985-3936', '33 Frost Avenue', 117);
insert into CITIZEN_B (citizenid, citizenname, phonenumber, address, cityid)
values (972999281, 'Janae Nicholson', '(446) 871-4078', '44 Nightingale Avenue', 118);
insert into CITIZEN_B (citizenid, citizenname, phonenumber, address, cityid)
values (869593414, 'Sarahi Wagner', '(588) 363-6336', '67 Locust Street', 119);
insert into CITIZEN_B (citizenid, citizenname, phonenumber, address, cityid)
values (364323076, 'Fatima Livingston', '(797) 334-1333', '88 King Boulevard', 120);
insert into CITIZEN_B (citizenid, citizenname, phonenumber, address, cityid)
values (456295284, 'Ashleigh Winters', '(291) 680-4955', '102 East Avenue', 121);
insert into CITIZEN_B (citizenid, citizenname, phonenumber, address, cityid)
values (486877093, 'Clayton Shah', '(438) 398-3822', '35 Shade Route', 122);
insert into CITIZEN_B (citizenid, citizenname, phonenumber, address, cityid)
values (850636732, 'Emilia Bautista', '(672) 836-5328', '67 Clarity Row', 123);
insert into CITIZEN_B (citizenid, citizenname, phonenumber, address, cityid)
values (670150291, 'Martin Hodges', '(969) 528-3764', '90 Flax Street', 124);
insert into CITIZEN_B (citizenid, citizenname, phonenumber, address, cityid)
values (345108322, 'Carlie Avery', '(837) 213-1474', '66 Nightingale Row', 125);
insert into CITIZEN_B (citizenid, citizenname, phonenumber, address, cityid)
values (49629406, 'Mayra Mcgee', '(465) 501-2208', '29 Archer Lane', 126);
insert into CITIZEN_B (citizenid, citizenname, phonenumber, address, cityid)
values (996662084, 'Kelly Murphy', '(280) 346-4131', '68 Beech Route', 127);
insert into CITIZEN_B (citizenid, citizenname, phonenumber, address, cityid)
values (482818846, 'Messiah Mercer', '(506) 310-6753', '73 Victory Boulevard', 128);
insert into CITIZEN_B (citizenid, citizenname, phonenumber, address, cityid)
values (385892708, 'Libby Brady', '(371) 532-6213', '68 Sunshine Boulevard', 129);
insert into CITIZEN_B (citizenid, citizenname, phonenumber, address, cityid)
values (113899307, 'Reynaldo Lucero', '(376) 470-6332', '64 Apollo Passage', 130);
insert into CITIZEN_B (citizenid, citizenname, phonenumber, address, cityid)
values (19214993, 'Rowan Walters', '(990) 951-3708', '49 Kingwood Avenue', 131);
insert into CITIZEN_B (citizenid, citizenname, phonenumber, address, cityid)
values (640808719, 'Rohan Patel', '(646) 942-2650', '84 Greenfield Boulevard', 132);
insert into CITIZEN_B (citizenid, citizenname, phonenumber, address, cityid)
values (464600526, 'Paxton Rogers', '(860) 723-4516', '75 Starlight Avenue', 133);
insert into CITIZEN_B (citizenid, citizenname, phonenumber, address, cityid)
values (191386480, 'Alexis Bean', '(766) 620-8862', '76 Sunny Street', 134);
insert into CITIZEN_B (citizenid, citizenname, phonenumber, address, cityid)
values (287878005, 'Tiara Wilkinson', '(571) 568-9706', '95 Knight Lane', 135);
insert into CITIZEN_B (citizenid, citizenname, phonenumber, address, cityid)
values (754030724, 'Taniya Best', '(727) 486-2616', '11 Moonlight Way', 136);
insert into CITIZEN_B (citizenid, citizenname, phonenumber, address, cityid)
values (698473099, 'Kristian Perkins', '(241) 712-1121', '65 Storm Way', 137);
insert into CITIZEN_B (citizenid, citizenname, phonenumber, address, cityid)
values (111413768, 'Daniella Ballard', '(908) 533-5728', '83 Aurora Street', 138);
insert into CITIZEN_B (citizenid, citizenname, phonenumber, address, cityid)
values (671660675, 'Bridger Nicholson', '(477) 741-3982', '101 Champion Boulevard', 139);
insert into CITIZEN_B (citizenid, citizenname, phonenumber, address, cityid)
values (892580017, 'Tanner Velazquez', '(243) 828-0882', '49 Hart Row', 140);
insert into CITIZEN_B (citizenid, citizenname, phonenumber, address, cityid)
values (903626083, 'Kadyn Parker', '(490) 332-1815', '108 Beech Avenue', 141);
insert into CITIZEN_B (citizenid, citizenname, phonenumber, address, cityid)
values (620937216, 'Ernesto Crane', '(527) 637-2468', '108 Sunshine Row', 142);
insert into CITIZEN_B (citizenid, citizenname, phonenumber, address, cityid)
values (908000615, 'Alma Benson', '(468) 917-8598', '82 Spring Avenue', 143);
insert into CITIZEN_B (citizenid, citizenname, phonenumber, address, cityid)
values (724134639, 'Marie Barton', '(626) 986-0157', '49 Merchant Street', 144);
insert into CITIZEN_B (citizenid, citizenname, phonenumber, address, cityid)
values (985907107, 'Lilyana Lamb', '(940) 472-6389', '110 Achorage Street', 145);
insert into CITIZEN_B (citizenid, citizenname, phonenumber, address, cityid)
values (726919780, 'Lewis Stewart', '(730) 384-0925', '115 Knight Boulevard', 146);
insert into CITIZEN_B (citizenid, citizenname, phonenumber, address, cityid)
values (412079807, 'Alonso Washington', '(223) 511-1080', '55 Cathedral Street', 147);
insert into CITIZEN_B (citizenid, citizenname, phonenumber, address, cityid)
values (709915279, 'Aiyana Russo', '(437) 246-9151', '11 Palm Street', 148);
insert into CITIZEN_B (citizenid, citizenname, phonenumber, address, cityid)
values (434940113, 'Jaylon Mills', '(202) 987-5836', '80 Archer Route', 149);
insert into CITIZEN_B (citizenid, citizenname, phonenumber, address, cityid)
values (291741163, 'Drew Love', '(202) 878-9980', '77 General Street', 110);
insert into CITIZEN_B (citizenid, citizenname, phonenumber, address, cityid)
values (426148194, 'Denisse Ball', '(579) 989-1843', '2 West Row', 111);
insert into CITIZEN_B (citizenid, citizenname, phonenumber, address, cityid)
values (64526097, 'Lia Michael', '(952) 885-8891', '112 Champion Way', 112);
insert into CITIZEN_B (citizenid, citizenname, phonenumber, address, cityid)
values (603338542, 'Esteban Frederick', '(578) 921-4734', '24 Circus Boulevard', 113);
insert into CITIZEN_B (citizenid, citizenname, phonenumber, address, cityid)
values (784600813, 'Addyson Farley', '(923) 746-5945', '51 Ember Street', 114);
insert into CITIZEN_B (citizenid, citizenname, phonenumber, address, cityid)
values (70822249, 'Peyton Griffith', '(809) 797-1096', '48 Harbor Avenue', 115);
insert into CITIZEN_B (citizenid, citizenname, phonenumber, address, cityid)
values (70831716, 'Ronan Holmes', '(553) 207-6160', '31 Archer Lane', 116);
insert into CITIZEN_B (citizenid, citizenname, phonenumber, address, cityid)
values (751988735, 'Heidy Cruz', '(770) 434-7266', '30 Willow Way', 117);
insert into CITIZEN_B (citizenid, citizenname, phonenumber, address, cityid)
values (365963339, 'Miracle Gould', '(658) 950-6485', '21 Old Lane', 118);
insert into CITIZEN_B (citizenid, citizenname, phonenumber, address, cityid)
values (648911084, 'Gunnar Barr', '(309) 615-5237', '7 Senna Row', 141);
insert into CITIZEN_B (citizenid, citizenname, phonenumber, address, cityid)
values (185000152, 'Chana Meadows', '(833) 811-2588', '62 Tower Row', 142);
insert into CITIZEN_B (citizenid, citizenname, phonenumber, address, cityid)
values (710935253, 'Olivia Duncan', '(841) 486-2290', '111 Barley Avenue', 143);
insert into CITIZEN_B (citizenid, citizenname, phonenumber, address, cityid)
values (293713935, 'Kolten Clarke', '(893) 528-2309', '9 Prince Street', 144);
insert into CITIZEN_B (citizenid, citizenname, phonenumber, address, cityid)
values (63271602, 'Milagros Hill', '(740) 275-8298', '40 Beaver Lane', 145);
insert into CITIZEN_B (citizenid, citizenname, phonenumber, address, cityid)
values (326413904, 'Libby Dickson', '(625) 579-6590', '28 Cliff Avenue', 146);
insert into CITIZEN_B (citizenid, citizenname, phonenumber, address, cityid)
values (360147273, 'Kiley Compton', '(399) 339-4007', '74 Anchor Route', 143);
insert into CITIZEN_B (citizenid, citizenname, phonenumber, address, cityid)
values (792958079, 'Phoenix Mcdowell', '(775) 470-2012', '86 Union Avenue', 144);
insert into CITIZEN_B (citizenid, citizenname, phonenumber, address, cityid)
values (642196831, 'Taryn Bridges', '(713) 375-2755', '115 Moon Lane', 145);
insert into CITIZEN_B (citizenid, citizenname, phonenumber, address, cityid)
values (187988627, 'Elsie Black', '(648) 822-3256', '88 Kings Boulevard', 146);
insert into CITIZEN_B (citizenid, citizenname, phonenumber, address, cityid)
values (211681471, 'Bruce Meyer', '(964) 549-4644', '91 Berry Row', 147);
insert into CITIZEN_B (citizenid, citizenname, phonenumber, address, cityid)
values (503126262, 'Teagan Fritz', '(863) 209-0900', '87 Oval Boulevard', 148);
insert into CITIZEN_B (citizenid, citizenname, phonenumber, address, cityid)
values (437511476, 'Alfredo Cline', '(300) 477-8871', '6 South Lane', 149);
insert into CITIZEN_B (citizenid, citizenname, phonenumber, address, cityid)
values (991978392, 'Alvin Alvarez', '(688) 423-0740', '57 Broom Row', 110);
insert into CITIZEN_B (citizenid, citizenname, phonenumber, address, cityid)
values (897773040, 'Cayden Henry', '(873) 742-8711', '39 Ocean Avenue', 128);
insert into CITIZEN_B (citizenid, citizenname, phonenumber, address, cityid)
values (206683768, 'Iyana Paul', '(649) 590-8167', '94 Colonel Passage', 129);
insert into CITIZEN_B (citizenid, citizenname, phonenumber, address, cityid)
values (779945885, 'Haiden Shepard', '(244) 246-4486', '76 Storm Street', 130);
insert into CITIZEN_B (citizenid, citizenname, phonenumber, address, cityid)
values (726563582, 'Braden Summers', '(959) 747-1142', '8 Garden Boulevard', 131);
insert into CITIZEN_B (citizenid, citizenname, phonenumber, address, cityid)
values (156171593, 'James Nichols', '(543) 926-5707', '15 Haven Avenue', 132);
insert into CITIZEN_B (citizenid, citizenname, phonenumber, address, cityid)
values (171910180, 'Damien Hess', '(293) 978-4218', '92 Penrose Avenue', 133);
insert into CITIZEN_B (citizenid, citizenname, phonenumber, address, cityid)
values (388283660, 'Joselyn Chan', '(276) 550-7416', '77 Fair Avenue', 134);
insert into CITIZEN_B (citizenid, citizenname, phonenumber, address, cityid)
values (18795929, 'Serena Klein', '(679) 870-5170', '63 Globe Way', 135);
insert into CITIZEN_B (citizenid, citizenname, phonenumber, address, cityid)
values (856592056, 'Sammy Bonilla', '(858) 712-2817', '56 Bury Street', 136);
insert into CITIZEN_B (citizenid, citizenname, phonenumber, address, cityid)
values (173006051, 'Kiana Jimenez', '(848) 252-2370', '60 Senna Row', 137);
insert into CITIZEN_B (citizenid, citizenname, phonenumber, address, cityid)
values (840454690, 'Tamia Mercado', '(357) 947-6644', '12 Gold Boulevard', 116);
insert into CITIZEN_B (citizenid, citizenname, phonenumber, address, cityid)
values (677761715, 'Chanel Raymond', '(964) 295-4683', '4 Manor Way', 117);
insert into CITIZEN_B (citizenid, citizenname, phonenumber, address, cityid)
values (55937608, 'Ariel Little', '(286) 596-0144', '5 Paradise Way', 118);
insert into CITIZEN_B (citizenid, citizenname, phonenumber, address, cityid)
values (719978224, 'Nolan Orozco', '(605) 200-4712', '101 Oak Street', 141);
insert into CITIZEN_B (citizenid, citizenname, phonenumber, address, cityid)
values (834214215, 'George Maldonado', '(683) 582-9224', '77 Nova Row', 142);
insert into CITIZEN_B (citizenid, citizenname, phonenumber, address, cityid)
values (434932129, 'Valery Leach', '(599) 541-6077', '9 Green Route', 143);
insert into CITIZEN_B (citizenid, citizenname, phonenumber, address, cityid)
values (988386543, 'Leonel Joseph', '(507) 464-8089', '79 Mount Street', 144);
insert into CITIZEN_B (citizenid, citizenname, phonenumber, address, cityid)
values (129407872, 'Koen Finley', '(723) 553-9931', '83 Bush Lane', 145);
insert into CITIZEN_B (citizenid, citizenname, phonenumber, address, cityid)
values (452323355, 'Marshall Barton', '(978) 512-8548', '7 Copper Passage', 146);
insert into CITIZEN_B (citizenid, citizenname, phonenumber, address, cityid)
values (742852779, 'Noelle Butler', '(207) 369-5153', '61 Temple Lane', 143);
insert into CITIZEN_B (citizenid, citizenname, phonenumber, address, cityid)
values (592650513, 'Saul Leonard', '(283) 581-4214', '112 Windmill Route', 144);
insert into CITIZEN_B (citizenid, citizenname, phonenumber, address, cityid)
values (448291127, 'Haley Howe', '(795) 925-1060', '73 Juniper Lane', 130);
insert into CITIZEN_B (citizenid, citizenname, phonenumber, address, cityid)
values (18645918, 'Emmy Strong', '(255) 850-9946', '75 Jewel Street', 131);
insert into CITIZEN_B (citizenid, citizenname, phonenumber, address, cityid)
values (653961350, 'Josie Mcfarland', '(342) 258-1111', '87 Providence Lane', 132);
insert into CITIZEN_B (citizenid, citizenname, phonenumber, address, cityid)
values (64729682, 'Yazmin Oconnell', '(566) 312-8386', '23 Bay View Lane', 133);
insert into CITIZEN_B (citizenid, citizenname, phonenumber, address, cityid)
values (955095939, 'Zaniyah Reese', '(442) 634-5835', '61 Mason Way', 134);
insert into CITIZEN_B (citizenid, citizenname, phonenumber, address, cityid)
values (685600354, 'Declan Wilson', '(759) 929-2227', '39 Gold Avenue', 135);
prompt 100 records loaded
prompt Enabling foreign key constraints for CITIZEN_B...
alter table CITIZEN_B enable constraint SYS_C007328;
prompt Enabling triggers for CITIZEN_B...
alter table CITIZEN_B enable all triggers;

set feedback on
set define on
prompt Done
