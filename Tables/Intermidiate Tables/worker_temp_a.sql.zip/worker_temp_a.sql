?��prompt PL/SQL Developer Export Tables for user SYSTEM
prompt Created by Evyatar on יום שני 10 אוגוסט 2020
set feedback off
set define off

prompt Creating WORKER_TEMP_A...
create table WORKER_TEMP_A
(
  workerid         NUMBER(9),
  workername       VARCHAR2(50),
  birthdate        DATE,
  itsboss_workerid NUMBER(9),
  startdate        DATE,
  enddate          DATE,
  type             INTEGER,
  citizenid        INTEGER,
  salary           FLOAT
)
tablespace SYSTEM
  pctfree 10
  pctused 40
  initrans 1
  maxtrans 255
  storage
  (
    initial 64K
    next 1M
    minextents 1
    maxextents unlimited
  );

prompt Disabling triggers for WORKER_TEMP_A...
alter table WORKER_TEMP_A disable all triggers;
prompt Deleting WORKER_TEMP_A...
delete from WORKER_TEMP_A;
prompt Loading WORKER_TEMP_A...
insert into WORKER_TEMP_A (workerid, workername, birthdate, itsboss_workerid, startdate, enddate, type, citizenid, salary)
values (5000, 'Isaiah Moreno', to_date('18-12-1954', 'dd-mm-yyyy'), 5004, to_date('04-01-2020', 'dd-mm-yyyy'), to_date('19-10-2020', 'dd-mm-yyyy'), 1, 166, 16769);
insert into WORKER_TEMP_A (workerid, workername, birthdate, itsboss_workerid, startdate, enddate, type, citizenid, salary)
values (5001, 'Russell Carradine', to_date('21-02-1958', 'dd-mm-yyyy'), 5008, to_date('08-04-2020', 'dd-mm-yyyy'), to_date('02-06-2020', 'dd-mm-yyyy'), 2, 503, 6845);
insert into WORKER_TEMP_A (workerid, workername, birthdate, itsboss_workerid, startdate, enddate, type, citizenid, salary)
values (5002, 'Todd Anderson', to_date('04-11-1960', 'dd-mm-yyyy'), 5008, to_date('18-04-2009', 'dd-mm-yyyy'), to_date('03-04-2021', 'dd-mm-yyyy'), 2, 627, 6350);
insert into WORKER_TEMP_A (workerid, workername, birthdate, itsboss_workerid, startdate, enddate, type, citizenid, salary)
values (5004, 'Domingo Hong', to_date('03-11-1957', 'dd-mm-yyyy'), 5007, to_date('13-05-2017', 'dd-mm-yyyy'), to_date('13-01-2025', 'dd-mm-yyyy'), 2, 920, 14382);
insert into WORKER_TEMP_A (workerid, workername, birthdate, itsboss_workerid, startdate, enddate, type, citizenid, salary)
values (5005, 'David Gyllenhaal', to_date('13-07-1960', 'dd-mm-yyyy'), 5009, to_date('16-12-2019', 'dd-mm-yyyy'), to_date('05-11-2025', 'dd-mm-yyyy'), 2, 878, 21384);
insert into WORKER_TEMP_A (workerid, workername, birthdate, itsboss_workerid, startdate, enddate, type, citizenid, salary)
values (5006, 'Roddy Cross', to_date('15-01-1955', 'dd-mm-yyyy'), 5007, to_date('27-01-2013', 'dd-mm-yyyy'), to_date('03-08-2024', 'dd-mm-yyyy'), 1, 404, 5463);
insert into WORKER_TEMP_A (workerid, workername, birthdate, itsboss_workerid, startdate, enddate, type, citizenid, salary)
values (5007, 'Kim Glover', to_date('08-06-1955', 'dd-mm-yyyy'), 5003, to_date('25-07-2015', 'dd-mm-yyyy'), to_date('04-04-2025', 'dd-mm-yyyy'), 2, 848, 18894);
insert into WORKER_TEMP_A (workerid, workername, birthdate, itsboss_workerid, startdate, enddate, type, citizenid, salary)
values (5008, 'Wendy Downey', to_date('10-12-1957', 'dd-mm-yyyy'), 5001, to_date('05-08-2016', 'dd-mm-yyyy'), to_date('09-04-2023', 'dd-mm-yyyy'), 2, 316, 6122);
insert into WORKER_TEMP_A (workerid, workername, birthdate, itsboss_workerid, startdate, enddate, type, citizenid, salary)
values (5011, 'Mae Cherry', to_date('05-01-1952', 'dd-mm-yyyy'), 5009, to_date('16-05-2015', 'dd-mm-yyyy'), to_date('25-12-2024', 'dd-mm-yyyy'), 2, 731, 10591);
insert into WORKER_TEMP_A (workerid, workername, birthdate, itsboss_workerid, startdate, enddate, type, citizenid, salary)
values (5012, 'Rick Sizemore', to_date('16-01-1955', 'dd-mm-yyyy'), 5008, to_date('20-10-2011', 'dd-mm-yyyy'), to_date('21-12-2024', 'dd-mm-yyyy'), 2, 14, 20722);
insert into WORKER_TEMP_A (workerid, workername, birthdate, itsboss_workerid, startdate, enddate, type, citizenid, salary)
values (5013, 'Mia Strathairn', to_date('10-05-1957', 'dd-mm-yyyy'), 5003, to_date('17-05-2015', 'dd-mm-yyyy'), to_date('05-07-2024', 'dd-mm-yyyy'), 2, 853, 18032);
insert into WORKER_TEMP_A (workerid, workername, birthdate, itsboss_workerid, startdate, enddate, type, citizenid, salary)
values (5014, 'Rosanna Napolitano', to_date('17-08-1956', 'dd-mm-yyyy'), 5003, to_date('29-03-2009', 'dd-mm-yyyy'), to_date('30-08-2022', 'dd-mm-yyyy'), 1, 642, 21995);
insert into WORKER_TEMP_A (workerid, workername, birthdate, itsboss_workerid, startdate, enddate, type, citizenid, salary)
values (5016, 'Mykelti Berenger', to_date('13-11-1960', 'dd-mm-yyyy'), 5006, to_date('14-04-2008', 'dd-mm-yyyy'), to_date('03-08-2020', 'dd-mm-yyyy'), 2, 325, 21494);
insert into WORKER_TEMP_A (workerid, workername, birthdate, itsboss_workerid, startdate, enddate, type, citizenid, salary)
values (5017, 'Albertina Mellencamp', to_date('28-06-1954', 'dd-mm-yyyy'), 5005, to_date('20-01-2013', 'dd-mm-yyyy'), to_date('16-01-2022', 'dd-mm-yyyy'), 2, 877, 4779);
insert into WORKER_TEMP_A (workerid, workername, birthdate, itsboss_workerid, startdate, enddate, type, citizenid, salary)
values (5018, 'Ellen Kutcher', to_date('09-07-1953', 'dd-mm-yyyy'), 5001, to_date('01-11-2011', 'dd-mm-yyyy'), to_date('29-10-2023', 'dd-mm-yyyy'), 1, 914, 11830);
insert into WORKER_TEMP_A (workerid, workername, birthdate, itsboss_workerid, startdate, enddate, type, citizenid, salary)
values (5019, 'Sarah Turturro', to_date('16-07-1956', 'dd-mm-yyyy'), 5009, to_date('10-07-2017', 'dd-mm-yyyy'), to_date('22-11-2022', 'dd-mm-yyyy'), 1, 578, 12855);
insert into WORKER_TEMP_A (workerid, workername, birthdate, itsboss_workerid, startdate, enddate, type, citizenid, salary)
values (5020, 'Nikka Soul', to_date('10-04-1951', 'dd-mm-yyyy'), 5003, to_date('05-04-2020', 'dd-mm-yyyy'), to_date('21-09-2020', 'dd-mm-yyyy'), 1, 175, 10439);
insert into WORKER_TEMP_A (workerid, workername, birthdate, itsboss_workerid, startdate, enddate, type, citizenid, salary)
values (5022, 'Anna Rains', to_date('14-01-1952', 'dd-mm-yyyy'), 5008, to_date('25-12-2016', 'dd-mm-yyyy'), to_date('11-07-2024', 'dd-mm-yyyy'), 1, 341, 16873);
insert into WORKER_TEMP_A (workerid, workername, birthdate, itsboss_workerid, startdate, enddate, type, citizenid, salary)
values (5023, 'Jessica Dolenz', to_date('12-12-1955', 'dd-mm-yyyy'), 5003, to_date('26-11-2013', 'dd-mm-yyyy'), to_date('06-01-2022', 'dd-mm-yyyy'), 2, 155, 9141);
insert into WORKER_TEMP_A (workerid, workername, birthdate, itsboss_workerid, startdate, enddate, type, citizenid, salary)
values (5025, 'Donald Giraldo', to_date('24-02-1957', 'dd-mm-yyyy'), 5008, to_date('20-08-2016', 'dd-mm-yyyy'), to_date('16-10-2024', 'dd-mm-yyyy'), 2, 732, 14283);
insert into WORKER_TEMP_A (workerid, workername, birthdate, itsboss_workerid, startdate, enddate, type, citizenid, salary)
values (5026, 'Donald Giraldo', to_date('19-02-1958', 'dd-mm-yyyy'), 5004, to_date('04-04-2016', 'dd-mm-yyyy'), to_date('22-12-2021', 'dd-mm-yyyy'), 1, 732, 14454);
insert into WORKER_TEMP_A (workerid, workername, birthdate, itsboss_workerid, startdate, enddate, type, citizenid, salary)
values (5028, 'Lydia Douglas', to_date('12-03-1952', 'dd-mm-yyyy'), 5001, to_date('29-12-2016', 'dd-mm-yyyy'), to_date('24-11-2021', 'dd-mm-yyyy'), 1, 8, 20730);
insert into WORKER_TEMP_A (workerid, workername, birthdate, itsboss_workerid, startdate, enddate, type, citizenid, salary)
values (5029, 'Vanessa Kattan', to_date('02-05-1953', 'dd-mm-yyyy'), 5009, to_date('28-04-2013', 'dd-mm-yyyy'), to_date('17-11-2021', 'dd-mm-yyyy'), 2, 280, 9948);
insert into WORKER_TEMP_A (workerid, workername, birthdate, itsboss_workerid, startdate, enddate, type, citizenid, salary)
values (5030, 'Harriet Jonze', to_date('11-09-1960', 'dd-mm-yyyy'), 5009, to_date('17-01-2008', 'dd-mm-yyyy'), to_date('06-09-2021', 'dd-mm-yyyy'), 1, 736, 20254);
insert into WORKER_TEMP_A (workerid, workername, birthdate, itsboss_workerid, startdate, enddate, type, citizenid, salary)
values (5031, 'Ray Burmester', to_date('24-02-1958', 'dd-mm-yyyy'), 5004, to_date('22-11-2008', 'dd-mm-yyyy'), to_date('07-08-2025', 'dd-mm-yyyy'), 2, 56, 14712);
insert into WORKER_TEMP_A (workerid, workername, birthdate, itsboss_workerid, startdate, enddate, type, citizenid, salary)
values (5032, 'Larry Drive', to_date('30-03-1958', 'dd-mm-yyyy'), 5001, to_date('30-12-2012', 'dd-mm-yyyy'), to_date('27-03-2025', 'dd-mm-yyyy'), 1, 193, 5439);
insert into WORKER_TEMP_A (workerid, workername, birthdate, itsboss_workerid, startdate, enddate, type, citizenid, salary)
values (5034, 'Micky Parsons', to_date('19-04-1951', 'dd-mm-yyyy'), 5007, to_date('15-12-2011', 'dd-mm-yyyy'), to_date('15-01-2022', 'dd-mm-yyyy'), 2, 344, 4878);
insert into WORKER_TEMP_A (workerid, workername, birthdate, itsboss_workerid, startdate, enddate, type, citizenid, salary)
values (5035, 'Marley Moorer', to_date('02-07-1954', 'dd-mm-yyyy'), 5002, to_date('12-08-2015', 'dd-mm-yyyy'), to_date('26-09-2024', 'dd-mm-yyyy'), 1, 750, 17652);
insert into WORKER_TEMP_A (workerid, workername, birthdate, itsboss_workerid, startdate, enddate, type, citizenid, salary)
values (5036, 'Christian Finn', to_date('07-12-1955', 'dd-mm-yyyy'), 5005, to_date('30-01-2019', 'dd-mm-yyyy'), to_date('28-06-2024', 'dd-mm-yyyy'), 2, 322, 5319);
insert into WORKER_TEMP_A (workerid, workername, birthdate, itsboss_workerid, startdate, enddate, type, citizenid, salary)
values (5037, 'Anna Rains', to_date('19-02-1954', 'dd-mm-yyyy'), 5007, to_date('20-06-2017', 'dd-mm-yyyy'), to_date('03-11-2025', 'dd-mm-yyyy'), 2, 341, 8360);
insert into WORKER_TEMP_A (workerid, workername, birthdate, itsboss_workerid, startdate, enddate, type, citizenid, salary)
values (5040, 'Murray Douglas', to_date('02-05-1959', 'dd-mm-yyyy'), 5008, to_date('07-04-2010', 'dd-mm-yyyy'), to_date('10-03-2021', 'dd-mm-yyyy'), 1, 156, 16463);
insert into WORKER_TEMP_A (workerid, workername, birthdate, itsboss_workerid, startdate, enddate, type, citizenid, salary)
values (5041, 'Gordon Womack', to_date('13-11-1950', 'dd-mm-yyyy'), 5005, to_date('18-09-2015', 'dd-mm-yyyy'), to_date('16-08-2022', 'dd-mm-yyyy'), 1, 729, 10690);
insert into WORKER_TEMP_A (workerid, workername, birthdate, itsboss_workerid, startdate, enddate, type, citizenid, salary)
values (5042, 'Thomas Craig', to_date('01-07-1960', 'dd-mm-yyyy'), 5002, to_date('06-03-2016', 'dd-mm-yyyy'), to_date('09-10-2022', 'dd-mm-yyyy'), 2, 607, 19329);
insert into WORKER_TEMP_A (workerid, workername, birthdate, itsboss_workerid, startdate, enddate, type, citizenid, salary)
values (5043, 'Sheryl Hartnett', to_date('01-12-1956', 'dd-mm-yyyy'), 5006, to_date('13-09-2014', 'dd-mm-yyyy'), to_date('17-11-2021', 'dd-mm-yyyy'), 2, 708, 10613);
insert into WORKER_TEMP_A (workerid, workername, birthdate, itsboss_workerid, startdate, enddate, type, citizenid, salary)
values (5044, 'Lena Sandler', to_date('23-03-1958', 'dd-mm-yyyy'), 5002, to_date('21-05-2009', 'dd-mm-yyyy'), to_date('21-11-2021', 'dd-mm-yyyy'), 2, 955, 12189);
insert into WORKER_TEMP_A (workerid, workername, birthdate, itsboss_workerid, startdate, enddate, type, citizenid, salary)
values (5046, 'Hector Pleasence', to_date('16-10-1959', 'dd-mm-yyyy'), 5009, to_date('07-07-2019', 'dd-mm-yyyy'), to_date('26-03-2021', 'dd-mm-yyyy'), 2, 747, 12979);
insert into WORKER_TEMP_A (workerid, workername, birthdate, itsboss_workerid, startdate, enddate, type, citizenid, salary)
values (5047, 'Halle Imperioli', to_date('01-07-1951', 'dd-mm-yyyy'), 5007, to_date('20-07-2019', 'dd-mm-yyyy'), to_date('31-01-2022', 'dd-mm-yyyy'), 1, 547, 6330);
insert into WORKER_TEMP_A (workerid, workername, birthdate, itsboss_workerid, startdate, enddate, type, citizenid, salary)
values (5048, 'Don Lineback', to_date('08-05-1955', 'dd-mm-yyyy'), 5003, to_date('27-06-2009', 'dd-mm-yyyy'), to_date('03-04-2025', 'dd-mm-yyyy'), 1, 339, 16830);
insert into WORKER_TEMP_A (workerid, workername, birthdate, itsboss_workerid, startdate, enddate, type, citizenid, salary)
values (5049, 'Kay Coburn', to_date('13-08-1958', 'dd-mm-yyyy'), 5008, to_date('08-03-2015', 'dd-mm-yyyy'), to_date('01-10-2023', 'dd-mm-yyyy'), 1, 365, 12266);
insert into WORKER_TEMP_A (workerid, workername, birthdate, itsboss_workerid, startdate, enddate, type, citizenid, salary)
values (5050, 'Karon Leachman', to_date('06-09-1953', 'dd-mm-yyyy'), 5005, to_date('26-09-2008', 'dd-mm-yyyy'), to_date('29-05-2021', 'dd-mm-yyyy'), 2, 131, 16725);
insert into WORKER_TEMP_A (workerid, workername, birthdate, itsboss_workerid, startdate, enddate, type, citizenid, salary)
values (5052, 'Vanessa Vance', to_date('06-07-1953', 'dd-mm-yyyy'), 5004, to_date('04-08-2018', 'dd-mm-yyyy'), to_date('05-11-2021', 'dd-mm-yyyy'), 2, 410, 6909);
insert into WORKER_TEMP_A (workerid, workername, birthdate, itsboss_workerid, startdate, enddate, type, citizenid, salary)
values (5054, 'Nina Bassett', to_date('23-03-1955', 'dd-mm-yyyy'), 5002, to_date('01-12-2015', 'dd-mm-yyyy'), to_date('27-03-2024', 'dd-mm-yyyy'), 2, 479, 10085);
insert into WORKER_TEMP_A (workerid, workername, birthdate, itsboss_workerid, startdate, enddate, type, citizenid, salary)
values (5055, 'Cliff Heche', to_date('24-10-1951', 'dd-mm-yyyy'), 5009, to_date('11-08-2015', 'dd-mm-yyyy'), to_date('05-04-2022', 'dd-mm-yyyy'), 1, 700, 19565);
insert into WORKER_TEMP_A (workerid, workername, birthdate, itsboss_workerid, startdate, enddate, type, citizenid, salary)
values (5057, 'Liam Aaron', to_date('24-12-1957', 'dd-mm-yyyy'), 5002, to_date('24-04-2016', 'dd-mm-yyyy'), to_date('25-04-2022', 'dd-mm-yyyy'), 1, 527, 16316);
insert into WORKER_TEMP_A (workerid, workername, birthdate, itsboss_workerid, startdate, enddate, type, citizenid, salary)
values (5058, 'Nikki Close', to_date('11-01-1953', 'dd-mm-yyyy'), 5008, to_date('19-05-2008', 'dd-mm-yyyy'), to_date('23-07-2023', 'dd-mm-yyyy'), 1, 727, 20117);
insert into WORKER_TEMP_A (workerid, workername, birthdate, itsboss_workerid, startdate, enddate, type, citizenid, salary)
values (5059, 'Domingo Hong', to_date('13-01-1960', 'dd-mm-yyyy'), 5010, to_date('08-05-2017', 'dd-mm-yyyy'), to_date('30-05-2025', 'dd-mm-yyyy'), 1, 920, 19088);
insert into WORKER_TEMP_A (workerid, workername, birthdate, itsboss_workerid, startdate, enddate, type, citizenid, salary)
values (5061, 'King Hershey', to_date('12-11-1952', 'dd-mm-yyyy'), 5005, to_date('04-09-2010', 'dd-mm-yyyy'), to_date('09-07-2022', 'dd-mm-yyyy'), 1, 386, 19092);
insert into WORKER_TEMP_A (workerid, workername, birthdate, itsboss_workerid, startdate, enddate, type, citizenid, salary)
values (5062, 'Cyndi Ferrer', to_date('27-09-1954', 'dd-mm-yyyy'), 5006, to_date('26-09-2019', 'dd-mm-yyyy'), to_date('27-12-2023', 'dd-mm-yyyy'), 1, 511, 17085);
insert into WORKER_TEMP_A (workerid, workername, birthdate, itsboss_workerid, startdate, enddate, type, citizenid, salary)
values (5064, 'Emm MacNeil', to_date('01-08-1952', 'dd-mm-yyyy'), 5003, to_date('07-05-2018', 'dd-mm-yyyy'), to_date('08-08-2023', 'dd-mm-yyyy'), 1, 776, 16368);
insert into WORKER_TEMP_A (workerid, workername, birthdate, itsboss_workerid, startdate, enddate, type, citizenid, salary)
values (5067, 'Mae Cherry', to_date('17-09-1951', 'dd-mm-yyyy'), 5009, to_date('19-08-2015', 'dd-mm-yyyy'), to_date('17-11-2024', 'dd-mm-yyyy'), 1, 731, 20834);
insert into WORKER_TEMP_A (workerid, workername, birthdate, itsboss_workerid, startdate, enddate, type, citizenid, salary)
values (5068, 'Walter Rosas', to_date('09-06-1954', 'dd-mm-yyyy'), 5004, to_date('02-10-2012', 'dd-mm-yyyy'), to_date('30-03-2024', 'dd-mm-yyyy'), 2, 660, 9540);
insert into WORKER_TEMP_A (workerid, workername, birthdate, itsboss_workerid, startdate, enddate, type, citizenid, salary)
values (5070, 'Anthony Ribisi', to_date('06-07-1956', 'dd-mm-yyyy'), 5003, to_date('06-09-2015', 'dd-mm-yyyy'), to_date('23-09-2024', 'dd-mm-yyyy'), 2, 835, 5185);
insert into WORKER_TEMP_A (workerid, workername, birthdate, itsboss_workerid, startdate, enddate, type, citizenid, salary)
values (5073, 'Gilberto Rea', to_date('29-06-1950', 'dd-mm-yyyy'), 5002, to_date('12-02-2018', 'dd-mm-yyyy'), to_date('16-09-2022', 'dd-mm-yyyy'), 1, 843, 5417);
insert into WORKER_TEMP_A (workerid, workername, birthdate, itsboss_workerid, startdate, enddate, type, citizenid, salary)
values (5076, 'Chrissie Zahn', to_date('18-05-1960', 'dd-mm-yyyy'), 5007, to_date('04-09-2010', 'dd-mm-yyyy'), to_date('27-10-2025', 'dd-mm-yyyy'), 1, 924, 5352);
insert into WORKER_TEMP_A (workerid, workername, birthdate, itsboss_workerid, startdate, enddate, type, citizenid, salary)
values (5078, 'Fats Walker', to_date('15-03-1959', 'dd-mm-yyyy'), 5005, to_date('06-09-2019', 'dd-mm-yyyy'), to_date('19-09-2021', 'dd-mm-yyyy'), 2, 845, 17794);
insert into WORKER_TEMP_A (workerid, workername, birthdate, itsboss_workerid, startdate, enddate, type, citizenid, salary)
values (5079, 'Tyrone Sledge', to_date('10-05-1955', 'dd-mm-yyyy'), 5008, to_date('06-05-2009', 'dd-mm-yyyy'), to_date('12-02-2023', 'dd-mm-yyyy'), 2, 850, 19605);
insert into WORKER_TEMP_A (workerid, workername, birthdate, itsboss_workerid, startdate, enddate, type, citizenid, salary)
values (5081, 'Gabrielle Hampton', to_date('08-01-1953', 'dd-mm-yyyy'), 5007, to_date('06-03-2008', 'dd-mm-yyyy'), to_date('22-11-2022', 'dd-mm-yyyy'), 2, 932, 16258);
insert into WORKER_TEMP_A (workerid, workername, birthdate, itsboss_workerid, startdate, enddate, type, citizenid, salary)
values (5082, 'Pamela Beals', to_date('17-06-1952', 'dd-mm-yyyy'), 5007, to_date('05-08-2014', 'dd-mm-yyyy'), to_date('22-12-2025', 'dd-mm-yyyy'), 2, 840, 12343);
insert into WORKER_TEMP_A (workerid, workername, birthdate, itsboss_workerid, startdate, enddate, type, citizenid, salary)
values (5085, 'Etta Stills', to_date('11-09-1960', 'dd-mm-yyyy'), 5009, to_date('17-06-2013', 'dd-mm-yyyy'), to_date('15-03-2023', 'dd-mm-yyyy'), 2, 551, 19795);
insert into WORKER_TEMP_A (workerid, workername, birthdate, itsboss_workerid, startdate, enddate, type, citizenid, salary)
values (5087, 'Debi Chandler', to_date('30-10-1950', 'dd-mm-yyyy'), 5007, to_date('02-05-2019', 'dd-mm-yyyy'), to_date('18-10-2020', 'dd-mm-yyyy'), 1, 521, 10063);
insert into WORKER_TEMP_A (workerid, workername, birthdate, itsboss_workerid, startdate, enddate, type, citizenid, salary)
values (5088, 'Gaby Coughlan', to_date('11-06-1957', 'dd-mm-yyyy'), 5003, to_date('28-03-2017', 'dd-mm-yyyy'), to_date('19-06-2022', 'dd-mm-yyyy'), 1, 94, 6513);
insert into WORKER_TEMP_A (workerid, workername, birthdate, itsboss_workerid, startdate, enddate, type, citizenid, salary)
values (5090, 'Timothy McKennitt', to_date('14-03-1952', 'dd-mm-yyyy'), 5004, to_date('04-10-2014', 'dd-mm-yyyy'), to_date('08-12-2022', 'dd-mm-yyyy'), 2, 446, 14015);
insert into WORKER_TEMP_A (workerid, workername, birthdate, itsboss_workerid, startdate, enddate, type, citizenid, salary)
values (5091, 'Ahmad Gill', to_date('08-10-1954', 'dd-mm-yyyy'), 5009, to_date('18-09-2008', 'dd-mm-yyyy'), to_date('26-04-2024', 'dd-mm-yyyy'), 2, 921, 21671);
insert into WORKER_TEMP_A (workerid, workername, birthdate, itsboss_workerid, startdate, enddate, type, citizenid, salary)
values (5095, 'Guy Tobolowsky', to_date('05-10-1955', 'dd-mm-yyyy'), 5007, to_date('05-05-2019', 'dd-mm-yyyy'), to_date('19-03-2022', 'dd-mm-yyyy'), 2, 243, 6805);
insert into WORKER_TEMP_A (workerid, workername, birthdate, itsboss_workerid, startdate, enddate, type, citizenid, salary)
values (5098, 'Diane Kattan', to_date('14-04-1954', 'dd-mm-yyyy'), 5008, to_date('03-04-2008', 'dd-mm-yyyy'), to_date('12-11-2022', 'dd-mm-yyyy'), 1, 209, 16821);
insert into WORKER_TEMP_A (workerid, workername, birthdate, itsboss_workerid, startdate, enddate, type, citizenid, salary)
values (5099, 'Dwight Moriarty', to_date('03-12-1954', 'dd-mm-yyyy'), 5002, to_date('31-03-2018', 'dd-mm-yyyy'), to_date('03-12-2021', 'dd-mm-yyyy'), 1, 107, 10003);
insert into WORKER_TEMP_A (workerid, workername, birthdate, itsboss_workerid, startdate, enddate, type, citizenid, salary)
values (5101, 'Bob Robbins', to_date('17-12-1959', 'dd-mm-yyyy'), 5002, to_date('20-05-2020', 'dd-mm-yyyy'), to_date('15-11-2021', 'dd-mm-yyyy'), 1, 772, 18621);
insert into WORKER_TEMP_A (workerid, workername, birthdate, itsboss_workerid, startdate, enddate, type, citizenid, salary)
values (5104, 'Roy Borgnine', to_date('13-01-1959', 'dd-mm-yyyy'), 5003, to_date('25-01-2009', 'dd-mm-yyyy'), to_date('25-09-2023', 'dd-mm-yyyy'), 1, 321, 17881);
insert into WORKER_TEMP_A (workerid, workername, birthdate, itsboss_workerid, startdate, enddate, type, citizenid, salary)
values (5106, 'Owen Viterelli', to_date('30-04-1954', 'dd-mm-yyyy'), 5006, to_date('10-06-2008', 'dd-mm-yyyy'), to_date('16-02-2024', 'dd-mm-yyyy'), 1, 755, 5701);
insert into WORKER_TEMP_A (workerid, workername, birthdate, itsboss_workerid, startdate, enddate, type, citizenid, salary)
values (5107, 'Natascha Sampson', to_date('15-07-1953', 'dd-mm-yyyy'), 5006, to_date('04-05-2019', 'dd-mm-yyyy'), to_date('25-10-2024', 'dd-mm-yyyy'), 1, 548, 16787);
insert into WORKER_TEMP_A (workerid, workername, birthdate, itsboss_workerid, startdate, enddate, type, citizenid, salary)
values (5109, 'Benjamin Lennox', to_date('19-10-1958', 'dd-mm-yyyy'), 5008, to_date('26-06-2015', 'dd-mm-yyyy'), to_date('23-02-2025', 'dd-mm-yyyy'), 2, 188, 8952);
insert into WORKER_TEMP_A (workerid, workername, birthdate, itsboss_workerid, startdate, enddate, type, citizenid, salary)
values (5111, 'Kyra Boone', to_date('15-11-1958', 'dd-mm-yyyy'), 5004, to_date('12-08-2014', 'dd-mm-yyyy'), to_date('13-10-2020', 'dd-mm-yyyy'), 1, 715, 11497);
insert into WORKER_TEMP_A (workerid, workername, birthdate, itsboss_workerid, startdate, enddate, type, citizenid, salary)
values (5113, 'Isaiah Dayne', to_date('04-04-1957', 'dd-mm-yyyy'), 5002, to_date('07-03-2008', 'dd-mm-yyyy'), to_date('14-05-2024', 'dd-mm-yyyy'), 1, 684, 21333);
insert into WORKER_TEMP_A (workerid, workername, birthdate, itsboss_workerid, startdate, enddate, type, citizenid, salary)
values (5115, 'Minnie DiBiasio', to_date('16-01-1950', 'dd-mm-yyyy'), 5006, to_date('05-02-2009', 'dd-mm-yyyy'), to_date('09-11-2022', 'dd-mm-yyyy'), 1, 275, 17991);
insert into WORKER_TEMP_A (workerid, workername, birthdate, itsboss_workerid, startdate, enddate, type, citizenid, salary)
values (5117, 'Timothy Rivers', to_date('22-04-1955', 'dd-mm-yyyy'), 5009, to_date('08-03-2011', 'dd-mm-yyyy'), to_date('26-10-2023', 'dd-mm-yyyy'), 1, 603, 10096);
insert into WORKER_TEMP_A (workerid, workername, birthdate, itsboss_workerid, startdate, enddate, type, citizenid, salary)
values (5118, 'Betty Polley', to_date('06-01-1956', 'dd-mm-yyyy'), 5008, to_date('30-08-2011', 'dd-mm-yyyy'), to_date('14-12-2025', 'dd-mm-yyyy'), 1, 448, 21374);
insert into WORKER_TEMP_A (workerid, workername, birthdate, itsboss_workerid, startdate, enddate, type, citizenid, salary)
values (5122, 'Chad Torn', to_date('27-12-1951', 'dd-mm-yyyy'), 5009, to_date('10-12-2013', 'dd-mm-yyyy'), to_date('06-06-2021', 'dd-mm-yyyy'), 1, 601, 6200);
insert into WORKER_TEMP_A (workerid, workername, birthdate, itsboss_workerid, startdate, enddate, type, citizenid, salary)
values (5124, 'Samuel Carlisle', to_date('03-03-1959', 'dd-mm-yyyy'), 5001, to_date('26-02-2011', 'dd-mm-yyyy'), to_date('01-05-2022', 'dd-mm-yyyy'), 1, 938, 13120);
insert into WORKER_TEMP_A (workerid, workername, birthdate, itsboss_workerid, startdate, enddate, type, citizenid, salary)
values (5126, 'Oliver Hornsby', to_date('12-09-1960', 'dd-mm-yyyy'), 5008, to_date('09-09-2013', 'dd-mm-yyyy'), to_date('07-08-2020', 'dd-mm-yyyy'), 2, 852, 9717);
insert into WORKER_TEMP_A (workerid, workername, birthdate, itsboss_workerid, startdate, enddate, type, citizenid, salary)
values (5127, 'Corey Brown', to_date('14-09-1960', 'dd-mm-yyyy'), 5009, to_date('13-03-2011', 'dd-mm-yyyy'), to_date('09-11-2025', 'dd-mm-yyyy'), 1, 377, 20645);
insert into WORKER_TEMP_A (workerid, workername, birthdate, itsboss_workerid, startdate, enddate, type, citizenid, salary)
values (5130, 'Alana Shalhoub', to_date('21-02-1956', 'dd-mm-yyyy'), 5006, to_date('05-04-2018', 'dd-mm-yyyy'), to_date('21-10-2024', 'dd-mm-yyyy'), 1, 177, 20387);
insert into WORKER_TEMP_A (workerid, workername, birthdate, itsboss_workerid, startdate, enddate, type, citizenid, salary)
values (5132, 'Collin Englund', to_date('17-08-1953', 'dd-mm-yyyy'), 5009, to_date('11-05-2014', 'dd-mm-yyyy'), to_date('18-06-2024', 'dd-mm-yyyy'), 1, 432, 9801);
insert into WORKER_TEMP_A (workerid, workername, birthdate, itsboss_workerid, startdate, enddate, type, citizenid, salary)
values (5133, 'Art Weston', to_date('18-03-1953', 'dd-mm-yyyy'), 5002, to_date('22-11-2013', 'dd-mm-yyyy'), to_date('07-04-2023', 'dd-mm-yyyy'), 2, 831, 15691);
insert into WORKER_TEMP_A (workerid, workername, birthdate, itsboss_workerid, startdate, enddate, type, citizenid, salary)
values (5135, 'Stephanie Horizon', to_date('12-10-1951', 'dd-mm-yyyy'), 5007, to_date('15-01-2009', 'dd-mm-yyyy'), to_date('01-03-2021', 'dd-mm-yyyy'), 1, 963, 21539);
insert into WORKER_TEMP_A (workerid, workername, birthdate, itsboss_workerid, startdate, enddate, type, citizenid, salary)
values (5137, 'Ralph Hopkins', to_date('02-09-1951', 'dd-mm-yyyy'), 5004, to_date('06-10-2014', 'dd-mm-yyyy'), to_date('25-12-2021', 'dd-mm-yyyy'), 2, 985, 9942);
insert into WORKER_TEMP_A (workerid, workername, birthdate, itsboss_workerid, startdate, enddate, type, citizenid, salary)
values (5140, 'Maxine Bullock', to_date('24-01-1959', 'dd-mm-yyyy'), 5008, to_date('14-03-2017', 'dd-mm-yyyy'), to_date('11-08-2024', 'dd-mm-yyyy'), 2, 310, 6387);
insert into WORKER_TEMP_A (workerid, workername, birthdate, itsboss_workerid, startdate, enddate, type, citizenid, salary)
values (5142, 'Dan Botti', to_date('19-10-1958', 'dd-mm-yyyy'), 5007, to_date('06-07-2010', 'dd-mm-yyyy'), to_date('23-02-2022', 'dd-mm-yyyy'), 2, 82, 12802);
insert into WORKER_TEMP_A (workerid, workername, birthdate, itsboss_workerid, startdate, enddate, type, citizenid, salary)
values (5144, 'Corey Day', to_date('28-09-1954', 'dd-mm-yyyy'), 5009, to_date('13-12-2016', 'dd-mm-yyyy'), to_date('07-02-2024', 'dd-mm-yyyy'), 2, 862, 4552);
insert into WORKER_TEMP_A (workerid, workername, birthdate, itsboss_workerid, startdate, enddate, type, citizenid, salary)
values (5146, 'Art Weston', to_date('24-02-1957', 'dd-mm-yyyy'), 5010, to_date('18-02-2020', 'dd-mm-yyyy'), to_date('03-09-2023', 'dd-mm-yyyy'), 1, 831, 20457);
insert into WORKER_TEMP_A (workerid, workername, birthdate, itsboss_workerid, startdate, enddate, type, citizenid, salary)
values (5147, 'Blair Caviezel', to_date('30-08-1959', 'dd-mm-yyyy'), 5008, to_date('26-12-2008', 'dd-mm-yyyy'), to_date('28-10-2023', 'dd-mm-yyyy'), 2, 372, 7635);
insert into WORKER_TEMP_A (workerid, workername, birthdate, itsboss_workerid, startdate, enddate, type, citizenid, salary)
values (5150, 'Omar Puckett', to_date('22-09-1956', 'dd-mm-yyyy'), 5002, to_date('14-07-2010', 'dd-mm-yyyy'), to_date('11-08-2025', 'dd-mm-yyyy'), 1, 886, 15045);
insert into WORKER_TEMP_A (workerid, workername, birthdate, itsboss_workerid, startdate, enddate, type, citizenid, salary)
values (5152, 'William Murdock', to_date('29-09-1960', 'dd-mm-yyyy'), 5010, to_date('29-11-2013', 'dd-mm-yyyy'), to_date('24-04-2023', 'dd-mm-yyyy'), 1, 898, 12403);
insert into WORKER_TEMP_A (workerid, workername, birthdate, itsboss_workerid, startdate, enddate, type, citizenid, salary)
values (5154, 'Rip Pitney', to_date('07-10-1958', 'dd-mm-yyyy'), 5005, to_date('31-10-2011', 'dd-mm-yyyy'), to_date('13-06-2020', 'dd-mm-yyyy'), 2, 857, 8132);
insert into WORKER_TEMP_A (workerid, workername, birthdate, itsboss_workerid, startdate, enddate, type, citizenid, salary)
values (5155, 'Rhona Connick', to_date('18-01-1960', 'dd-mm-yyyy'), 5007, to_date('16-05-2014', 'dd-mm-yyyy'), to_date('22-12-2022', 'dd-mm-yyyy'), 1, 639, 14932);
insert into WORKER_TEMP_A (workerid, workername, birthdate, itsboss_workerid, startdate, enddate, type, citizenid, salary)
values (5156, 'Ruth Lopez', to_date('10-10-1958', 'dd-mm-yyyy'), 5002, to_date('05-02-2009', 'dd-mm-yyyy'), to_date('30-09-2020', 'dd-mm-yyyy'), 2, 438, 12811);
insert into WORKER_TEMP_A (workerid, workername, birthdate, itsboss_workerid, startdate, enddate, type, citizenid, salary)
values (5160, 'Cheech McCoy', to_date('16-07-1952', 'dd-mm-yyyy'), 5008, to_date('04-07-2014', 'dd-mm-yyyy'), to_date('24-08-2020', 'dd-mm-yyyy'), 2, 210, 4749);
insert into WORKER_TEMP_A (workerid, workername, birthdate, itsboss_workerid, startdate, enddate, type, citizenid, salary)
values (5161, 'Saffron Gosdin', to_date('21-08-1956', 'dd-mm-yyyy'), 5003, to_date('23-06-2010', 'dd-mm-yyyy'), to_date('29-03-2021', 'dd-mm-yyyy'), 1, 654, 5714);
insert into WORKER_TEMP_A (workerid, workername, birthdate, itsboss_workerid, startdate, enddate, type, citizenid, salary)
values (5163, 'Marty Scorsese', to_date('31-03-1959', 'dd-mm-yyyy'), 5010, to_date('07-11-2012', 'dd-mm-yyyy'), to_date('08-12-2023', 'dd-mm-yyyy'), 2, 223, 17003);
insert into WORKER_TEMP_A (workerid, workername, birthdate, itsboss_workerid, startdate, enddate, type, citizenid, salary)
values (5164, 'Vincent Peniston', to_date('29-08-1960', 'dd-mm-yyyy'), 5002, to_date('03-02-2019', 'dd-mm-yyyy'), to_date('29-11-2021', 'dd-mm-yyyy'), 2, 581, 6715);
insert into WORKER_TEMP_A (workerid, workername, birthdate, itsboss_workerid, startdate, enddate, type, citizenid, salary)
values (5166, 'Ahmad Gill', to_date('13-01-1959', 'dd-mm-yyyy'), 5002, to_date('07-09-2008', 'dd-mm-yyyy'), to_date('07-06-2022', 'dd-mm-yyyy'), 2, 921, 13207);
insert into WORKER_TEMP_A (workerid, workername, birthdate, itsboss_workerid, startdate, enddate, type, citizenid, salary)
values (5170, 'Tommy Moffat', to_date('07-09-1951', 'dd-mm-yyyy'), 5005, to_date('11-01-2016', 'dd-mm-yyyy'), to_date('21-10-2024', 'dd-mm-yyyy'), 1, 952, 8843);
insert into WORKER_TEMP_A (workerid, workername, birthdate, itsboss_workerid, startdate, enddate, type, citizenid, salary)
values (5172, 'Donald Giraldo', to_date('31-12-1959', 'dd-mm-yyyy'), 5008, to_date('28-02-2018', 'dd-mm-yyyy'), to_date('22-03-2025', 'dd-mm-yyyy'), 1, 732, 12461);
insert into WORKER_TEMP_A (workerid, workername, birthdate, itsboss_workerid, startdate, enddate, type, citizenid, salary)
values (5173, 'Greg Bandy', to_date('21-02-1957', 'dd-mm-yyyy'), 5006, to_date('05-09-2015', 'dd-mm-yyyy'), to_date('19-06-2023', 'dd-mm-yyyy'), 2, 861, 20397);
insert into WORKER_TEMP_A (workerid, workername, birthdate, itsboss_workerid, startdate, enddate, type, citizenid, salary)
values (5175, 'Joan Hyde', to_date('27-11-1951', 'dd-mm-yyyy'), 5009, to_date('02-02-2020', 'dd-mm-yyyy'), to_date('18-06-2021', 'dd-mm-yyyy'), 1, 274, 8998);
insert into WORKER_TEMP_A (workerid, workername, birthdate, itsboss_workerid, startdate, enddate, type, citizenid, salary)
values (5178, 'Shawn Gray', to_date('16-12-1956', 'dd-mm-yyyy'), 5003, to_date('02-12-2018', 'dd-mm-yyyy'), to_date('19-07-2024', 'dd-mm-yyyy'), 1, 795, 9324);
insert into WORKER_TEMP_A (workerid, workername, birthdate, itsboss_workerid, startdate, enddate, type, citizenid, salary)
values (5179, 'Jake Aaron', to_date('21-05-1959', 'dd-mm-yyyy'), 5005, to_date('04-11-2011', 'dd-mm-yyyy'), to_date('09-03-2022', 'dd-mm-yyyy'), 2, 496, 21616);
insert into WORKER_TEMP_A (workerid, workername, birthdate, itsboss_workerid, startdate, enddate, type, citizenid, salary)
values (5181, 'Christmas Whitman', to_date('01-12-1958', 'dd-mm-yyyy'), 5008, to_date('12-06-2019', 'dd-mm-yyyy'), to_date('29-09-2022', 'dd-mm-yyyy'), 2, 454, 9814);
insert into WORKER_TEMP_A (workerid, workername, birthdate, itsboss_workerid, startdate, enddate, type, citizenid, salary)
values (5182, 'Trey Weaver', to_date('23-01-1956', 'dd-mm-yyyy'), 5005, to_date('05-09-2016', 'dd-mm-yyyy'), to_date('05-07-2023', 'dd-mm-yyyy'), 2, 37, 12312);
insert into WORKER_TEMP_A (workerid, workername, birthdate, itsboss_workerid, startdate, enddate, type, citizenid, salary)
values (5184, 'Tanya Farrell', to_date('03-08-1956', 'dd-mm-yyyy'), 5006, to_date('02-02-2008', 'dd-mm-yyyy'), to_date('01-06-2021', 'dd-mm-yyyy'), 2, 352, 19484);
insert into WORKER_TEMP_A (workerid, workername, birthdate, itsboss_workerid, startdate, enddate, type, citizenid, salary)
values (5187, 'Cheryl Liotta', to_date('08-08-1960', 'dd-mm-yyyy'), 5005, to_date('17-04-2018', 'dd-mm-yyyy'), to_date('05-12-2025', 'dd-mm-yyyy'), 2, 353, 16769);
insert into WORKER_TEMP_A (workerid, workername, birthdate, itsboss_workerid, startdate, enddate, type, citizenid, salary)
values (5188, 'Aimee Tierney', to_date('31-10-1956', 'dd-mm-yyyy'), 5006, to_date('08-07-2012', 'dd-mm-yyyy'), to_date('14-02-2022', 'dd-mm-yyyy'), 1, 61, 17415);
insert into WORKER_TEMP_A (workerid, workername, birthdate, itsboss_workerid, startdate, enddate, type, citizenid, salary)
values (5190, 'Roberta Puckett', to_date('13-02-1952', 'dd-mm-yyyy'), 5004, to_date('28-09-2015', 'dd-mm-yyyy'), to_date('13-11-2020', 'dd-mm-yyyy'), 1, 34, 6819);
insert into WORKER_TEMP_A (workerid, workername, birthdate, itsboss_workerid, startdate, enddate, type, citizenid, salary)
values (5193, 'Jean-Luc McBride', to_date('13-12-1954', 'dd-mm-yyyy'), 5003, to_date('22-02-2011', 'dd-mm-yyyy'), to_date('31-10-2022', 'dd-mm-yyyy'), 1, 150, 17366);
insert into WORKER_TEMP_A (workerid, workername, birthdate, itsboss_workerid, startdate, enddate, type, citizenid, salary)
values (5196, 'Gaby Coughlan', to_date('16-04-1956', 'dd-mm-yyyy'), 5005, to_date('16-05-2009', 'dd-mm-yyyy'), to_date('16-10-2024', 'dd-mm-yyyy'), 2, 94, 18662);
insert into WORKER_TEMP_A (workerid, workername, birthdate, itsboss_workerid, startdate, enddate, type, citizenid, salary)
values (5198, 'Cuba Pullman', to_date('26-12-1952', 'dd-mm-yyyy'), 5010, to_date('27-12-2016', 'dd-mm-yyyy'), to_date('28-09-2020', 'dd-mm-yyyy'), 1, 423, 8644);
insert into WORKER_TEMP_A (workerid, workername, birthdate, itsboss_workerid, startdate, enddate, type, citizenid, salary)
values (5199, 'Marlon Rowlands', to_date('14-10-1960', 'dd-mm-yyyy'), 5004, to_date('23-05-2019', 'dd-mm-yyyy'), to_date('28-05-2021', 'dd-mm-yyyy'), 2, 154, 17246);
insert into WORKER_TEMP_A (workerid, workername, birthdate, itsboss_workerid, startdate, enddate, type, citizenid, salary)
values (5200, 'Gilberto Hewett', to_date('26-01-1953', 'dd-mm-yyyy'), 5009, to_date('04-11-2012', 'dd-mm-yyyy'), to_date('09-01-2021', 'dd-mm-yyyy'), 2, 252, 21688);
insert into WORKER_TEMP_A (workerid, workername, birthdate, itsboss_workerid, startdate, enddate, type, citizenid, salary)
values (5201, 'Halle Imperioli', to_date('23-01-1955', 'dd-mm-yyyy'), 5001, to_date('16-12-2016', 'dd-mm-yyyy'), to_date('05-08-2022', 'dd-mm-yyyy'), 2, 547, 18386);
insert into WORKER_TEMP_A (workerid, workername, birthdate, itsboss_workerid, startdate, enddate, type, citizenid, salary)
values (5202, 'Joseph Brosnan', to_date('02-09-1954', 'dd-mm-yyyy'), 5010, to_date('27-07-2015', 'dd-mm-yyyy'), to_date('11-09-2023', 'dd-mm-yyyy'), 1, 269, 9737);
insert into WORKER_TEMP_A (workerid, workername, birthdate, itsboss_workerid, startdate, enddate, type, citizenid, salary)
values (5203, 'Mary Sewell', to_date('30-01-1957', 'dd-mm-yyyy'), 5007, to_date('09-06-2016', 'dd-mm-yyyy'), to_date('16-02-2022', 'dd-mm-yyyy'), 2, 513, 10582);
insert into WORKER_TEMP_A (workerid, workername, birthdate, itsboss_workerid, startdate, enddate, type, citizenid, salary)
values (5204, 'Karon Zeta-Jones', to_date('11-07-1954', 'dd-mm-yyyy'), 5006, to_date('16-04-2014', 'dd-mm-yyyy'), to_date('06-01-2022', 'dd-mm-yyyy'), 1, 189, 16635);
insert into WORKER_TEMP_A (workerid, workername, birthdate, itsboss_workerid, startdate, enddate, type, citizenid, salary)
values (5205, 'Rhea Lorenz', to_date('22-10-1954', 'dd-mm-yyyy'), 5003, to_date('05-01-2011', 'dd-mm-yyyy'), to_date('05-03-2024', 'dd-mm-yyyy'), 1, 809, 5899);
insert into WORKER_TEMP_A (workerid, workername, birthdate, itsboss_workerid, startdate, enddate, type, citizenid, salary)
values (5206, 'Simon Murphy', to_date('12-12-1958', 'dd-mm-yyyy'), 5010, to_date('04-07-2017', 'dd-mm-yyyy'), to_date('28-08-2020', 'dd-mm-yyyy'), 2, 500, 7845);
insert into WORKER_TEMP_A (workerid, workername, birthdate, itsboss_workerid, startdate, enddate, type, citizenid, salary)
values (5207, 'Larry Randal', to_date('13-05-1960', 'dd-mm-yyyy'), 5004, to_date('23-07-2010', 'dd-mm-yyyy'), to_date('07-07-2023', 'dd-mm-yyyy'), 2, 703, 12616);
insert into WORKER_TEMP_A (workerid, workername, birthdate, itsboss_workerid, startdate, enddate, type, citizenid, salary)
values (5208, 'Percy Place', to_date('02-09-1959', 'dd-mm-yyyy'), 5004, to_date('19-01-2013', 'dd-mm-yyyy'), to_date('01-01-2024', 'dd-mm-yyyy'), 2, 940, 9549);
insert into WORKER_TEMP_A (workerid, workername, birthdate, itsboss_workerid, startdate, enddate, type, citizenid, salary)
values (5209, 'Vertical Goodall', to_date('30-06-1954', 'dd-mm-yyyy'), 5001, to_date('11-04-2011', 'dd-mm-yyyy'), to_date('30-09-2020', 'dd-mm-yyyy'), 1, 230, 7541);
insert into WORKER_TEMP_A (workerid, workername, birthdate, itsboss_workerid, startdate, enddate, type, citizenid, salary)
values (5210, 'Shelby Murphy', to_date('03-11-1960', 'dd-mm-yyyy'), 5007, to_date('10-06-2012', 'dd-mm-yyyy'), to_date('27-07-2025', 'dd-mm-yyyy'), 2, 613, 13655);
insert into WORKER_TEMP_A (workerid, workername, birthdate, itsboss_workerid, startdate, enddate, type, citizenid, salary)
values (5212, 'Spike Firth', to_date('11-10-1950', 'dd-mm-yyyy'), 5001, to_date('21-10-2018', 'dd-mm-yyyy'), to_date('23-03-2024', 'dd-mm-yyyy'), 1, 566, 6580);
insert into WORKER_TEMP_A (workerid, workername, birthdate, itsboss_workerid, startdate, enddate, type, citizenid, salary)
values (5213, 'Jarvis Rubinek', to_date('23-10-1958', 'dd-mm-yyyy'), 5003, to_date('13-03-2008', 'dd-mm-yyyy'), to_date('30-11-2020', 'dd-mm-yyyy'), 1, 298, 12421);
insert into WORKER_TEMP_A (workerid, workername, birthdate, itsboss_workerid, startdate, enddate, type, citizenid, salary)
values (5214, 'Ali Plowright', to_date('01-12-1955', 'dd-mm-yyyy'), 5003, to_date('13-05-2020', 'dd-mm-yyyy'), to_date('20-12-2024', 'dd-mm-yyyy'), 1, 212, 15736);
insert into WORKER_TEMP_A (workerid, workername, birthdate, itsboss_workerid, startdate, enddate, type, citizenid, salary)
values (5215, 'Lucinda Thomson', to_date('21-06-1953', 'dd-mm-yyyy'), 5006, to_date('01-05-2016', 'dd-mm-yyyy'), to_date('11-04-2021', 'dd-mm-yyyy'), 1, 192, 14479);
insert into WORKER_TEMP_A (workerid, workername, birthdate, itsboss_workerid, startdate, enddate, type, citizenid, salary)
values (5216, 'Candice Gayle', to_date('04-10-1954', 'dd-mm-yyyy'), 5001, to_date('04-03-2019', 'dd-mm-yyyy'), to_date('14-12-2025', 'dd-mm-yyyy'), 2, 616, 16921);
insert into WORKER_TEMP_A (workerid, workername, birthdate, itsboss_workerid, startdate, enddate, type, citizenid, salary)
values (5217, 'Woody Keeslar', to_date('05-03-1957', 'dd-mm-yyyy'), 5008, to_date('15-12-2011', 'dd-mm-yyyy'), to_date('31-10-2025', 'dd-mm-yyyy'), 2, 631, 8545);
insert into WORKER_TEMP_A (workerid, workername, birthdate, itsboss_workerid, startdate, enddate, type, citizenid, salary)
values (5218, 'Charles Stanton', to_date('29-08-1952', 'dd-mm-yyyy'), 5004, to_date('17-02-2015', 'dd-mm-yyyy'), to_date('20-07-2020', 'dd-mm-yyyy'), 1, 97, 4100);
insert into WORKER_TEMP_A (workerid, workername, birthdate, itsboss_workerid, startdate, enddate, type, citizenid, salary)
values (5219, 'Gena Hornsby', to_date('18-03-1952', 'dd-mm-yyyy'), 5002, to_date('09-03-2011', 'dd-mm-yyyy'), to_date('13-07-2022', 'dd-mm-yyyy'), 2, 494, 15734);
insert into WORKER_TEMP_A (workerid, workername, birthdate, itsboss_workerid, startdate, enddate, type, citizenid, salary)
values (5220, 'Debi Russell', to_date('02-04-1955', 'dd-mm-yyyy'), 5003, to_date('10-02-2018', 'dd-mm-yyyy'), to_date('02-12-2023', 'dd-mm-yyyy'), 1, 214, 10845);
insert into WORKER_TEMP_A (workerid, workername, birthdate, itsboss_workerid, startdate, enddate, type, citizenid, salary)
values (5221, 'Russell Humphrey', to_date('08-07-1954', 'dd-mm-yyyy'), 5004, to_date('07-09-2019', 'dd-mm-yyyy'), to_date('22-10-2020', 'dd-mm-yyyy'), 1, 967, 17457);
insert into WORKER_TEMP_A (workerid, workername, birthdate, itsboss_workerid, startdate, enddate, type, citizenid, salary)
values (5222, 'Guy Redford', to_date('01-05-1956', 'dd-mm-yyyy'), 5003, to_date('07-11-2019', 'dd-mm-yyyy'), to_date('02-11-2022', 'dd-mm-yyyy'), 2, 745, 15636);
insert into WORKER_TEMP_A (workerid, workername, birthdate, itsboss_workerid, startdate, enddate, type, citizenid, salary)
values (5224, 'Val Trejo', to_date('19-11-1960', 'dd-mm-yyyy'), 5005, to_date('11-11-2009', 'dd-mm-yyyy'), to_date('24-07-2023', 'dd-mm-yyyy'), 2, 122, 8039);
insert into WORKER_TEMP_A (workerid, workername, birthdate, itsboss_workerid, startdate, enddate, type, citizenid, salary)
values (5225, 'Ruth Flatts', to_date('29-04-1957', 'dd-mm-yyyy'), 5004, to_date('04-11-2018', 'dd-mm-yyyy'), to_date('02-10-2025', 'dd-mm-yyyy'), 2, 187, 15146);
insert into WORKER_TEMP_A (workerid, workername, birthdate, itsboss_workerid, startdate, enddate, type, citizenid, salary)
values (5226, 'Rick Jeter', to_date('22-09-1952', 'dd-mm-yyyy'), 5008, to_date('26-02-2017', 'dd-mm-yyyy'), to_date('10-11-2024', 'dd-mm-yyyy'), 1, 676, 18901);
insert into WORKER_TEMP_A (workerid, workername, birthdate, itsboss_workerid, startdate, enddate, type, citizenid, salary)
values (5227, 'Will Torn', to_date('25-11-1955', 'dd-mm-yyyy'), 5004, to_date('03-01-2008', 'dd-mm-yyyy'), to_date('20-02-2022', 'dd-mm-yyyy'), 1, 615, 7344);
insert into WORKER_TEMP_A (workerid, workername, birthdate, itsboss_workerid, startdate, enddate, type, citizenid, salary)
values (5228, 'Carlene Hawthorne', to_date('30-10-1958', 'dd-mm-yyyy'), 5005, to_date('21-01-2017', 'dd-mm-yyyy'), to_date('18-11-2025', 'dd-mm-yyyy'), 2, 401, 7969);
insert into WORKER_TEMP_A (workerid, workername, birthdate, itsboss_workerid, startdate, enddate, type, citizenid, salary)
values (5229, 'Cherry Costner', to_date('16-08-1959', 'dd-mm-yyyy'), 5005, to_date('20-10-2014', 'dd-mm-yyyy'), to_date('28-06-2021', 'dd-mm-yyyy'), 2, 641, 12288);
insert into WORKER_TEMP_A (workerid, workername, birthdate, itsboss_workerid, startdate, enddate, type, citizenid, salary)
values (5230, 'Carla Stoltz', to_date('13-01-1959', 'dd-mm-yyyy'), 5001, to_date('02-06-2015', 'dd-mm-yyyy'), to_date('20-02-2025', 'dd-mm-yyyy'), 1, 430, 18237);
insert into WORKER_TEMP_A (workerid, workername, birthdate, itsboss_workerid, startdate, enddate, type, citizenid, salary)
values (5231, 'Geggy Uggams', to_date('25-09-1952', 'dd-mm-yyyy'), 5002, to_date('06-11-2019', 'dd-mm-yyyy'), to_date('28-10-2025', 'dd-mm-yyyy'), 1, 538, 18649);
insert into WORKER_TEMP_A (workerid, workername, birthdate, itsboss_workerid, startdate, enddate, type, citizenid, salary)
values (5232, 'Christmas Lennix', to_date('05-02-1953', 'dd-mm-yyyy'), 5009, to_date('11-05-2014', 'dd-mm-yyyy'), to_date('17-11-2022', 'dd-mm-yyyy'), 2, 516, 18488);
insert into WORKER_TEMP_A (workerid, workername, birthdate, itsboss_workerid, startdate, enddate, type, citizenid, salary)
values (5233, 'Don Lineback', to_date('08-01-1953', 'dd-mm-yyyy'), 5002, to_date('25-11-2011', 'dd-mm-yyyy'), to_date('03-09-2022', 'dd-mm-yyyy'), 2, 339, 13442);
insert into WORKER_TEMP_A (workerid, workername, birthdate, itsboss_workerid, startdate, enddate, type, citizenid, salary)
values (5234, 'Madeleine Dickinson', to_date('19-04-1953', 'dd-mm-yyyy'), 5007, to_date('08-06-2019', 'dd-mm-yyyy'), to_date('12-08-2025', 'dd-mm-yyyy'), 2, 145, 5675);
insert into WORKER_TEMP_A (workerid, workername, birthdate, itsboss_workerid, startdate, enddate, type, citizenid, salary)
values (5235, 'Rebeka Schwarzenegger', to_date('16-03-1956', 'dd-mm-yyyy'), 5007, to_date('20-02-2018', 'dd-mm-yyyy'), to_date('21-08-2020', 'dd-mm-yyyy'), 2, 896, 12699);
insert into WORKER_TEMP_A (workerid, workername, birthdate, itsboss_workerid, startdate, enddate, type, citizenid, salary)
values (5237, 'Treat Wine', to_date('02-02-1955', 'dd-mm-yyyy'), 5002, to_date('01-11-2016', 'dd-mm-yyyy'), to_date('23-03-2022', 'dd-mm-yyyy'), 2, 801, 11260);
insert into WORKER_TEMP_A (workerid, workername, birthdate, itsboss_workerid, startdate, enddate, type, citizenid, salary)
values (5238, 'Casey Beckinsale', to_date('10-04-1951', 'dd-mm-yyyy'), 5008, to_date('30-01-2017', 'dd-mm-yyyy'), to_date('23-10-2020', 'dd-mm-yyyy'), 2, 962, 5602);
insert into WORKER_TEMP_A (workerid, workername, birthdate, itsboss_workerid, startdate, enddate, type, citizenid, salary)
values (5239, 'Gates Cassel', to_date('29-01-1954', 'dd-mm-yyyy'), 5002, to_date('10-06-2009', 'dd-mm-yyyy'), to_date('11-11-2025', 'dd-mm-yyyy'), 2, 165, 8869);
insert into WORKER_TEMP_A (workerid, workername, birthdate, itsboss_workerid, startdate, enddate, type, citizenid, salary)
values (5240, 'Ray Burmester', to_date('15-06-1950', 'dd-mm-yyyy'), 5006, to_date('02-10-2018', 'dd-mm-yyyy'), to_date('09-01-2024', 'dd-mm-yyyy'), 2, 56, 16225);
insert into WORKER_TEMP_A (workerid, workername, birthdate, itsboss_workerid, startdate, enddate, type, citizenid, salary)
values (5241, 'Timothy Rivers', to_date('25-03-1959', 'dd-mm-yyyy'), 5006, to_date('05-03-2012', 'dd-mm-yyyy'), to_date('16-12-2024', 'dd-mm-yyyy'), 2, 603, 14340);
insert into WORKER_TEMP_A (workerid, workername, birthdate, itsboss_workerid, startdate, enddate, type, citizenid, salary)
values (5242, 'Yaphet Reeves', to_date('23-10-1952', 'dd-mm-yyyy'), 5010, to_date('30-08-2009', 'dd-mm-yyyy'), to_date('08-11-2023', 'dd-mm-yyyy'), 1, 760, 11650);
insert into WORKER_TEMP_A (workerid, workername, birthdate, itsboss_workerid, startdate, enddate, type, citizenid, salary)
values (5243, 'Bradley Pitney', to_date('02-11-1956', 'dd-mm-yyyy'), 5005, to_date('15-03-2016', 'dd-mm-yyyy'), to_date('23-04-2024', 'dd-mm-yyyy'), 1, 162, 20585);
insert into WORKER_TEMP_A (workerid, workername, birthdate, itsboss_workerid, startdate, enddate, type, citizenid, salary)
values (5244, 'Cherry Costner', to_date('27-05-1954', 'dd-mm-yyyy'), 5002, to_date('11-04-2014', 'dd-mm-yyyy'), to_date('14-10-2021', 'dd-mm-yyyy'), 1, 641, 9833);
insert into WORKER_TEMP_A (workerid, workername, birthdate, itsboss_workerid, startdate, enddate, type, citizenid, salary)
values (5245, 'Jonatha Oldman', to_date('20-11-1958', 'dd-mm-yyyy'), 5008, to_date('28-04-2012', 'dd-mm-yyyy'), to_date('11-12-2020', 'dd-mm-yyyy'), 1, 937, 21793);
insert into WORKER_TEMP_A (workerid, workername, birthdate, itsboss_workerid, startdate, enddate, type, citizenid, salary)
values (5246, 'Clay Cartlidge', to_date('28-01-1953', 'dd-mm-yyyy'), 5002, to_date('24-06-2017', 'dd-mm-yyyy'), to_date('21-08-2025', 'dd-mm-yyyy'), 1, 926, 15790);
insert into WORKER_TEMP_A (workerid, workername, birthdate, itsboss_workerid, startdate, enddate, type, citizenid, salary)
values (5247, 'Debby Aykroyd', to_date('05-08-1950', 'dd-mm-yyyy'), 5005, to_date('26-10-2018', 'dd-mm-yyyy'), to_date('13-11-2022', 'dd-mm-yyyy'), 2, 814, 4124);
insert into WORKER_TEMP_A (workerid, workername, birthdate, itsboss_workerid, startdate, enddate, type, citizenid, salary)
values (5249, 'Carlene Tate', to_date('07-12-1960', 'dd-mm-yyyy'), 5007, to_date('04-06-2019', 'dd-mm-yyyy'), to_date('29-02-2024', 'dd-mm-yyyy'), 1, 702, 6121);
insert into WORKER_TEMP_A (workerid, workername, birthdate, itsboss_workerid, startdate, enddate, type, citizenid, salary)
values (5060, 'Maxine Bullock', to_date('28-02-1957', 'dd-mm-yyyy'), 5001, to_date('09-09-2018', 'dd-mm-yyyy'), to_date('09-09-2024', 'dd-mm-yyyy'), 2, 310, 7602);
insert into WORKER_TEMP_A (workerid, workername, birthdate, itsboss_workerid, startdate, enddate, type, citizenid, salary)
values (5063, 'Rhett Carmen', to_date('15-10-1951', 'dd-mm-yyyy'), 5005, to_date('09-11-2017', 'dd-mm-yyyy'), to_date('18-03-2021', 'dd-mm-yyyy'), 2, 499, 13308);
insert into WORKER_TEMP_A (workerid, workername, birthdate, itsboss_workerid, startdate, enddate, type, citizenid, salary)
values (5066, 'Penelope Dafoe', to_date('22-10-1960', 'dd-mm-yyyy'), 5008, to_date('17-07-2016', 'dd-mm-yyyy'), to_date('27-09-2022', 'dd-mm-yyyy'), 2, 144, 20745);
insert into WORKER_TEMP_A (workerid, workername, birthdate, itsboss_workerid, startdate, enddate, type, citizenid, salary)
values (5069, 'Desmond Eldard', to_date('27-04-1959', 'dd-mm-yyyy'), 5003, to_date('20-11-2019', 'dd-mm-yyyy'), to_date('08-05-2023', 'dd-mm-yyyy'), 2, 272, 7354);
insert into WORKER_TEMP_A (workerid, workername, birthdate, itsboss_workerid, startdate, enddate, type, citizenid, salary)
values (5071, 'Merillee Whitaker', to_date('15-05-1956', 'dd-mm-yyyy'), 5005, to_date('03-10-2012', 'dd-mm-yyyy'), to_date('22-08-2020', 'dd-mm-yyyy'), 1, 456, 10997);
insert into WORKER_TEMP_A (workerid, workername, birthdate, itsboss_workerid, startdate, enddate, type, citizenid, salary)
values (5075, 'Cathy Coolidge', to_date('15-12-1952', 'dd-mm-yyyy'), 5004, to_date('21-08-2010', 'dd-mm-yyyy'), to_date('07-10-2025', 'dd-mm-yyyy'), 2, 75, 17007);
insert into WORKER_TEMP_A (workerid, workername, birthdate, itsboss_workerid, startdate, enddate, type, citizenid, salary)
values (5077, 'Johnny Clayton', to_date('22-05-1951', 'dd-mm-yyyy'), 5004, to_date('03-01-2010', 'dd-mm-yyyy'), to_date('22-12-2021', 'dd-mm-yyyy'), 2, 488, 5708);
insert into WORKER_TEMP_A (workerid, workername, birthdate, itsboss_workerid, startdate, enddate, type, citizenid, salary)
values (5080, 'Noah O''Sullivan', to_date('25-05-1957', 'dd-mm-yyyy'), 5007, to_date('18-07-2011', 'dd-mm-yyyy'), to_date('18-07-2025', 'dd-mm-yyyy'), 2, 396, 20107);
insert into WORKER_TEMP_A (workerid, workername, birthdate, itsboss_workerid, startdate, enddate, type, citizenid, salary)
values (5083, 'Jeff Reynolds', to_date('26-12-1951', 'dd-mm-yyyy'), 5001, to_date('08-10-2015', 'dd-mm-yyyy'), to_date('01-04-2025', 'dd-mm-yyyy'), 1, 141, 7093);
insert into WORKER_TEMP_A (workerid, workername, birthdate, itsboss_workerid, startdate, enddate, type, citizenid, salary)
values (5086, 'Bridget Dayne', to_date('10-05-1952', 'dd-mm-yyyy'), 5009, to_date('07-08-2010', 'dd-mm-yyyy'), to_date('12-09-2020', 'dd-mm-yyyy'), 1, 614, 16637);
insert into WORKER_TEMP_A (workerid, workername, birthdate, itsboss_workerid, startdate, enddate, type, citizenid, salary)
values (5089, 'Merillee Hughes', to_date('07-06-1953', 'dd-mm-yyyy'), 5007, to_date('21-04-2008', 'dd-mm-yyyy'), to_date('14-06-2022', 'dd-mm-yyyy'), 2, 118, 21176);
insert into WORKER_TEMP_A (workerid, workername, birthdate, itsboss_workerid, startdate, enddate, type, citizenid, salary)
values (5094, 'Freda Van Der Beek', to_date('06-02-1952', 'dd-mm-yyyy'), 5004, to_date('05-10-2014', 'dd-mm-yyyy'), to_date('19-06-2021', 'dd-mm-yyyy'), 1, 486, 12508);
insert into WORKER_TEMP_A (workerid, workername, birthdate, itsboss_workerid, startdate, enddate, type, citizenid, salary)
values (5097, 'Derrick Pierce', to_date('08-10-1951', 'dd-mm-yyyy'), 5003, to_date('08-05-2014', 'dd-mm-yyyy'), to_date('26-08-2022', 'dd-mm-yyyy'), 2, 31, 13336);
insert into WORKER_TEMP_A (workerid, workername, birthdate, itsboss_workerid, startdate, enddate, type, citizenid, salary)
values (5100, 'Suzi Colon', to_date('07-07-1957', 'dd-mm-yyyy'), 5002, to_date('10-12-2013', 'dd-mm-yyyy'), to_date('06-02-2025', 'dd-mm-yyyy'), 1, 49, 10748);
insert into WORKER_TEMP_A (workerid, workername, birthdate, itsboss_workerid, startdate, enddate, type, citizenid, salary)
values (5103, 'Chalee Martinez', to_date('21-02-1953', 'dd-mm-yyyy'), 5004, to_date('17-06-2019', 'dd-mm-yyyy'), to_date('27-02-2022', 'dd-mm-yyyy'), 2, 648, 16430);
insert into WORKER_TEMP_A (workerid, workername, birthdate, itsboss_workerid, startdate, enddate, type, citizenid, salary)
values (5105, 'Rodney Fender', to_date('07-02-1950', 'dd-mm-yyyy'), 5004, to_date('15-07-2013', 'dd-mm-yyyy'), to_date('26-03-2025', 'dd-mm-yyyy'), 1, 712, 8072);
insert into WORKER_TEMP_A (workerid, workername, birthdate, itsboss_workerid, startdate, enddate, type, citizenid, salary)
values (5108, 'Ivan Matheson', to_date('01-08-1954', 'dd-mm-yyyy'), 5004, to_date('10-03-2015', 'dd-mm-yyyy'), to_date('22-10-2023', 'dd-mm-yyyy'), 2, 930, 14078);
insert into WORKER_TEMP_A (workerid, workername, birthdate, itsboss_workerid, startdate, enddate, type, citizenid, salary)
values (5110, 'Julia De Almeida', to_date('25-11-1952', 'dd-mm-yyyy'), 5004, to_date('19-11-2008', 'dd-mm-yyyy'), to_date('23-06-2021', 'dd-mm-yyyy'), 1, 26, 18686);
insert into WORKER_TEMP_A (workerid, workername, birthdate, itsboss_workerid, startdate, enddate, type, citizenid, salary)
values (5114, 'Carlene Tate', to_date('09-03-1957', 'dd-mm-yyyy'), 5001, to_date('10-11-2015', 'dd-mm-yyyy'), to_date('16-02-2023', 'dd-mm-yyyy'), 2, 702, 7259);
insert into WORKER_TEMP_A (workerid, workername, birthdate, itsboss_workerid, startdate, enddate, type, citizenid, salary)
values (5116, 'Lynette Butler', to_date('19-07-1957', 'dd-mm-yyyy'), 5008, to_date('08-03-2016', 'dd-mm-yyyy'), to_date('13-10-2023', 'dd-mm-yyyy'), 2, 455, 10101);
insert into WORKER_TEMP_A (workerid, workername, birthdate, itsboss_workerid, startdate, enddate, type, citizenid, salary)
values (5119, 'Rowan Clark', to_date('18-03-1955', 'dd-mm-yyyy'), 5006, to_date('08-06-2017', 'dd-mm-yyyy'), to_date('22-11-2024', 'dd-mm-yyyy'), 1, 825, 5448);
insert into WORKER_TEMP_A (workerid, workername, birthdate, itsboss_workerid, startdate, enddate, type, citizenid, salary)
values (5123, 'Wesley Osbourne', to_date('29-05-1955', 'dd-mm-yyyy'), 5004, to_date('04-03-2015', 'dd-mm-yyyy'), to_date('02-09-2024', 'dd-mm-yyyy'), 1, 81, 9847);
insert into WORKER_TEMP_A (workerid, workername, birthdate, itsboss_workerid, startdate, enddate, type, citizenid, salary)
values (5125, 'Pat Beckham', to_date('21-06-1955', 'dd-mm-yyyy'), 5004, to_date('02-01-2016', 'dd-mm-yyyy'), to_date('23-09-2023', 'dd-mm-yyyy'), 2, 667, 9698);
insert into WORKER_TEMP_A (workerid, workername, birthdate, itsboss_workerid, startdate, enddate, type, citizenid, salary)
values (5128, 'Rick Harary', to_date('18-01-1959', 'dd-mm-yyyy'), 5005, to_date('20-06-2019', 'dd-mm-yyyy'), to_date('29-10-2022', 'dd-mm-yyyy'), 2, 671, 15761);
insert into WORKER_TEMP_A (workerid, workername, birthdate, itsboss_workerid, startdate, enddate, type, citizenid, salary)
values (5131, 'Ethan Sinatra', to_date('27-08-1959', 'dd-mm-yyyy'), 5003, to_date('28-10-2011', 'dd-mm-yyyy'), to_date('19-04-2025', 'dd-mm-yyyy'), 1, 668, 8953);
insert into WORKER_TEMP_A (workerid, workername, birthdate, itsboss_workerid, startdate, enddate, type, citizenid, salary)
values (5134, 'Bernie Linney', to_date('27-05-1952', 'dd-mm-yyyy'), 5002, to_date('26-02-2019', 'dd-mm-yyyy'), to_date('29-09-2022', 'dd-mm-yyyy'), 2, 761, 12908);
insert into WORKER_TEMP_A (workerid, workername, birthdate, itsboss_workerid, startdate, enddate, type, citizenid, salary)
values (5139, 'Bill Faithfull', to_date('04-03-1957', 'dd-mm-yyyy'), 5006, to_date('19-10-2016', 'dd-mm-yyyy'), to_date('26-12-2022', 'dd-mm-yyyy'), 2, 361, 17502);
insert into WORKER_TEMP_A (workerid, workername, birthdate, itsboss_workerid, startdate, enddate, type, citizenid, salary)
values (5141, 'Terrence Vaughn', to_date('07-03-1959', 'dd-mm-yyyy'), 5008, to_date('22-05-2012', 'dd-mm-yyyy'), to_date('08-03-2021', 'dd-mm-yyyy'), 2, 881, 20679);
insert into WORKER_TEMP_A (workerid, workername, birthdate, itsboss_workerid, startdate, enddate, type, citizenid, salary)
values (5145, 'Dwight Secada', to_date('05-04-1957', 'dd-mm-yyyy'), 5001, to_date('10-05-2011', 'dd-mm-yyyy'), to_date('20-08-2021', 'dd-mm-yyyy'), 1, 869, 9848);
insert into WORKER_TEMP_A (workerid, workername, birthdate, itsboss_workerid, startdate, enddate, type, citizenid, salary)
values (5148, 'Leslie Diesel', to_date('21-11-1959', 'dd-mm-yyyy'), 5008, to_date('24-06-2017', 'dd-mm-yyyy'), to_date('10-03-2022', 'dd-mm-yyyy'), 2, 651, 9542);
insert into WORKER_TEMP_A (workerid, workername, birthdate, itsboss_workerid, startdate, enddate, type, citizenid, salary)
values (5151, 'Angelina Lunch', to_date('08-09-1957', 'dd-mm-yyyy'), 5008, to_date('22-11-2014', 'dd-mm-yyyy'), to_date('30-06-2025', 'dd-mm-yyyy'), 2, 585, 19560);
insert into WORKER_TEMP_A (workerid, workername, birthdate, itsboss_workerid, startdate, enddate, type, citizenid, salary)
values (5153, 'Melba Jeffreys', to_date('22-08-1958', 'dd-mm-yyyy'), 5002, to_date('08-05-2009', 'dd-mm-yyyy'), to_date('28-01-2023', 'dd-mm-yyyy'), 1, 644, 17746);
insert into WORKER_TEMP_A (workerid, workername, birthdate, itsboss_workerid, startdate, enddate, type, citizenid, salary)
values (5157, 'Cornell Stevenson', to_date('10-12-1957', 'dd-mm-yyyy'), 5006, to_date('12-05-2019', 'dd-mm-yyyy'), to_date('03-09-2023', 'dd-mm-yyyy'), 2, 146, 12621);
insert into WORKER_TEMP_A (workerid, workername, birthdate, itsboss_workerid, startdate, enddate, type, citizenid, salary)
values (5159, 'Udo Chapman', to_date('28-05-1954', 'dd-mm-yyyy'), 5005, to_date('30-01-2010', 'dd-mm-yyyy'), to_date('17-06-2021', 'dd-mm-yyyy'), 1, 251, 6301);
insert into WORKER_TEMP_A (workerid, workername, birthdate, itsboss_workerid, startdate, enddate, type, citizenid, salary)
values (5162, 'Kelli Gryner', to_date('10-09-1955', 'dd-mm-yyyy'), 5005, to_date('19-12-2011', 'dd-mm-yyyy'), to_date('31-08-2022', 'dd-mm-yyyy'), 1, 140, 15126);
insert into WORKER_TEMP_A (workerid, workername, birthdate, itsboss_workerid, startdate, enddate, type, citizenid, salary)
values (5165, 'Joy Reeve', to_date('26-06-1954', 'dd-mm-yyyy'), 5003, to_date('29-06-2009', 'dd-mm-yyyy'), to_date('15-02-2022', 'dd-mm-yyyy'), 1, 331, 17381);
insert into WORKER_TEMP_A (workerid, workername, birthdate, itsboss_workerid, startdate, enddate, type, citizenid, salary)
values (5168, 'Andre Quinn', to_date('02-06-1960', 'dd-mm-yyyy'), 5008, to_date('04-03-2008', 'dd-mm-yyyy'), to_date('19-10-2024', 'dd-mm-yyyy'), 1, 379, 14671);
insert into WORKER_TEMP_A (workerid, workername, birthdate, itsboss_workerid, startdate, enddate, type, citizenid, salary)
values (5171, 'Caroline Huston', to_date('14-04-1955', 'dd-mm-yyyy'), 5007, to_date('12-05-2013', 'dd-mm-yyyy'), to_date('09-04-2023', 'dd-mm-yyyy'), 1, 261, 11230);
insert into WORKER_TEMP_A (workerid, workername, birthdate, itsboss_workerid, startdate, enddate, type, citizenid, salary)
values (5174, 'Denise Red', to_date('24-07-1958', 'dd-mm-yyyy'), 5006, to_date('12-02-2010', 'dd-mm-yyyy'), to_date('23-01-2024', 'dd-mm-yyyy'), 1, 507, 12201);
insert into WORKER_TEMP_A (workerid, workername, birthdate, itsboss_workerid, startdate, enddate, type, citizenid, salary)
values (5177, 'Mitchell Himmelman', to_date('28-03-1957', 'dd-mm-yyyy'), 5001, to_date('16-09-2018', 'dd-mm-yyyy'), to_date('22-08-2024', 'dd-mm-yyyy'), 1, 875, 13944);
insert into WORKER_TEMP_A (workerid, workername, birthdate, itsboss_workerid, startdate, enddate, type, citizenid, salary)
values (5180, 'Val Coolidge', to_date('27-01-1951', 'dd-mm-yyyy'), 5002, to_date('19-02-2015', 'dd-mm-yyyy'), to_date('13-10-2022', 'dd-mm-yyyy'), 1, 933, 13285);
insert into WORKER_TEMP_A (workerid, workername, birthdate, itsboss_workerid, startdate, enddate, type, citizenid, salary)
values (5185, 'Vivica Darren', to_date('06-11-1955', 'dd-mm-yyyy'), 5004, to_date('30-03-2010', 'dd-mm-yyyy'), to_date('25-07-2020', 'dd-mm-yyyy'), 2, 659, 10594);
insert into WORKER_TEMP_A (workerid, workername, birthdate, itsboss_workerid, startdate, enddate, type, citizenid, salary)
values (5189, 'Larry Randal', to_date('20-12-1957', 'dd-mm-yyyy'), 5007, to_date('10-07-2008', 'dd-mm-yyyy'), to_date('04-12-2020', 'dd-mm-yyyy'), 1, 703, 11396);
insert into WORKER_TEMP_A (workerid, workername, birthdate, itsboss_workerid, startdate, enddate, type, citizenid, salary)
values (5191, 'Donna Parish', to_date('16-05-1951', 'dd-mm-yyyy'), 5009, to_date('26-03-2014', 'dd-mm-yyyy'), to_date('22-11-2023', 'dd-mm-yyyy'), 2, 484, 21278);
insert into WORKER_TEMP_A (workerid, workername, birthdate, itsboss_workerid, startdate, enddate, type, citizenid, salary)
values (5194, 'Cherry Costner', to_date('29-11-1952', 'dd-mm-yyyy'), 5004, to_date('03-03-2013', 'dd-mm-yyyy'), to_date('04-08-2024', 'dd-mm-yyyy'), 2, 641, 13131);
insert into WORKER_TEMP_A (workerid, workername, birthdate, itsboss_workerid, startdate, enddate, type, citizenid, salary)
values (5197, 'Alec Haynes', to_date('04-06-1950', 'dd-mm-yyyy'), 5008, to_date('07-01-2018', 'dd-mm-yyyy'), to_date('30-07-2022', 'dd-mm-yyyy'), 2, 47, 15788);
insert into WORKER_TEMP_A (workerid, workername, birthdate, itsboss_workerid, startdate, enddate, type, citizenid, salary)
values (5003, 'Rachel Cummings', to_date('27-05-1952', 'dd-mm-yyyy'), 5005, to_date('16-04-2008', 'dd-mm-yyyy'), to_date('23-01-2025', 'dd-mm-yyyy'), 2, 387, 6202);
insert into WORKER_TEMP_A (workerid, workername, birthdate, itsboss_workerid, startdate, enddate, type, citizenid, salary)
values (5009, 'Austin Bruce', to_date('29-08-1950', 'dd-mm-yyyy'), 5008, to_date('30-12-2016', 'dd-mm-yyyy'), to_date('23-07-2024', 'dd-mm-yyyy'), 2, 360, 19384);
insert into WORKER_TEMP_A (workerid, workername, birthdate, itsboss_workerid, startdate, enddate, type, citizenid, salary)
values (5015, 'Jet Bacharach', to_date('22-04-1958', 'dd-mm-yyyy'), 5009, to_date('11-06-2016', 'dd-mm-yyyy'), to_date('13-06-2023', 'dd-mm-yyyy'), 1, 103, 12747);
insert into WORKER_TEMP_A (workerid, workername, birthdate, itsboss_workerid, startdate, enddate, type, citizenid, salary)
values (5021, 'Morris Savage', to_date('02-07-1956', 'dd-mm-yyyy'), 5001, to_date('01-07-2011', 'dd-mm-yyyy'), to_date('21-07-2021', 'dd-mm-yyyy'), 2, 257, 9929);
insert into WORKER_TEMP_A (workerid, workername, birthdate, itsboss_workerid, startdate, enddate, type, citizenid, salary)
values (5027, 'Tanya Farrell', to_date('18-08-1950', 'dd-mm-yyyy'), 5007, to_date('11-11-2010', 'dd-mm-yyyy'), to_date('27-11-2024', 'dd-mm-yyyy'), 1, 352, 9317);
insert into WORKER_TEMP_A (workerid, workername, birthdate, itsboss_workerid, startdate, enddate, type, citizenid, salary)
values (5033, 'Debi Russell', to_date('20-01-1951', 'dd-mm-yyyy'), 5001, to_date('20-12-2009', 'dd-mm-yyyy'), to_date('19-12-2022', 'dd-mm-yyyy'), 2, 214, 14895);
insert into WORKER_TEMP_A (workerid, workername, birthdate, itsboss_workerid, startdate, enddate, type, citizenid, salary)
values (5039, 'Harrison Cocker', to_date('27-01-1952', 'dd-mm-yyyy'), 5006, to_date('11-03-2018', 'dd-mm-yyyy'), to_date('27-06-2024', 'dd-mm-yyyy'), 2, 48, 8416);
insert into WORKER_TEMP_A (workerid, workername, birthdate, itsboss_workerid, startdate, enddate, type, citizenid, salary)
values (5045, 'Chloe Rubinek', to_date('12-03-1954', 'dd-mm-yyyy'), 5007, to_date('16-10-2013', 'dd-mm-yyyy'), to_date('30-09-2021', 'dd-mm-yyyy'), 1, 880, 13718);
insert into WORKER_TEMP_A (workerid, workername, birthdate, itsboss_workerid, startdate, enddate, type, citizenid, salary)
values (5051, 'Domingo Hong', to_date('17-02-1955', 'dd-mm-yyyy'), 5009, to_date('17-01-2011', 'dd-mm-yyyy'), to_date('19-01-2022', 'dd-mm-yyyy'), 2, 920, 12890);
insert into WORKER_TEMP_A (workerid, workername, birthdate, itsboss_workerid, startdate, enddate, type, citizenid, salary)
values (5056, 'Julia De Almeida', to_date('18-04-1954', 'dd-mm-yyyy'), 5006, to_date('30-11-2010', 'dd-mm-yyyy'), to_date('05-09-2023', 'dd-mm-yyyy'), 1, 26, 21948);
insert into WORKER_TEMP_A (workerid, workername, birthdate, itsboss_workerid, startdate, enddate, type, citizenid, salary)
values (5065, 'Wang Lofgren', to_date('10-03-1955', 'dd-mm-yyyy'), 5010, to_date('01-09-2010', 'dd-mm-yyyy'), to_date('16-04-2025', 'dd-mm-yyyy'), 1, 628, 13330);
insert into WORKER_TEMP_A (workerid, workername, birthdate, itsboss_workerid, startdate, enddate, type, citizenid, salary)
values (5074, 'Rupert Harrelson', to_date('16-10-1958', 'dd-mm-yyyy'), 5002, to_date('01-08-2014', 'dd-mm-yyyy'), to_date('18-02-2022', 'dd-mm-yyyy'), 2, 138, 4722);
insert into WORKER_TEMP_A (workerid, workername, birthdate, itsboss_workerid, startdate, enddate, type, citizenid, salary)
values (5084, 'King McKean', to_date('01-07-1959', 'dd-mm-yyyy'), 5004, to_date('26-12-2014', 'dd-mm-yyyy'), to_date('28-06-2025', 'dd-mm-yyyy'), 2, 910, 10869);
insert into WORKER_TEMP_A (workerid, workername, birthdate, itsboss_workerid, startdate, enddate, type, citizenid, salary)
values (5093, 'Emerson Neuwirth', to_date('26-10-1950', 'dd-mm-yyyy'), 5005, to_date('14-11-2019', 'dd-mm-yyyy'), to_date('01-07-2022', 'dd-mm-yyyy'), 1, 29, 9479);
insert into WORKER_TEMP_A (workerid, workername, birthdate, itsboss_workerid, startdate, enddate, type, citizenid, salary)
values (5102, 'Ralph Hopkins', to_date('17-07-1951', 'dd-mm-yyyy'), 5008, to_date('09-03-2008', 'dd-mm-yyyy'), to_date('14-04-2021', 'dd-mm-yyyy'), 2, 985, 12636);
insert into WORKER_TEMP_A (workerid, workername, birthdate, itsboss_workerid, startdate, enddate, type, citizenid, salary)
values (5112, 'Coley O''Hara', to_date('30-09-1954', 'dd-mm-yyyy'), 5002, to_date('12-02-2013', 'dd-mm-yyyy'), to_date('05-05-2023', 'dd-mm-yyyy'), 2, 783, 14427);
insert into WORKER_TEMP_A (workerid, workername, birthdate, itsboss_workerid, startdate, enddate, type, citizenid, salary)
values (5121, 'Ruth McGovern', to_date('19-09-1958', 'dd-mm-yyyy'), 5003, to_date('24-05-2015', 'dd-mm-yyyy'), to_date('11-09-2022', 'dd-mm-yyyy'), 2, 84, 4259);
insert into WORKER_TEMP_A (workerid, workername, birthdate, itsboss_workerid, startdate, enddate, type, citizenid, salary)
values (5129, 'Tyrone Sledge', to_date('21-08-1950', 'dd-mm-yyyy'), 5005, to_date('10-11-2017', 'dd-mm-yyyy'), to_date('13-03-2021', 'dd-mm-yyyy'), 2, 850, 21882);
insert into WORKER_TEMP_A (workerid, workername, birthdate, itsboss_workerid, startdate, enddate, type, citizenid, salary)
values (5138, 'Rebeka Schwarzenegger', to_date('04-01-1954', 'dd-mm-yyyy'), 5008, to_date('30-11-2017', 'dd-mm-yyyy'), to_date('20-02-2023', 'dd-mm-yyyy'), 2, 896, 10520);
insert into WORKER_TEMP_A (workerid, workername, birthdate, itsboss_workerid, startdate, enddate, type, citizenid, salary)
values (5149, 'Ani Neill', to_date('19-07-1951', 'dd-mm-yyyy'), 5005, to_date('05-02-2017', 'dd-mm-yyyy'), to_date('15-08-2020', 'dd-mm-yyyy'), 2, 545, 12451);
insert into WORKER_TEMP_A (workerid, workername, birthdate, itsboss_workerid, startdate, enddate, type, citizenid, salary)
values (5158, 'Russell Carradine', to_date('14-05-1959', 'dd-mm-yyyy'), 5009, to_date('08-09-2011', 'dd-mm-yyyy'), to_date('21-12-2020', 'dd-mm-yyyy'), 2, 503, 8818);
insert into WORKER_TEMP_A (workerid, workername, birthdate, itsboss_workerid, startdate, enddate, type, citizenid, salary)
values (5167, 'Naomi Lovitz', to_date('09-05-1959', 'dd-mm-yyyy'), 5001, to_date('03-07-2014', 'dd-mm-yyyy'), to_date('20-05-2021', 'dd-mm-yyyy'), 2, 508, 12182);
insert into WORKER_TEMP_A (workerid, workername, birthdate, itsboss_workerid, startdate, enddate, type, citizenid, salary)
values (5176, 'Cathy Coolidge', to_date('29-05-1955', 'dd-mm-yyyy'), 5010, to_date('09-06-2017', 'dd-mm-yyyy'), to_date('13-09-2025', 'dd-mm-yyyy'), 1, 75, 16903);
insert into WORKER_TEMP_A (workerid, workername, birthdate, itsboss_workerid, startdate, enddate, type, citizenid, salary)
values (5186, 'Vonda Hyde', to_date('21-12-1952', 'dd-mm-yyyy'), 5004, to_date('08-11-2016', 'dd-mm-yyyy'), to_date('28-06-2021', 'dd-mm-yyyy'), 2, 832, 14675);
insert into WORKER_TEMP_A (workerid, workername, birthdate, itsboss_workerid, startdate, enddate, type, citizenid, salary)
values (5195, 'Don Sepulveda', to_date('14-07-1957', 'dd-mm-yyyy'), 5006, to_date('19-04-2016', 'dd-mm-yyyy'), to_date('08-05-2025', 'dd-mm-yyyy'), 2, 592, 9005);
insert into WORKER_TEMP_A (workerid, workername, birthdate, itsboss_workerid, startdate, enddate, type, citizenid, salary)
values (5010, 'Rick Jeter', to_date('21-02-1953', 'dd-mm-yyyy'), 5002, to_date('04-01-2008', 'dd-mm-yyyy'), to_date('30-07-2020', 'dd-mm-yyyy'), 2, 676, 8672);
insert into WORKER_TEMP_A (workerid, workername, birthdate, itsboss_workerid, startdate, enddate, type, citizenid, salary)
values (5024, 'Joy Reeve', to_date('06-11-1957', 'dd-mm-yyyy'), 5003, to_date('03-11-2013', 'dd-mm-yyyy'), to_date('24-06-2022', 'dd-mm-yyyy'), 1, 331, 20223);
insert into WORKER_TEMP_A (workerid, workername, birthdate, itsboss_workerid, startdate, enddate, type, citizenid, salary)
values (5038, 'Dom Simpson', to_date('01-03-1952', 'dd-mm-yyyy'), 5009, to_date('03-09-2012', 'dd-mm-yyyy'), to_date('24-06-2024', 'dd-mm-yyyy'), 1, 758, 7259);
insert into WORKER_TEMP_A (workerid, workername, birthdate, itsboss_workerid, startdate, enddate, type, citizenid, salary)
values (5053, 'Seth Milsap', to_date('13-12-1950', 'dd-mm-yyyy'), 5004, to_date('13-08-2012', 'dd-mm-yyyy'), to_date('25-09-2024', 'dd-mm-yyyy'), 2, 201, 13869);
insert into WORKER_TEMP_A (workerid, workername, birthdate, itsboss_workerid, startdate, enddate, type, citizenid, salary)
values (5072, 'Hugo Durning', to_date('22-12-1960', 'dd-mm-yyyy'), 5007, to_date('22-02-2019', 'dd-mm-yyyy'), to_date('07-11-2024', 'dd-mm-yyyy'), 1, 340, 20694);
insert into WORKER_TEMP_A (workerid, workername, birthdate, itsboss_workerid, startdate, enddate, type, citizenid, salary)
values (5096, 'Vanessa Vance', to_date('16-09-1955', 'dd-mm-yyyy'), 5004, to_date('01-03-2017', 'dd-mm-yyyy'), to_date('20-12-2022', 'dd-mm-yyyy'), 1, 410, 8330);
insert into WORKER_TEMP_A (workerid, workername, birthdate, itsboss_workerid, startdate, enddate, type, citizenid, salary)
values (5120, 'Grant Atlas', to_date('22-11-1956', 'dd-mm-yyyy'), 5006, to_date('08-02-2013', 'dd-mm-yyyy'), to_date('24-01-2024', 'dd-mm-yyyy'), 2, 528, 10815);
insert into WORKER_TEMP_A (workerid, workername, birthdate, itsboss_workerid, startdate, enddate, type, citizenid, salary)
values (5143, 'Miranda Tinsley', to_date('15-10-1958', 'dd-mm-yyyy'), 5007, to_date('20-06-2008', 'dd-mm-yyyy'), to_date('21-09-2023', 'dd-mm-yyyy'), 1, 111, 10965);
insert into WORKER_TEMP_A (workerid, workername, birthdate, itsboss_workerid, startdate, enddate, type, citizenid, salary)
values (5169, 'Harris Valentin', to_date('19-03-1957', 'dd-mm-yyyy'), 5003, to_date('28-05-2008', 'dd-mm-yyyy'), to_date('06-01-2024', 'dd-mm-yyyy'), 1, 953, 7096);
insert into WORKER_TEMP_A (workerid, workername, birthdate, itsboss_workerid, startdate, enddate, type, citizenid, salary)
values (5192, 'Samantha Lunch', to_date('11-04-1958', 'dd-mm-yyyy'), 5010, to_date('13-01-2008', 'dd-mm-yyyy'), to_date('26-01-2023', 'dd-mm-yyyy'), 1, 757, 17042);
insert into WORKER_TEMP_A (workerid, workername, birthdate, itsboss_workerid, startdate, enddate, type, citizenid, salary)
values (5211, 'Nikki Close', to_date('23-11-1954', 'dd-mm-yyyy'), 5007, to_date('19-05-2017', 'dd-mm-yyyy'), to_date('22-12-2024', 'dd-mm-yyyy'), 2, 727, 9049);
insert into WORKER_TEMP_A (workerid, workername, birthdate, itsboss_workerid, startdate, enddate, type, citizenid, salary)
values (5223, 'Patty Herrmann', to_date('31-07-1956', 'dd-mm-yyyy'), 5002, to_date('14-11-2015', 'dd-mm-yyyy'), to_date('03-05-2023', 'dd-mm-yyyy'), 2, 958, 13112);
insert into WORKER_TEMP_A (workerid, workername, birthdate, itsboss_workerid, startdate, enddate, type, citizenid, salary)
values (5236, 'Edgar Bello', to_date('22-10-1953', 'dd-mm-yyyy'), 5004, to_date('24-12-2008', 'dd-mm-yyyy'), to_date('03-12-2021', 'dd-mm-yyyy'), 1, 3, 11401);
insert into WORKER_TEMP_A (workerid, workername, birthdate, itsboss_workerid, startdate, enddate, type, citizenid, salary)
values (5248, 'Nik Kweller', to_date('18-04-1959', 'dd-mm-yyyy'), 5004, to_date('02-12-2018', 'dd-mm-yyyy'), to_date('13-12-2022', 'dd-mm-yyyy'), 1, 996, 20233);
insert into WORKER_TEMP_A (workerid, workername, birthdate, itsboss_workerid, startdate, enddate, type, citizenid, salary)
values (5092, 'Nina Bassett', to_date('24-12-1956', 'dd-mm-yyyy'), 5010, to_date('27-09-2016', 'dd-mm-yyyy'), to_date('17-03-2023', 'dd-mm-yyyy'), 1, 479, 6584);
insert into WORKER_TEMP_A (workerid, workername, birthdate, itsboss_workerid, startdate, enddate, type, citizenid, salary)
values (5136, 'Karon Leachman', to_date('30-05-1959', 'dd-mm-yyyy'), 5004, to_date('22-03-2018', 'dd-mm-yyyy'), to_date('03-11-2024', 'dd-mm-yyyy'), 1, 131, 19748);
insert into WORKER_TEMP_A (workerid, workername, birthdate, itsboss_workerid, startdate, enddate, type, citizenid, salary)
values (5183, 'Kenny Jane', to_date('16-05-1953', 'dd-mm-yyyy'), 5002, to_date('16-11-2016', 'dd-mm-yyyy'), to_date('26-02-2025', 'dd-mm-yyyy'), 2, 539, 19269);
prompt 250 records loaded
prompt Enabling triggers for WORKER_TEMP_A...
alter table WORKER_TEMP_A enable all triggers;

set feedback on
set define on
prompt Done
