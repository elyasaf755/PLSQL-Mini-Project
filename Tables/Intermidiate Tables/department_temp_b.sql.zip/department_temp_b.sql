?��prompt PL/SQL Developer Export Tables for user SYSTEM
prompt Created by Evyatar on יום שני 10 אוגוסט 2020
set feedback off
set define off

prompt Creating DEPARTMENT_TEMP_B...
create table DEPARTMENT_TEMP_B
(
  depid        INTEGER not null,
  healthinstid NUMBER(3) not null,
  depname      VARCHAR2(50) not null,
  cityid       INTEGER,
  numberofbeds NUMBER(4) not null
)
tablespace SYSTEM
  pctfree 10
  pctused 40
  initrans 1
  maxtrans 255
  storage
  (
    initial 64K
    next 1M
    minextents 1
    maxextents unlimited
  );
alter table DEPARTMENT_TEMP_B
  add primary key (DEPID, HEALTHINSTID)
  disable
  novalidate;
alter table DEPARTMENT_TEMP_B
  add foreign key (HEALTHINSTID)
  references HEALTHINSTITUTION (HEALTHINSTID)
  disable
  novalidate;
alter table DEPARTMENT_TEMP_B
  add foreign key (CITYID)
  references CITY (CITYID)
  disable
  novalidate;

prompt Disabling triggers for DEPARTMENT_TEMP_B...
alter table DEPARTMENT_TEMP_B disable all triggers;
prompt Deleting DEPARTMENT_TEMP_B...
delete from DEPARTMENT_TEMP_B;
prompt Loading DEPARTMENT_TEMP_B...
insert into DEPARTMENT_TEMP_B (depid, healthinstid, depname, cityid, numberofbeds)
values (224, 435, 'Admissions', 28, 47);
insert into DEPARTMENT_TEMP_B (depid, healthinstid, depname, cityid, numberofbeds)
values (753, 861, 'Anesthetics', 4, 36);
insert into DEPARTMENT_TEMP_B (depid, healthinstid, depname, cityid, numberofbeds)
values (621, 726, 'Breast Screening', 27, 30);
insert into DEPARTMENT_TEMP_B (depid, healthinstid, depname, cityid, numberofbeds)
values (265, 758, 'Burn Center', 19, 39);
insert into DEPARTMENT_TEMP_B (depid, healthinstid, depname, cityid, numberofbeds)
values (540, 224, 'Cardiology', 4, 38);
insert into DEPARTMENT_TEMP_B (depid, healthinstid, depname, cityid, numberofbeds)
values (924, 42, 'CSSD', 16, 11);
insert into DEPARTMENT_TEMP_B (depid, healthinstid, depname, cityid, numberofbeds)
values (598, 116, 'Chaplaincy', 10, 26);
insert into DEPARTMENT_TEMP_B (depid, healthinstid, depname, cityid, numberofbeds)
values (789, 431, 'Coronary Care Unit', 10, 45);
insert into DEPARTMENT_TEMP_B (depid, healthinstid, depname, cityid, numberofbeds)
values (993, 380, 'Critical Care', 3, 13);
insert into DEPARTMENT_TEMP_B (depid, healthinstid, depname, cityid, numberofbeds)
values (97, 426, 'Diagnostic Imaging', 7, 11);
insert into DEPARTMENT_TEMP_B (depid, healthinstid, depname, cityid, numberofbeds)
values (976, 546, 'Discharge Lounge', 13, 16);
insert into DEPARTMENT_TEMP_B (depid, healthinstid, depname, cityid, numberofbeds)
values (399, 186, 'Elderly services', 26, 44);
insert into DEPARTMENT_TEMP_B (depid, healthinstid, depname, cityid, numberofbeds)
values (405, 632, 'Finance Department', 25, 26);
insert into DEPARTMENT_TEMP_B (depid, healthinstid, depname, cityid, numberofbeds)
values (633, 789, 'Gastroenterology', 21, 18);
insert into DEPARTMENT_TEMP_B (depid, healthinstid, depname, cityid, numberofbeds)
values (450, 860, 'General Services', 4, 13);
insert into DEPARTMENT_TEMP_B (depid, healthinstid, depname, cityid, numberofbeds)
values (959, 74, 'General Surgery', 2, 41);
insert into DEPARTMENT_TEMP_B (depid, healthinstid, depname, cityid, numberofbeds)
values (336, 472, 'Gynecology', 4, 48);
insert into DEPARTMENT_TEMP_B (depid, healthinstid, depname, cityid, numberofbeds)
values (890, 514, 'Haematology', 17, 38);
insert into DEPARTMENT_TEMP_B (depid, healthinstid, depname, cityid, numberofbeds)
values (777, 680, 'Health & Safety', 10, 41);
insert into DEPARTMENT_TEMP_B (depid, healthinstid, depname, cityid, numberofbeds)
values (179, 213, 'Intensive Care Unit', 9, 30);
insert into DEPARTMENT_TEMP_B (depid, healthinstid, depname, cityid, numberofbeds)
values (365, 51, 'Human Resources', 8, 38);
insert into DEPARTMENT_TEMP_B (depid, healthinstid, depname, cityid, numberofbeds)
values (600, 581, 'Infection Control', 29, 21);
insert into DEPARTMENT_TEMP_B (depid, healthinstid, depname, cityid, numberofbeds)
values (528, 78, 'Information Management', 15, 10);
insert into DEPARTMENT_TEMP_B (depid, healthinstid, depname, cityid, numberofbeds)
values (492, 895, 'Maternity', 24, 31);
insert into DEPARTMENT_TEMP_B (depid, healthinstid, depname, cityid, numberofbeds)
values (220, 301, 'Medical Records', 19, 12);
insert into DEPARTMENT_TEMP_B (depid, healthinstid, depname, cityid, numberofbeds)
values (33, 151, 'Microbiology', 17, 43);
insert into DEPARTMENT_TEMP_B (depid, healthinstid, depname, cityid, numberofbeds)
values (121, 170, 'Neonatal', 6, 30);
insert into DEPARTMENT_TEMP_B (depid, healthinstid, depname, cityid, numberofbeds)
values (22, 912, 'Neurology', 18, 13);
insert into DEPARTMENT_TEMP_B (depid, healthinstid, depname, cityid, numberofbeds)
values (830, 501, 'Nutrition and Dietetics', 10, 16);
insert into DEPARTMENT_TEMP_B (depid, healthinstid, depname, cityid, numberofbeds)
values (413, 893, 'Obstetrics/Gynecology', 18, 13);
insert into DEPARTMENT_TEMP_B (depid, healthinstid, depname, cityid, numberofbeds)
values (425, 857, 'Occupational Therapy', 16, 37);
insert into DEPARTMENT_TEMP_B (depid, healthinstid, depname, cityid, numberofbeds)
values (329, 443, 'Oncology', 24, 28);
insert into DEPARTMENT_TEMP_B (depid, healthinstid, depname, cityid, numberofbeds)
values (556, 297, 'Ophthalmology', 8, 43);
insert into DEPARTMENT_TEMP_B (depid, healthinstid, depname, cityid, numberofbeds)
values (20, 566, 'Orthopaedics', 10, 48);
insert into DEPARTMENT_TEMP_B (depid, healthinstid, depname, cityid, numberofbeds)
values (717, 164, 'Otolaryngology', 8, 41);
insert into DEPARTMENT_TEMP_B (depid, healthinstid, depname, cityid, numberofbeds)
values (853, 996, 'Pain Management', 2, 16);
insert into DEPARTMENT_TEMP_B (depid, healthinstid, depname, cityid, numberofbeds)
values (233, 652, 'Patient Accounts', 27, 33);
insert into DEPARTMENT_TEMP_B (depid, healthinstid, depname, cityid, numberofbeds)
values (734, 582, 'Patient Services', 3, 20);
insert into DEPARTMENT_TEMP_B (depid, healthinstid, depname, cityid, numberofbeds)
values (124, 564, 'Pharmacy', 19, 37);
insert into DEPARTMENT_TEMP_B (depid, healthinstid, depname, cityid, numberofbeds)
values (245, 815, 'Physiotherapy', 15, 33);
insert into DEPARTMENT_TEMP_B (depid, healthinstid, depname, cityid, numberofbeds)
values (803, 820, 'Purchasing & Supplies', 5, 36);
insert into DEPARTMENT_TEMP_B (depid, healthinstid, depname, cityid, numberofbeds)
values (110, 157, 'Radiology', 7, 42);
insert into DEPARTMENT_TEMP_B (depid, healthinstid, depname, cityid, numberofbeds)
values (631, 281, 'Radiotherapy', 25, 14);
insert into DEPARTMENT_TEMP_B (depid, healthinstid, depname, cityid, numberofbeds)
values (149, 420, 'Renal', 23, 25);
insert into DEPARTMENT_TEMP_B (depid, healthinstid, depname, cityid, numberofbeds)
values (172, 408, 'Rheumatology', 19, 11);
insert into DEPARTMENT_TEMP_B (depid, healthinstid, depname, cityid, numberofbeds)
values (710, 279, 'Sexual Health', 22, 17);
insert into DEPARTMENT_TEMP_B (depid, healthinstid, depname, cityid, numberofbeds)
values (185, 423, 'Social Work', 17, 44);
insert into DEPARTMENT_TEMP_B (depid, healthinstid, depname, cityid, numberofbeds)
values (513, 573, 'Urology', 12, 10);
insert into DEPARTMENT_TEMP_B (depid, healthinstid, depname, cityid, numberofbeds)
values (226, 292, 'Occupational Therapy', 8, 25);
insert into DEPARTMENT_TEMP_B (depid, healthinstid, depname, cityid, numberofbeds)
values (478, 146, 'Oncology', 22, 40);
insert into DEPARTMENT_TEMP_B (depid, healthinstid, depname, cityid, numberofbeds)
values (958, 338, 'Ophthalmology', 27, 11);
insert into DEPARTMENT_TEMP_B (depid, healthinstid, depname, cityid, numberofbeds)
values (792, 364, 'Orthopaedics', 4, 37);
insert into DEPARTMENT_TEMP_B (depid, healthinstid, depname, cityid, numberofbeds)
values (419, 340, 'Otolaryngology', 8, 25);
insert into DEPARTMENT_TEMP_B (depid, healthinstid, depname, cityid, numberofbeds)
values (977, 180, 'Pain Management', 8, 38);
insert into DEPARTMENT_TEMP_B (depid, healthinstid, depname, cityid, numberofbeds)
values (688, 713, 'Patient Accounts', 5, 25);
insert into DEPARTMENT_TEMP_B (depid, healthinstid, depname, cityid, numberofbeds)
values (480, 809, 'Patient Services', 17, 24);
insert into DEPARTMENT_TEMP_B (depid, healthinstid, depname, cityid, numberofbeds)
values (741, 839, 'Pharmacy', 20, 10);
insert into DEPARTMENT_TEMP_B (depid, healthinstid, depname, cityid, numberofbeds)
values (964, 656, 'Physiotherapy', 3, 25);
insert into DEPARTMENT_TEMP_B (depid, healthinstid, depname, cityid, numberofbeds)
values (296, 834, 'Purchasing & Supplies', 8, 16);
insert into DEPARTMENT_TEMP_B (depid, healthinstid, depname, cityid, numberofbeds)
values (951, 34, 'Radiology', 13, 20);
insert into DEPARTMENT_TEMP_B (depid, healthinstid, depname, cityid, numberofbeds)
values (758, 616, 'Radiotherapy', 3, 47);
insert into DEPARTMENT_TEMP_B (depid, healthinstid, depname, cityid, numberofbeds)
values (820, 931, 'Renal', 25, 14);
insert into DEPARTMENT_TEMP_B (depid, healthinstid, depname, cityid, numberofbeds)
values (799, 503, 'Rheumatology', 4, 38);
insert into DEPARTMENT_TEMP_B (depid, healthinstid, depname, cityid, numberofbeds)
values (670, 748, 'Sexual Health', 10, 26);
insert into DEPARTMENT_TEMP_B (depid, healthinstid, depname, cityid, numberofbeds)
values (321, 381, 'Social Work', 17, 35);
insert into DEPARTMENT_TEMP_B (depid, healthinstid, depname, cityid, numberofbeds)
values (246, 352, 'Burn Center', 20, 28);
insert into DEPARTMENT_TEMP_B (depid, healthinstid, depname, cityid, numberofbeds)
values (790, 25, 'Cardiology', 27, 47);
insert into DEPARTMENT_TEMP_B (depid, healthinstid, depname, cityid, numberofbeds)
values (684, 31, 'CSSD', 22, 11);
insert into DEPARTMENT_TEMP_B (depid, healthinstid, depname, cityid, numberofbeds)
values (928, 200, 'Chaplaincy', 23, 31);
insert into DEPARTMENT_TEMP_B (depid, healthinstid, depname, cityid, numberofbeds)
values (846, 107, 'Coronary Care Unit', 22, 22);
insert into DEPARTMENT_TEMP_B (depid, healthinstid, depname, cityid, numberofbeds)
values (640, 601, 'Critical Care', 16, 27);
insert into DEPARTMENT_TEMP_B (depid, healthinstid, depname, cityid, numberofbeds)
values (251, 310, 'Diagnostic Imaging', 8, 49);
insert into DEPARTMENT_TEMP_B (depid, healthinstid, depname, cityid, numberofbeds)
values (572, 526, 'Discharge Lounge', 23, 47);
insert into DEPARTMENT_TEMP_B (depid, healthinstid, depname, cityid, numberofbeds)
values (926, 831, 'Elderly services', 5, 48);
insert into DEPARTMENT_TEMP_B (depid, healthinstid, depname, cityid, numberofbeds)
values (501, 121, 'Finance Department', 2, 33);
insert into DEPARTMENT_TEMP_B (depid, healthinstid, depname, cityid, numberofbeds)
values (953, 313, 'Gastroenterology', 26, 11);
insert into DEPARTMENT_TEMP_B (depid, healthinstid, depname, cityid, numberofbeds)
values (737, 339, 'General Services', 21, 22);
insert into DEPARTMENT_TEMP_B (depid, healthinstid, depname, cityid, numberofbeds)
values (608, 942, 'General Surgery', 3, 39);
insert into DEPARTMENT_TEMP_B (depid, healthinstid, depname, cityid, numberofbeds)
values (886, 363, 'Gynecology', 6, 46);
insert into DEPARTMENT_TEMP_B (depid, healthinstid, depname, cityid, numberofbeds)
values (749, 572, 'Haematology', 27, 37);
insert into DEPARTMENT_TEMP_B (depid, healthinstid, depname, cityid, numberofbeds)
values (130, 111, 'Health & Safety', 9, 49);
insert into DEPARTMENT_TEMP_B (depid, healthinstid, depname, cityid, numberofbeds)
values (155, 555, 'Intensive Care Unit', 3, 49);
insert into DEPARTMENT_TEMP_B (depid, healthinstid, depname, cityid, numberofbeds)
values (189, 714, 'Human Resources', 21, 39);
insert into DEPARTMENT_TEMP_B (depid, healthinstid, depname, cityid, numberofbeds)
values (16, 584, 'Admissions', 17, 11);
insert into DEPARTMENT_TEMP_B (depid, healthinstid, depname, cityid, numberofbeds)
values (780, 854, 'Anesthetics', 24, 11);
insert into DEPARTMENT_TEMP_B (depid, healthinstid, depname, cityid, numberofbeds)
values (731, 892, 'Breast Screening', 20, 39);
insert into DEPARTMENT_TEMP_B (depid, healthinstid, depname, cityid, numberofbeds)
values (880, 781, 'Burn Center', 12, 10);
insert into DEPARTMENT_TEMP_B (depid, healthinstid, depname, cityid, numberofbeds)
values (427, 309, 'Cardiology', 27, 35);
insert into DEPARTMENT_TEMP_B (depid, healthinstid, depname, cityid, numberofbeds)
values (763, 883, 'CSSD', 12, 48);
insert into DEPARTMENT_TEMP_B (depid, healthinstid, depname, cityid, numberofbeds)
values (549, 319, 'Chaplaincy', 15, 24);
insert into DEPARTMENT_TEMP_B (depid, healthinstid, depname, cityid, numberofbeds)
values (29, 174, 'Coronary Care Unit', 14, 42);
insert into DEPARTMENT_TEMP_B (depid, healthinstid, depname, cityid, numberofbeds)
values (75, 427, 'Critical Care', 29, 41);
insert into DEPARTMENT_TEMP_B (depid, healthinstid, depname, cityid, numberofbeds)
values (503, 455, 'Diagnostic Imaging', 27, 47);
insert into DEPARTMENT_TEMP_B (depid, healthinstid, depname, cityid, numberofbeds)
values (491, 331, 'Discharge Lounge', 21, 17);
insert into DEPARTMENT_TEMP_B (depid, healthinstid, depname, cityid, numberofbeds)
values (712, 589, 'Elderly services', 24, 31);
insert into DEPARTMENT_TEMP_B (depid, healthinstid, depname, cityid, numberofbeds)
values (93, 759, 'Finance Department', 20, 12);
insert into DEPARTMENT_TEMP_B (depid, healthinstid, depname, cityid, numberofbeds)
values (682, 865, 'Gastroenterology', 26, 17);
insert into DEPARTMENT_TEMP_B (depid, healthinstid, depname, cityid, numberofbeds)
values (279, 648, 'General Services', 22, 49);
insert into DEPARTMENT_TEMP_B (depid, healthinstid, depname, cityid, numberofbeds)
values (203, 547, 'General Surgery', 15, 16);
insert into DEPARTMENT_TEMP_B (depid, healthinstid, depname, cityid, numberofbeds)
values (735, 360, 'Gynecology', 12, 42);
insert into DEPARTMENT_TEMP_B (depid, healthinstid, depname, cityid, numberofbeds)
values (716, 435, 'Haematology', 14, 42);
insert into DEPARTMENT_TEMP_B (depid, healthinstid, depname, cityid, numberofbeds)
values (838, 861, 'Health & Safety', 3, 36);
insert into DEPARTMENT_TEMP_B (depid, healthinstid, depname, cityid, numberofbeds)
values (473, 726, 'Ophthalmology', 18, 38);
insert into DEPARTMENT_TEMP_B (depid, healthinstid, depname, cityid, numberofbeds)
values (306, 758, 'Orthopaedics', 1, 41);
insert into DEPARTMENT_TEMP_B (depid, healthinstid, depname, cityid, numberofbeds)
values (847, 224, 'Otolaryngology', 26, 50);
insert into DEPARTMENT_TEMP_B (depid, healthinstid, depname, cityid, numberofbeds)
values (356, 42, 'Pain Management', 28, 32);
insert into DEPARTMENT_TEMP_B (depid, healthinstid, depname, cityid, numberofbeds)
values (496, 116, 'Patient Accounts', 30, 42);
insert into DEPARTMENT_TEMP_B (depid, healthinstid, depname, cityid, numberofbeds)
values (767, 431, 'Patient Services', 28, 42);
insert into DEPARTMENT_TEMP_B (depid, healthinstid, depname, cityid, numberofbeds)
values (530, 380, 'Pharmacy', 9, 35);
insert into DEPARTMENT_TEMP_B (depid, healthinstid, depname, cityid, numberofbeds)
values (642, 426, 'Physiotherapy', 10, 16);
insert into DEPARTMENT_TEMP_B (depid, healthinstid, depname, cityid, numberofbeds)
values (471, 546, 'Purchasing & Supplies', 14, 39);
insert into DEPARTMENT_TEMP_B (depid, healthinstid, depname, cityid, numberofbeds)
values (218, 186, 'Radiology', 29, 38);
insert into DEPARTMENT_TEMP_B (depid, healthinstid, depname, cityid, numberofbeds)
values (591, 632, 'Radiotherapy', 5, 25);
insert into DEPARTMENT_TEMP_B (depid, healthinstid, depname, cityid, numberofbeds)
values (526, 789, 'Renal', 28, 32);
insert into DEPARTMENT_TEMP_B (depid, healthinstid, depname, cityid, numberofbeds)
values (406, 860, 'Rheumatology', 29, 48);
insert into DEPARTMENT_TEMP_B (depid, healthinstid, depname, cityid, numberofbeds)
values (81, 74, 'Sexual Health', 26, 35);
insert into DEPARTMENT_TEMP_B (depid, healthinstid, depname, cityid, numberofbeds)
values (67, 472, 'Social Work', 14, 41);
insert into DEPARTMENT_TEMP_B (depid, healthinstid, depname, cityid, numberofbeds)
values (981, 514, 'Urology', 14, 40);
insert into DEPARTMENT_TEMP_B (depid, healthinstid, depname, cityid, numberofbeds)
values (686, 680, 'Occupational Therapy', 7, 39);
insert into DEPARTMENT_TEMP_B (depid, healthinstid, depname, cityid, numberofbeds)
values (87, 213, 'Oncology', 28, 47);
insert into DEPARTMENT_TEMP_B (depid, healthinstid, depname, cityid, numberofbeds)
values (531, 51, 'Ophthalmology', 5, 25);
insert into DEPARTMENT_TEMP_B (depid, healthinstid, depname, cityid, numberofbeds)
values (184, 581, 'Orthopaedics', 11, 40);
insert into DEPARTMENT_TEMP_B (depid, healthinstid, depname, cityid, numberofbeds)
values (619, 78, 'Otolaryngology', 21, 27);
insert into DEPARTMENT_TEMP_B (depid, healthinstid, depname, cityid, numberofbeds)
values (332, 895, 'Pain Management', 20, 33);
insert into DEPARTMENT_TEMP_B (depid, healthinstid, depname, cityid, numberofbeds)
values (26, 301, 'Patient Accounts', 14, 24);
insert into DEPARTMENT_TEMP_B (depid, healthinstid, depname, cityid, numberofbeds)
values (114, 151, 'Patient Services', 10, 24);
insert into DEPARTMENT_TEMP_B (depid, healthinstid, depname, cityid, numberofbeds)
values (512, 170, 'Pharmacy', 27, 47);
insert into DEPARTMENT_TEMP_B (depid, healthinstid, depname, cityid, numberofbeds)
values (433, 912, 'Physiotherapy', 20, 14);
insert into DEPARTMENT_TEMP_B (depid, healthinstid, depname, cityid, numberofbeds)
values (660, 501, 'Purchasing & Supplies', 26, 43);
insert into DEPARTMENT_TEMP_B (depid, healthinstid, depname, cityid, numberofbeds)
values (667, 893, 'Radiology', 15, 38);
insert into DEPARTMENT_TEMP_B (depid, healthinstid, depname, cityid, numberofbeds)
values (460, 857, 'Radiotherapy', 9, 39);
insert into DEPARTMENT_TEMP_B (depid, healthinstid, depname, cityid, numberofbeds)
values (895, 443, 'Renal', 5, 39);
insert into DEPARTMENT_TEMP_B (depid, healthinstid, depname, cityid, numberofbeds)
values (368, 297, 'Rheumatology', 5, 29);
insert into DEPARTMENT_TEMP_B (depid, healthinstid, depname, cityid, numberofbeds)
values (74, 566, 'Sexual Health', 23, 40);
insert into DEPARTMENT_TEMP_B (depid, healthinstid, depname, cityid, numberofbeds)
values (738, 164, 'Social Work', 27, 44);
insert into DEPARTMENT_TEMP_B (depid, healthinstid, depname, cityid, numberofbeds)
values (88, 996, 'Burn Center', 5, 46);
insert into DEPARTMENT_TEMP_B (depid, healthinstid, depname, cityid, numberofbeds)
values (866, 652, 'Cardiology', 1, 41);
insert into DEPARTMENT_TEMP_B (depid, healthinstid, depname, cityid, numberofbeds)
values (205, 582, 'CSSD', 21, 16);
insert into DEPARTMENT_TEMP_B (depid, healthinstid, depname, cityid, numberofbeds)
values (157, 564, 'Chaplaincy', 16, 37);
insert into DEPARTMENT_TEMP_B (depid, healthinstid, depname, cityid, numberofbeds)
values (932, 815, 'Coronary Care Unit', 3, 38);
insert into DEPARTMENT_TEMP_B (depid, healthinstid, depname, cityid, numberofbeds)
values (779, 820, 'Critical Care', 28, 21);
insert into DEPARTMENT_TEMP_B (depid, healthinstid, depname, cityid, numberofbeds)
values (766, 157, 'Diagnostic Imaging', 25, 23);
insert into DEPARTMENT_TEMP_B (depid, healthinstid, depname, cityid, numberofbeds)
values (366, 281, 'Discharge Lounge', 26, 13);
insert into DEPARTMENT_TEMP_B (depid, healthinstid, depname, cityid, numberofbeds)
values (592, 420, 'Elderly services', 16, 16);
insert into DEPARTMENT_TEMP_B (depid, healthinstid, depname, cityid, numberofbeds)
values (438, 408, 'Finance Department', 13, 12);
insert into DEPARTMENT_TEMP_B (depid, healthinstid, depname, cityid, numberofbeds)
values (393, 279, 'Gastroenterology', 12, 24);
insert into DEPARTMENT_TEMP_B (depid, healthinstid, depname, cityid, numberofbeds)
values (760, 423, 'General Services', 26, 43);
insert into DEPARTMENT_TEMP_B (depid, healthinstid, depname, cityid, numberofbeds)
values (791, 573, 'General Surgery', 11, 44);
insert into DEPARTMENT_TEMP_B (depid, healthinstid, depname, cityid, numberofbeds)
values (875, 292, 'Gynecology', 6, 39);
insert into DEPARTMENT_TEMP_B (depid, healthinstid, depname, cityid, numberofbeds)
values (223, 146, 'Purchasing & Supplies', 30, 13);
insert into DEPARTMENT_TEMP_B (depid, healthinstid, depname, cityid, numberofbeds)
values (338, 338, 'Radiology', 18, 30);
insert into DEPARTMENT_TEMP_B (depid, healthinstid, depname, cityid, numberofbeds)
values (219, 364, 'Radiotherapy', 1, 46);
insert into DEPARTMENT_TEMP_B (depid, healthinstid, depname, cityid, numberofbeds)
values (994, 340, 'Renal', 2, 23);
insert into DEPARTMENT_TEMP_B (depid, healthinstid, depname, cityid, numberofbeds)
values (289, 180, 'Rheumatology', 6, 41);
insert into DEPARTMENT_TEMP_B (depid, healthinstid, depname, cityid, numberofbeds)
values (873, 713, 'Sexual Health', 2, 26);
insert into DEPARTMENT_TEMP_B (depid, healthinstid, depname, cityid, numberofbeds)
values (107, 809, 'Social Work', 27, 17);
insert into DEPARTMENT_TEMP_B (depid, healthinstid, depname, cityid, numberofbeds)
values (651, 839, 'Urology', 12, 37);
insert into DEPARTMENT_TEMP_B (depid, healthinstid, depname, cityid, numberofbeds)
values (197, 656, 'Occupational Therapy', 15, 46);
insert into DEPARTMENT_TEMP_B (depid, healthinstid, depname, cityid, numberofbeds)
values (388, 834, 'Oncology', 20, 25);
insert into DEPARTMENT_TEMP_B (depid, healthinstid, depname, cityid, numberofbeds)
values (781, 34, 'Ophthalmology', 22, 24);
insert into DEPARTMENT_TEMP_B (depid, healthinstid, depname, cityid, numberofbeds)
values (161, 616, 'Orthopaedics', 13, 37);
insert into DEPARTMENT_TEMP_B (depid, healthinstid, depname, cityid, numberofbeds)
values (458, 931, 'Otolaryngology', 8, 47);
insert into DEPARTMENT_TEMP_B (depid, healthinstid, depname, cityid, numberofbeds)
values (476, 503, 'Pain Management', 4, 30);
insert into DEPARTMENT_TEMP_B (depid, healthinstid, depname, cityid, numberofbeds)
values (652, 748, 'Patient Accounts', 13, 40);
insert into DEPARTMENT_TEMP_B (depid, healthinstid, depname, cityid, numberofbeds)
values (337, 381, 'Patient Services', 3, 48);
insert into DEPARTMENT_TEMP_B (depid, healthinstid, depname, cityid, numberofbeds)
values (547, 352, 'Pharmacy', 11, 34);
insert into DEPARTMENT_TEMP_B (depid, healthinstid, depname, cityid, numberofbeds)
values (546, 25, 'Physiotherapy', 4, 47);
insert into DEPARTMENT_TEMP_B (depid, healthinstid, depname, cityid, numberofbeds)
values (747, 31, 'Purchasing & Supplies', 5, 46);
insert into DEPARTMENT_TEMP_B (depid, healthinstid, depname, cityid, numberofbeds)
values (967, 200, 'Radiology', 19, 46);
insert into DEPARTMENT_TEMP_B (depid, healthinstid, depname, cityid, numberofbeds)
values (415, 107, 'Radiotherapy', 14, 12);
insert into DEPARTMENT_TEMP_B (depid, healthinstid, depname, cityid, numberofbeds)
values (561, 601, 'Renal', 29, 14);
insert into DEPARTMENT_TEMP_B (depid, healthinstid, depname, cityid, numberofbeds)
values (479, 310, 'Rheumatology', 12, 41);
insert into DEPARTMENT_TEMP_B (depid, healthinstid, depname, cityid, numberofbeds)
values (736, 526, 'Sexual Health', 9, 21);
insert into DEPARTMENT_TEMP_B (depid, healthinstid, depname, cityid, numberofbeds)
values (343, 831, 'Social Work', 3, 27);
insert into DEPARTMENT_TEMP_B (depid, healthinstid, depname, cityid, numberofbeds)
values (882, 121, 'Burn Center', 14, 31);
insert into DEPARTMENT_TEMP_B (depid, healthinstid, depname, cityid, numberofbeds)
values (198, 313, 'Cardiology', 17, 45);
insert into DEPARTMENT_TEMP_B (depid, healthinstid, depname, cityid, numberofbeds)
values (641, 339, 'CSSD', 22, 40);
insert into DEPARTMENT_TEMP_B (depid, healthinstid, depname, cityid, numberofbeds)
values (713, 942, 'Chaplaincy', 17, 49);
insert into DEPARTMENT_TEMP_B (depid, healthinstid, depname, cityid, numberofbeds)
values (353, 363, 'Coronary Care Unit', 30, 36);
insert into DEPARTMENT_TEMP_B (depid, healthinstid, depname, cityid, numberofbeds)
values (797, 572, 'Critical Care', 18, 35);
insert into DEPARTMENT_TEMP_B (depid, healthinstid, depname, cityid, numberofbeds)
values (645, 111, 'Diagnostic Imaging', 9, 43);
insert into DEPARTMENT_TEMP_B (depid, healthinstid, depname, cityid, numberofbeds)
values (811, 555, 'Discharge Lounge', 15, 17);
insert into DEPARTMENT_TEMP_B (depid, healthinstid, depname, cityid, numberofbeds)
values (548, 714, 'Elderly services', 20, 28);
insert into DEPARTMENT_TEMP_B (depid, healthinstid, depname, cityid, numberofbeds)
values (0, 584, 'Finance Department', 27, 41);
insert into DEPARTMENT_TEMP_B (depid, healthinstid, depname, cityid, numberofbeds)
values (472, 854, 'Gastroenterology', 20, 25);
insert into DEPARTMENT_TEMP_B (depid, healthinstid, depname, cityid, numberofbeds)
values (325, 892, 'General Services', 10, 44);
insert into DEPARTMENT_TEMP_B (depid, healthinstid, depname, cityid, numberofbeds)
values (457, 781, 'General Surgery', 2, 29);
insert into DEPARTMENT_TEMP_B (depid, healthinstid, depname, cityid, numberofbeds)
values (522, 309, 'Gynecology', 16, 13);
insert into DEPARTMENT_TEMP_B (depid, healthinstid, depname, cityid, numberofbeds)
values (828, 883, 'Haematology', 8, 39);
insert into DEPARTMENT_TEMP_B (depid, healthinstid, depname, cityid, numberofbeds)
values (922, 319, 'Health & Safety', 17, 44);
insert into DEPARTMENT_TEMP_B (depid, healthinstid, depname, cityid, numberofbeds)
values (756, 174, 'Intensive Care Unit', 26, 36);
insert into DEPARTMENT_TEMP_B (depid, healthinstid, depname, cityid, numberofbeds)
values (2, 427, 'Human Resources', 8, 29);
insert into DEPARTMENT_TEMP_B (depid, healthinstid, depname, cityid, numberofbeds)
values (860, 455, 'Admissions', 14, 27);
insert into DEPARTMENT_TEMP_B (depid, healthinstid, depname, cityid, numberofbeds)
values (806, 331, 'Anesthetics', 28, 34);
insert into DEPARTMENT_TEMP_B (depid, healthinstid, depname, cityid, numberofbeds)
values (952, 589, 'Breast Screening', 18, 17);
insert into DEPARTMENT_TEMP_B (depid, healthinstid, depname, cityid, numberofbeds)
values (517, 759, 'Burn Center', 15, 35);
insert into DEPARTMENT_TEMP_B (depid, healthinstid, depname, cityid, numberofbeds)
values (918, 865, 'Cardiology', 1, 50);
insert into DEPARTMENT_TEMP_B (depid, healthinstid, depname, cityid, numberofbeds)
values (103, 648, 'CSSD', 6, 49);
insert into DEPARTMENT_TEMP_B (depid, healthinstid, depname, cityid, numberofbeds)
values (191, 547, 'Chaplaincy', 29, 17);
insert into DEPARTMENT_TEMP_B (depid, healthinstid, depname, cityid, numberofbeds)
values (32, 360, 'Coronary Care Unit', 20, 29);
insert into DEPARTMENT_TEMP_B (depid, healthinstid, depname, cityid, numberofbeds)
values (68, 435, 'Critical Care', 2, 37);
insert into DEPARTMENT_TEMP_B (depid, healthinstid, depname, cityid, numberofbeds)
values (371, 861, 'Diagnostic Imaging', 26, 20);
insert into DEPARTMENT_TEMP_B (depid, healthinstid, depname, cityid, numberofbeds)
values (173, 726, 'Discharge Lounge', 24, 27);
insert into DEPARTMENT_TEMP_B (depid, healthinstid, depname, cityid, numberofbeds)
values (102, 758, 'Elderly services', 22, 47);
insert into DEPARTMENT_TEMP_B (depid, healthinstid, depname, cityid, numberofbeds)
values (392, 224, 'Finance Department', 14, 23);
insert into DEPARTMENT_TEMP_B (depid, healthinstid, depname, cityid, numberofbeds)
values (344, 42, 'Gastroenterology', 3, 19);
insert into DEPARTMENT_TEMP_B (depid, healthinstid, depname, cityid, numberofbeds)
values (28, 116, 'General Services', 3, 22);
insert into DEPARTMENT_TEMP_B (depid, healthinstid, depname, cityid, numberofbeds)
values (395, 431, 'General Surgery', 17, 33);
insert into DEPARTMENT_TEMP_B (depid, healthinstid, depname, cityid, numberofbeds)
values (674, 380, 'Gynecology', 23, 18);
insert into DEPARTMENT_TEMP_B (depid, healthinstid, depname, cityid, numberofbeds)
values (383, 426, 'Haematology', 22, 29);
insert into DEPARTMENT_TEMP_B (depid, healthinstid, depname, cityid, numberofbeds)
values (677, 546, 'Health & Safety', 2, 43);
insert into DEPARTMENT_TEMP_B (depid, healthinstid, depname, cityid, numberofbeds)
values (840, 186, 'Ophthalmology', 15, 46);
insert into DEPARTMENT_TEMP_B (depid, healthinstid, depname, cityid, numberofbeds)
values (123, 632, 'Orthopaedics', 20, 18);
insert into DEPARTMENT_TEMP_B (depid, healthinstid, depname, cityid, numberofbeds)
values (280, 789, 'Otolaryngology', 30, 31);
insert into DEPARTMENT_TEMP_B (depid, healthinstid, depname, cityid, numberofbeds)
values (584, 860, 'Pain Management', 10, 32);
insert into DEPARTMENT_TEMP_B (depid, healthinstid, depname, cityid, numberofbeds)
values (495, 74, 'Patient Accounts', 19, 42);
insert into DEPARTMENT_TEMP_B (depid, healthinstid, depname, cityid, numberofbeds)
values (76, 472, 'Patient Services', 3, 38);
insert into DEPARTMENT_TEMP_B (depid, healthinstid, depname, cityid, numberofbeds)
values (122, 514, 'Pharmacy', 17, 16);
insert into DEPARTMENT_TEMP_B (depid, healthinstid, depname, cityid, numberofbeds)
values (283, 680, 'Physiotherapy', 5, 44);
insert into DEPARTMENT_TEMP_B (depid, healthinstid, depname, cityid, numberofbeds)
values (949, 213, 'Purchasing & Supplies', 27, 46);
insert into DEPARTMENT_TEMP_B (depid, healthinstid, depname, cityid, numberofbeds)
values (764, 51, 'Radiology', 10, 36);
insert into DEPARTMENT_TEMP_B (depid, healthinstid, depname, cityid, numberofbeds)
values (225, 581, 'Radiotherapy', 27, 25);
insert into DEPARTMENT_TEMP_B (depid, healthinstid, depname, cityid, numberofbeds)
values (580, 78, 'Renal', 29, 17);
insert into DEPARTMENT_TEMP_B (depid, healthinstid, depname, cityid, numberofbeds)
values (300, 895, 'Rheumatology', 18, 45);
insert into DEPARTMENT_TEMP_B (depid, healthinstid, depname, cityid, numberofbeds)
values (511, 301, 'Sexual Health', 17, 41);
insert into DEPARTMENT_TEMP_B (depid, healthinstid, depname, cityid, numberofbeds)
values (762, 151, 'Social Work', 3, 16);
insert into DEPARTMENT_TEMP_B (depid, healthinstid, depname, cityid, numberofbeds)
values (443, 170, 'Urology', 14, 42);
insert into DEPARTMENT_TEMP_B (depid, healthinstid, depname, cityid, numberofbeds)
values (940, 912, 'Occupational Therapy', 13, 22);
insert into DEPARTMENT_TEMP_B (depid, healthinstid, depname, cityid, numberofbeds)
values (378, 501, 'Oncology', 14, 49);
insert into DEPARTMENT_TEMP_B (depid, healthinstid, depname, cityid, numberofbeds)
values (664, 893, 'Ophthalmology', 2, 25);
insert into DEPARTMENT_TEMP_B (depid, healthinstid, depname, cityid, numberofbeds)
values (12, 857, 'Orthopaedics', 5, 24);
insert into DEPARTMENT_TEMP_B (depid, healthinstid, depname, cityid, numberofbeds)
values (562, 443, 'Otolaryngology', 17, 38);
insert into DEPARTMENT_TEMP_B (depid, healthinstid, depname, cityid, numberofbeds)
values (459, 297, 'Pain Management', 18, 20);
insert into DEPARTMENT_TEMP_B (depid, healthinstid, depname, cityid, numberofbeds)
values (15, 566, 'Patient Accounts', 11, 21);
insert into DEPARTMENT_TEMP_B (depid, healthinstid, depname, cityid, numberofbeds)
values (524, 164, 'Patient Services', 22, 42);
insert into DEPARTMENT_TEMP_B (depid, healthinstid, depname, cityid, numberofbeds)
values (852, 996, 'Pharmacy', 2, 31);
insert into DEPARTMENT_TEMP_B (depid, healthinstid, depname, cityid, numberofbeds)
values (941, 652, 'Physiotherapy', 11, 43);
insert into DEPARTMENT_TEMP_B (depid, healthinstid, depname, cityid, numberofbeds)
values (382, 582, 'Purchasing & Supplies', 17, 29);
insert into DEPARTMENT_TEMP_B (depid, healthinstid, depname, cityid, numberofbeds)
values (627, 564, 'Radiology', 7, 28);
insert into DEPARTMENT_TEMP_B (depid, healthinstid, depname, cityid, numberofbeds)
values (390, 815, 'Radiotherapy', 21, 27);
insert into DEPARTMENT_TEMP_B (depid, healthinstid, depname, cityid, numberofbeds)
values (193, 820, 'Renal', 12, 47);
insert into DEPARTMENT_TEMP_B (depid, healthinstid, depname, cityid, numberofbeds)
values (826, 157, 'Rheumatology', 10, 14);
insert into DEPARTMENT_TEMP_B (depid, healthinstid, depname, cityid, numberofbeds)
values (855, 281, 'Sexual Health', 16, 33);
insert into DEPARTMENT_TEMP_B (depid, healthinstid, depname, cityid, numberofbeds)
values (778, 420, 'Social Work', 6, 50);
insert into DEPARTMENT_TEMP_B (depid, healthinstid, depname, cityid, numberofbeds)
values (815, 408, 'Burn Center', 8, 28);
insert into DEPARTMENT_TEMP_B (depid, healthinstid, depname, cityid, numberofbeds)
values (60, 279, 'Cardiology', 26, 12);
insert into DEPARTMENT_TEMP_B (depid, healthinstid, depname, cityid, numberofbeds)
values (84, 423, 'CSSD', 15, 25);
insert into DEPARTMENT_TEMP_B (depid, healthinstid, depname, cityid, numberofbeds)
values (341, 573, 'Chaplaincy', 16, 27);
insert into DEPARTMENT_TEMP_B (depid, healthinstid, depname, cityid, numberofbeds)
values (725, 292, 'Coronary Care Unit', 15, 16);
insert into DEPARTMENT_TEMP_B (depid, healthinstid, depname, cityid, numberofbeds)
values (730, 146, 'Critical Care', 22, 30);
insert into DEPARTMENT_TEMP_B (depid, healthinstid, depname, cityid, numberofbeds)
values (287, 338, 'Diagnostic Imaging', 13, 17);
insert into DEPARTMENT_TEMP_B (depid, healthinstid, depname, cityid, numberofbeds)
values (837, 364, 'Discharge Lounge', 10, 46);
insert into DEPARTMENT_TEMP_B (depid, healthinstid, depname, cityid, numberofbeds)
values (345, 340, 'Elderly services', 3, 42);
insert into DEPARTMENT_TEMP_B (depid, healthinstid, depname, cityid, numberofbeds)
values (625, 180, 'Finance Department', 28, 44);
insert into DEPARTMENT_TEMP_B (depid, healthinstid, depname, cityid, numberofbeds)
values (646, 713, 'Sexual Health', 8, 19);
insert into DEPARTMENT_TEMP_B (depid, healthinstid, depname, cityid, numberofbeds)
values (933, 809, 'Social Work', 18, 33);
insert into DEPARTMENT_TEMP_B (depid, healthinstid, depname, cityid, numberofbeds)
values (164, 839, 'Urology', 27, 21);
insert into DEPARTMENT_TEMP_B (depid, healthinstid, depname, cityid, numberofbeds)
values (217, 656, 'Occupational Therapy', 8, 27);
insert into DEPARTMENT_TEMP_B (depid, healthinstid, depname, cityid, numberofbeds)
values (678, 834, 'Oncology', 5, 42);
insert into DEPARTMENT_TEMP_B (depid, healthinstid, depname, cityid, numberofbeds)
values (41, 34, 'Ophthalmology', 26, 16);
insert into DEPARTMENT_TEMP_B (depid, healthinstid, depname, cityid, numberofbeds)
values (152, 616, 'Orthopaedics', 3, 17);
insert into DEPARTMENT_TEMP_B (depid, healthinstid, depname, cityid, numberofbeds)
values (444, 931, 'Otolaryngology', 6, 42);
insert into DEPARTMENT_TEMP_B (depid, healthinstid, depname, cityid, numberofbeds)
values (65, 503, 'Pain Management', 4, 47);
insert into DEPARTMENT_TEMP_B (depid, healthinstid, depname, cityid, numberofbeds)
values (516, 748, 'Patient Accounts', 11, 17);
prompt 264 records loaded
prompt Enabling triggers for DEPARTMENT_TEMP_B...
alter table DEPARTMENT_TEMP_B enable all triggers;

set feedback on
set define on
prompt Done
