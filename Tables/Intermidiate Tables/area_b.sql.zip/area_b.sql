?��prompt PL/SQL Developer Export Tables for user SYSTEM
prompt Created by Evyatar on יום שני 10 אוגוסט 2020
set feedback off
set define off

prompt Creating AREA_B...
create table AREA_B
(
  areaid   NUMBER(3) not null,
  areaname VARCHAR2(20) not null
)
tablespace SYSTEM
  pctfree 10
  pctused 40
  initrans 1
  maxtrans 255
  storage
  (
    initial 64K
    next 1M
    minextents 1
    maxextents unlimited
  );
alter table AREA_B
  add primary key (AREAID)
  using index 
  tablespace SYSTEM
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 64K
    next 1M
    minextents 1
    maxextents unlimited
  );

prompt Disabling triggers for AREA_B...
alter table AREA_B disable all triggers;
prompt Deleting AREA_B...
delete from AREA_B;
prompt Loading AREA_B...
insert into AREA_B (areaid, areaname)
values (1, 'West Virginia');
insert into AREA_B (areaid, areaname)
values (2, 'Missouri');
insert into AREA_B (areaid, areaname)
values (3, 'Texas');
insert into AREA_B (areaid, areaname)
values (4, 'Delaware');
insert into AREA_B (areaid, areaname)
values (5, 'Tennessee');
insert into AREA_B (areaid, areaname)
values (6, 'Arkansas');
insert into AREA_B (areaid, areaname)
values (7, 'Illinois');
insert into AREA_B (areaid, areaname)
values (8, 'Minnesota');
insert into AREA_B (areaid, areaname)
values (9, 'South Carolina');
insert into AREA_B (areaid, areaname)
values (10, 'Oregon');
insert into AREA_B (areaid, areaname)
values (11, 'Maryland');
insert into AREA_B (areaid, areaname)
values (12, 'Georgia');
insert into AREA_B (areaid, areaname)
values (13, 'Massachusetts');
insert into AREA_B (areaid, areaname)
values (14, 'Mississippi');
insert into AREA_B (areaid, areaname)
values (15, 'Ohio');
insert into AREA_B (areaid, areaname)
values (16, 'Idaho');
insert into AREA_B (areaid, areaname)
values (17, 'Florida');
insert into AREA_B (areaid, areaname)
values (18, 'New Jersey');
insert into AREA_B (areaid, areaname)
values (19, 'Michigan');
insert into AREA_B (areaid, areaname)
values (20, 'Hawaii');
prompt 20 records loaded
prompt Enabling triggers for AREA_B...
alter table AREA_B enable all triggers;

set feedback on
set define on
prompt Done
