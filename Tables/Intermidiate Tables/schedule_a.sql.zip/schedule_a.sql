?��prompt PL/SQL Developer Export Tables for user SYSTEM
prompt Created by Evyatar on יום שני 10 אוגוסט 2020
set feedback off
set define off

prompt Creating SCHEDULE_A...
create table SCHEDULE_A
(
  meetingtime DATE not null,
  clerkid     NUMBER(9) not null,
  citizenid   INTEGER not null
)
tablespace SYSTEM
  pctfree 10
  pctused 40
  initrans 1
  maxtrans 255
  storage
  (
    initial 64K
    next 1M
    minextents 1
    maxextents unlimited
  );
alter table SCHEDULE_A
  add primary key (MEETINGTIME, CLERKID, CITIZENID)
  using index 
  tablespace SYSTEM
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 64K
    next 1M
    minextents 1
    maxextents unlimited
  );
alter table SCHEDULE_A
  add foreign key (CLERKID)
  references CLERK (CLERKID);
alter table SCHEDULE_A
  add foreign key (CITIZENID)
  references CITIZEN (CITIZENID);

prompt Disabling triggers for SCHEDULE_A...
alter table SCHEDULE_A disable all triggers;
prompt Disabling foreign key constraints for SCHEDULE_A...
alter table SCHEDULE_A disable constraint SYS_C007541;
alter table SCHEDULE_A disable constraint SYS_C007542;
prompt Deleting SCHEDULE_A...
delete from SCHEDULE_A;
prompt Loading SCHEDULE_A...
insert into SCHEDULE_A (meetingtime, clerkid, citizenid)
values (to_date('28-04-2016 18:57:18', 'dd-mm-yyyy hh24:mi:ss'), 1, 438);
insert into SCHEDULE_A (meetingtime, clerkid, citizenid)
values (to_date('16-04-2015 06:05:45', 'dd-mm-yyyy hh24:mi:ss'), 3, 613);
insert into SCHEDULE_A (meetingtime, clerkid, citizenid)
values (to_date('25-11-2016 10:12:17', 'dd-mm-yyyy hh24:mi:ss'), 3, 43);
insert into SCHEDULE_A (meetingtime, clerkid, citizenid)
values (to_date('06-06-2012 07:04:13', 'dd-mm-yyyy hh24:mi:ss'), 5, 840);
insert into SCHEDULE_A (meetingtime, clerkid, citizenid)
values (to_date('05-04-2010 22:16:53', 'dd-mm-yyyy hh24:mi:ss'), 6, 779);
insert into SCHEDULE_A (meetingtime, clerkid, citizenid)
values (to_date('02-02-2014 21:33:33', 'dd-mm-yyyy hh24:mi:ss'), 6, 902);
insert into SCHEDULE_A (meetingtime, clerkid, citizenid)
values (to_date('24-06-2009 07:03:21', 'dd-mm-yyyy hh24:mi:ss'), 7, 355);
insert into SCHEDULE_A (meetingtime, clerkid, citizenid)
values (to_date('18-04-2016 10:16:01', 'dd-mm-yyyy hh24:mi:ss'), 7, 67);
insert into SCHEDULE_A (meetingtime, clerkid, citizenid)
values (to_date('27-10-2009 13:42:05', 'dd-mm-yyyy hh24:mi:ss'), 8, 376);
insert into SCHEDULE_A (meetingtime, clerkid, citizenid)
values (to_date('16-10-2012 18:56:18', 'dd-mm-yyyy hh24:mi:ss'), 8, 708);
insert into SCHEDULE_A (meetingtime, clerkid, citizenid)
values (to_date('04-11-2010 19:16:10', 'dd-mm-yyyy hh24:mi:ss'), 9, 453);
insert into SCHEDULE_A (meetingtime, clerkid, citizenid)
values (to_date('17-09-2012 13:14:44', 'dd-mm-yyyy hh24:mi:ss'), 9, 298);
prompt 12 records loaded
prompt Enabling foreign key constraints for SCHEDULE_A...
alter table SCHEDULE_A enable constraint SYS_C007541;
alter table SCHEDULE_A enable constraint SYS_C007542;
prompt Enabling triggers for SCHEDULE_A...
alter table SCHEDULE_A enable all triggers;

set feedback on
set define on
prompt Done
