?��prompt PL/SQL Developer Export Tables for user SYSTEM
prompt Created by Evyatar on יום שני 10 אוגוסט 2020
set feedback off
set define off

prompt Creating CITY_B...
create table CITY_B
(
  cityid   NUMBER(3) not null,
  cityname VARCHAR2(50) not null,
  areaid   NUMBER(3) not null
)
tablespace SYSTEM
  pctfree 10
  pctused 40
  initrans 1
  maxtrans 255
  storage
  (
    initial 64K
    next 1M
    minextents 1
    maxextents unlimited
  );
alter table CITY_B
  add primary key (CITYID)
  using index 
  tablespace SYSTEM
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 64K
    next 1M
    minextents 1
    maxextents unlimited
  );

prompt Disabling triggers for CITY_B...
alter table CITY_B disable all triggers;
prompt Deleting CITY_B...
delete from CITY_B;
prompt Loading CITY_B...
insert into CITY_B (cityid, cityname, areaid)
values (100, 'Jacksonville', 19);
insert into CITY_B (cityid, cityname, areaid)
values (101, 'Pasadena', 10);
insert into CITY_B (cityid, cityname, areaid)
values (102, 'High Wycombe', 6);
insert into CITY_B (cityid, cityname, areaid)
values (103, 'Bretzfeld-Waldbach', 5);
insert into CITY_B (cityid, cityname, areaid)
values (104, 'Bernex', 2);
insert into CITY_B (cityid, cityname, areaid)
values (105, 'Waalwijk', 5);
insert into CITY_B (cityid, cityname, areaid)
values (106, 'Neuquen', 6);
insert into CITY_B (cityid, cityname, areaid)
values (107, 'Waite Park', 7);
insert into CITY_B (cityid, cityname, areaid)
values (108, 'Buffalo Grove', 9);
insert into CITY_B (cityid, cityname, areaid)
values (109, 'Monroe', 15);
insert into CITY_B (cityid, cityname, areaid)
values (110, 'Sheffield', 3);
insert into CITY_B (cityid, cityname, areaid)
values (111, 'Edmonton', 13);
insert into CITY_B (cityid, cityname, areaid)
values (112, 'Colorado Springs', 5);
insert into CITY_B (cityid, cityname, areaid)
values (113, 'S. Bernardo do Campo', 15);
insert into CITY_B (cityid, cityname, areaid)
values (114, 'El Segundo', 6);
insert into CITY_B (cityid, cityname, areaid)
values (115, 'Kumamoto', 9);
insert into CITY_B (cityid, cityname, areaid)
values (116, 'Ft. Leavenworth', 8);
insert into CITY_B (cityid, cityname, areaid)
values (117, 'K׳¦ln', 18);
insert into CITY_B (cityid, cityname, areaid)
values (118, 'L''union', 9);
insert into CITY_B (cityid, cityname, areaid)
values (119, 'Pompeia', 13);
insert into CITY_B (cityid, cityname, areaid)
values (120, 'Pa׳—o de Arcos', 14);
insert into CITY_B (cityid, cityname, areaid)
values (121, 'Lenexa', 10);
insert into CITY_B (cityid, cityname, areaid)
values (122, 'Reading', 14);
insert into CITY_B (cityid, cityname, areaid)
values (123, 'Obfelden', 13);
insert into CITY_B (cityid, cityname, areaid)
values (124, 'Herzogenrath', 6);
insert into CITY_B (cityid, cityname, areaid)
values (125, 'Nara', 4);
insert into CITY_B (cityid, cityname, areaid)
values (126, 'Swannanoa', 9);
insert into CITY_B (cityid, cityname, areaid)
values (127, 'Echirolles', 4);
insert into CITY_B (cityid, cityname, areaid)
values (128, 'Toronto', 1);
insert into CITY_B (cityid, cityname, areaid)
values (129, 'Lucca', 18);
insert into CITY_B (cityid, cityname, areaid)
values (130, 'Suffern', 19);
insert into CITY_B (cityid, cityname, areaid)
values (131, 'Long Island City', 18);
insert into CITY_B (cityid, cityname, areaid)
values (132, 'Gettysburg', 13);
insert into CITY_B (cityid, cityname, areaid)
values (133, 'Kaunas', 2);
insert into CITY_B (cityid, cityname, areaid)
values (134, 'Forest Park', 6);
insert into CITY_B (cityid, cityname, areaid)
values (135, 'Benbrook', 18);
insert into CITY_B (cityid, cityname, areaid)
values (136, 'Gifu', 15);
insert into CITY_B (cityid, cityname, areaid)
values (137, 'Tualatin', 16);
insert into CITY_B (cityid, cityname, areaid)
values (138, 'Pa׳—o de Arcos', 17);
insert into CITY_B (cityid, cityname, areaid)
values (139, 'Bedfordshire', 16);
insert into CITY_B (cityid, cityname, areaid)
values (140, 'Koufu', 8);
insert into CITY_B (cityid, cityname, areaid)
values (141, 'Bekescsaba', 11);
insert into CITY_B (cityid, cityname, areaid)
values (142, 'Moorestown', 5);
insert into CITY_B (cityid, cityname, areaid)
values (143, 'Berlin-Adlershof', 9);
insert into CITY_B (cityid, cityname, areaid)
values (144, 'Ottawa', 19);
insert into CITY_B (cityid, cityname, areaid)
values (145, 'Birmingham', 14);
insert into CITY_B (cityid, cityname, areaid)
values (146, 'Balmoral', 1);
insert into CITY_B (cityid, cityname, areaid)
values (147, 'Maidenhead', 8);
insert into CITY_B (cityid, cityname, areaid)
values (148, 'Milton', 4);
insert into CITY_B (cityid, cityname, areaid)
values (149, 'Luedenscheid', 14);
prompt 50 records loaded
prompt Enabling triggers for CITY_B...
alter table CITY_B enable all triggers;

set feedback on
set define on
prompt Done
