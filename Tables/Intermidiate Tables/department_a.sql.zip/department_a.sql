?��prompt PL/SQL Developer Export Tables for user SYSTEM
prompt Created by Evyatar on יום שני 10 אוגוסט 2020
set feedback off
set define off

prompt Creating DEPARTMENT_A...
create table DEPARTMENT_A
(
  deptid  INTEGER not null,
  depname VARCHAR2(32) not null,
  cityid  INTEGER not null
)
tablespace SYSTEM
  pctfree 10
  pctused 40
  initrans 1
  maxtrans 255
  storage
  (
    initial 64K
    next 1M
    minextents 1
    maxextents unlimited
  );
alter table DEPARTMENT_A
  add primary key (DEPTID)
  using index 
  tablespace SYSTEM
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 64K
    next 1M
    minextents 1
    maxextents unlimited
  );

prompt Disabling triggers for DEPARTMENT_A...
alter table DEPARTMENT_A disable all triggers;
prompt Deleting DEPARTMENT_A...
delete from DEPARTMENT_A;
prompt Loading DEPARTMENT_A...
insert into DEPARTMENT_A (deptid, depname, cityid)
values (1, 'Admissions', 18);
insert into DEPARTMENT_A (deptid, depname, cityid)
values (2, 'Cardiology', 8);
insert into DEPARTMENT_A (deptid, depname, cityid)
values (3, 'Pharmacy', 20);
insert into DEPARTMENT_A (deptid, depname, cityid)
values (4, 'Nephrology', 15);
insert into DEPARTMENT_A (deptid, depname, cityid)
values (5, 'Admissions', 15);
insert into DEPARTMENT_A (deptid, depname, cityid)
values (6, 'Critical Care', 19);
insert into DEPARTMENT_A (deptid, depname, cityid)
values (7, 'Human Resources', 15);
insert into DEPARTMENT_A (deptid, depname, cityid)
values (8, 'Pharmacy', 4);
insert into DEPARTMENT_A (deptid, depname, cityid)
values (9, 'General Surgery', 15);
insert into DEPARTMENT_A (deptid, depname, cityid)
values (10, 'Pharmacy', 6);
insert into DEPARTMENT_A (deptid, depname, cityid)
values (11, 'Oncology', 2);
prompt 11 records loaded
prompt Enabling triggers for DEPARTMENT_A...
alter table DEPARTMENT_A enable all triggers;

set feedback on
set define on
prompt Done
