?��prompt PL/SQL Developer Export Tables for user SYSTEM
prompt Created by Evyatar on יום שני 10 אוגוסט 2020
set feedback off
set define off

prompt Creating LICENSING_TEMP...
create table LICENSING_TEMP
(
  licensetype VARCHAR2(50) not null,
  licenseid   NUMBER(3) not null,
  releasedate DATE not null,
  fieldid     NUMBER(3) not null
)
tablespace SYSTEM
  pctfree 10
  pctused 40
  initrans 1
  maxtrans 255
  storage
  (
    initial 64K
    next 1M
    minextents 1
    maxextents unlimited
  );
alter table LICENSING_TEMP
  add primary key (LICENSEID)
  using index 
  tablespace SYSTEM
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 64K
    next 1M
    minextents 1
    maxextents unlimited
  );
alter table LICENSING_TEMP
  add foreign key (FIELDID)
  references FIELD (FIELDID);

prompt Disabling triggers for LICENSING_TEMP...
alter table LICENSING_TEMP disable all triggers;
prompt Disabling foreign key constraints for LICENSING_TEMP...
alter table LICENSING_TEMP disable constraint SYS_C007471;
prompt Deleting LICENSING_TEMP...
delete from LICENSING_TEMP;
prompt Loading LICENSING_TEMP...
prompt Table is empty
prompt Enabling foreign key constraints for LICENSING_TEMP...
alter table LICENSING_TEMP enable constraint SYS_C007471;
prompt Enabling triggers for LICENSING_TEMP...
alter table LICENSING_TEMP enable all triggers;

set feedback on
set define on
prompt Done
