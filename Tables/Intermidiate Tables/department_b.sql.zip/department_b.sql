?��prompt PL/SQL Developer Export Tables for user SYSTEM
prompt Created by Evyatar on יום שני 10 אוגוסט 2020
set feedback off
set define off

prompt Creating DEPARTMENT_B...
create table DEPARTMENT_B
(
  depid        INTEGER not null,
  numberofbeds NUMBER(4) not null,
  depname      VARCHAR2(50) not null,
  healthinstid NUMBER(3) not null
)
tablespace SYSTEM
  pctfree 10
  pctused 40
  initrans 1
  maxtrans 255
  storage
  (
    initial 64K
    next 1M
    minextents 1
    maxextents unlimited
  );
alter table DEPARTMENT_B
  add primary key (DEPID, HEALTHINSTID)
  using index 
  tablespace SYSTEM
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 64K
    next 1M
    minextents 1
    maxextents unlimited
  );
alter table DEPARTMENT_B
  add foreign key (HEALTHINSTID)
  references HEALTHINSTITUTION (HEALTHINSTID);

prompt Disabling triggers for DEPARTMENT_B...
alter table DEPARTMENT_B disable all triggers;
prompt Disabling foreign key constraints for DEPARTMENT_B...
alter table DEPARTMENT_B disable constraint SYS_C007578;
prompt Deleting DEPARTMENT_B...
delete from DEPARTMENT_B;
prompt Loading DEPARTMENT_B...
insert into DEPARTMENT_B (depid, numberofbeds, depname, healthinstid)
values (224, 47, 'Admissions', 435);
insert into DEPARTMENT_B (depid, numberofbeds, depname, healthinstid)
values (753, 36, 'Anesthetics', 861);
insert into DEPARTMENT_B (depid, numberofbeds, depname, healthinstid)
values (621, 30, 'Breast Screening', 726);
insert into DEPARTMENT_B (depid, numberofbeds, depname, healthinstid)
values (265, 39, 'Burn Center', 758);
insert into DEPARTMENT_B (depid, numberofbeds, depname, healthinstid)
values (540, 38, 'Cardiology', 224);
insert into DEPARTMENT_B (depid, numberofbeds, depname, healthinstid)
values (924, 11, 'CSSD', 42);
insert into DEPARTMENT_B (depid, numberofbeds, depname, healthinstid)
values (598, 26, 'Chaplaincy', 116);
insert into DEPARTMENT_B (depid, numberofbeds, depname, healthinstid)
values (789, 45, 'Coronary Care Unit', 431);
insert into DEPARTMENT_B (depid, numberofbeds, depname, healthinstid)
values (993, 13, 'Critical Care', 380);
insert into DEPARTMENT_B (depid, numberofbeds, depname, healthinstid)
values (97, 11, 'Diagnostic Imaging', 426);
insert into DEPARTMENT_B (depid, numberofbeds, depname, healthinstid)
values (976, 16, 'Discharge Lounge', 546);
insert into DEPARTMENT_B (depid, numberofbeds, depname, healthinstid)
values (399, 44, 'Elderly services', 186);
insert into DEPARTMENT_B (depid, numberofbeds, depname, healthinstid)
values (405, 26, 'Finance Department', 632);
insert into DEPARTMENT_B (depid, numberofbeds, depname, healthinstid)
values (633, 18, 'Gastroenterology', 789);
insert into DEPARTMENT_B (depid, numberofbeds, depname, healthinstid)
values (450, 13, 'General Services', 860);
insert into DEPARTMENT_B (depid, numberofbeds, depname, healthinstid)
values (959, 41, 'General Surgery', 74);
insert into DEPARTMENT_B (depid, numberofbeds, depname, healthinstid)
values (336, 48, 'Gynecology', 472);
insert into DEPARTMENT_B (depid, numberofbeds, depname, healthinstid)
values (890, 38, 'Haematology', 514);
insert into DEPARTMENT_B (depid, numberofbeds, depname, healthinstid)
values (777, 41, 'Health & Safety', 680);
insert into DEPARTMENT_B (depid, numberofbeds, depname, healthinstid)
values (179, 30, 'Intensive Care Unit', 213);
insert into DEPARTMENT_B (depid, numberofbeds, depname, healthinstid)
values (365, 38, 'Human Resources', 51);
insert into DEPARTMENT_B (depid, numberofbeds, depname, healthinstid)
values (600, 21, 'Infection Control', 581);
insert into DEPARTMENT_B (depid, numberofbeds, depname, healthinstid)
values (528, 10, 'Information Management', 78);
insert into DEPARTMENT_B (depid, numberofbeds, depname, healthinstid)
values (492, 31, 'Maternity', 895);
insert into DEPARTMENT_B (depid, numberofbeds, depname, healthinstid)
values (220, 12, 'Medical Records', 301);
insert into DEPARTMENT_B (depid, numberofbeds, depname, healthinstid)
values (33, 43, 'Microbiology', 151);
insert into DEPARTMENT_B (depid, numberofbeds, depname, healthinstid)
values (121, 30, 'Neonatal', 170);
insert into DEPARTMENT_B (depid, numberofbeds, depname, healthinstid)
values (22, 13, 'Neurology', 912);
insert into DEPARTMENT_B (depid, numberofbeds, depname, healthinstid)
values (830, 16, 'Nutrition and Dietetics', 501);
insert into DEPARTMENT_B (depid, numberofbeds, depname, healthinstid)
values (413, 13, 'Obstetrics/Gynecology', 893);
insert into DEPARTMENT_B (depid, numberofbeds, depname, healthinstid)
values (425, 37, 'Occupational Therapy', 857);
insert into DEPARTMENT_B (depid, numberofbeds, depname, healthinstid)
values (329, 28, 'Oncology', 443);
insert into DEPARTMENT_B (depid, numberofbeds, depname, healthinstid)
values (556, 43, 'Ophthalmology', 297);
insert into DEPARTMENT_B (depid, numberofbeds, depname, healthinstid)
values (20, 48, 'Orthopaedics', 566);
insert into DEPARTMENT_B (depid, numberofbeds, depname, healthinstid)
values (717, 41, 'Otolaryngology', 164);
insert into DEPARTMENT_B (depid, numberofbeds, depname, healthinstid)
values (853, 16, 'Pain Management', 996);
insert into DEPARTMENT_B (depid, numberofbeds, depname, healthinstid)
values (233, 33, 'Patient Accounts', 652);
insert into DEPARTMENT_B (depid, numberofbeds, depname, healthinstid)
values (734, 20, 'Patient Services', 582);
insert into DEPARTMENT_B (depid, numberofbeds, depname, healthinstid)
values (124, 37, 'Pharmacy', 564);
insert into DEPARTMENT_B (depid, numberofbeds, depname, healthinstid)
values (245, 33, 'Physiotherapy', 815);
insert into DEPARTMENT_B (depid, numberofbeds, depname, healthinstid)
values (803, 36, 'Purchasing & Supplies', 820);
insert into DEPARTMENT_B (depid, numberofbeds, depname, healthinstid)
values (110, 42, 'Radiology', 157);
insert into DEPARTMENT_B (depid, numberofbeds, depname, healthinstid)
values (631, 14, 'Radiotherapy', 281);
insert into DEPARTMENT_B (depid, numberofbeds, depname, healthinstid)
values (149, 25, 'Renal', 420);
insert into DEPARTMENT_B (depid, numberofbeds, depname, healthinstid)
values (172, 11, 'Rheumatology', 408);
insert into DEPARTMENT_B (depid, numberofbeds, depname, healthinstid)
values (710, 17, 'Sexual Health', 279);
insert into DEPARTMENT_B (depid, numberofbeds, depname, healthinstid)
values (185, 44, 'Social Work', 423);
insert into DEPARTMENT_B (depid, numberofbeds, depname, healthinstid)
values (513, 10, 'Urology', 573);
insert into DEPARTMENT_B (depid, numberofbeds, depname, healthinstid)
values (226, 25, 'Occupational Therapy', 292);
insert into DEPARTMENT_B (depid, numberofbeds, depname, healthinstid)
values (478, 40, 'Oncology', 146);
insert into DEPARTMENT_B (depid, numberofbeds, depname, healthinstid)
values (958, 11, 'Ophthalmology', 338);
insert into DEPARTMENT_B (depid, numberofbeds, depname, healthinstid)
values (792, 37, 'Orthopaedics', 364);
insert into DEPARTMENT_B (depid, numberofbeds, depname, healthinstid)
values (419, 25, 'Otolaryngology', 340);
insert into DEPARTMENT_B (depid, numberofbeds, depname, healthinstid)
values (977, 38, 'Pain Management', 180);
insert into DEPARTMENT_B (depid, numberofbeds, depname, healthinstid)
values (688, 25, 'Patient Accounts', 713);
insert into DEPARTMENT_B (depid, numberofbeds, depname, healthinstid)
values (480, 24, 'Patient Services', 809);
insert into DEPARTMENT_B (depid, numberofbeds, depname, healthinstid)
values (741, 10, 'Pharmacy', 839);
insert into DEPARTMENT_B (depid, numberofbeds, depname, healthinstid)
values (964, 25, 'Physiotherapy', 656);
insert into DEPARTMENT_B (depid, numberofbeds, depname, healthinstid)
values (296, 16, 'Purchasing & Supplies', 834);
insert into DEPARTMENT_B (depid, numberofbeds, depname, healthinstid)
values (951, 20, 'Radiology', 34);
insert into DEPARTMENT_B (depid, numberofbeds, depname, healthinstid)
values (758, 47, 'Radiotherapy', 616);
insert into DEPARTMENT_B (depid, numberofbeds, depname, healthinstid)
values (820, 14, 'Renal', 931);
insert into DEPARTMENT_B (depid, numberofbeds, depname, healthinstid)
values (799, 38, 'Rheumatology', 503);
insert into DEPARTMENT_B (depid, numberofbeds, depname, healthinstid)
values (670, 26, 'Sexual Health', 748);
insert into DEPARTMENT_B (depid, numberofbeds, depname, healthinstid)
values (321, 35, 'Social Work', 381);
insert into DEPARTMENT_B (depid, numberofbeds, depname, healthinstid)
values (246, 28, 'Burn Center', 352);
insert into DEPARTMENT_B (depid, numberofbeds, depname, healthinstid)
values (790, 47, 'Cardiology', 25);
insert into DEPARTMENT_B (depid, numberofbeds, depname, healthinstid)
values (684, 11, 'CSSD', 31);
insert into DEPARTMENT_B (depid, numberofbeds, depname, healthinstid)
values (928, 31, 'Chaplaincy', 200);
insert into DEPARTMENT_B (depid, numberofbeds, depname, healthinstid)
values (846, 22, 'Coronary Care Unit', 107);
insert into DEPARTMENT_B (depid, numberofbeds, depname, healthinstid)
values (640, 27, 'Critical Care', 601);
insert into DEPARTMENT_B (depid, numberofbeds, depname, healthinstid)
values (251, 49, 'Diagnostic Imaging', 310);
insert into DEPARTMENT_B (depid, numberofbeds, depname, healthinstid)
values (572, 47, 'Discharge Lounge', 526);
insert into DEPARTMENT_B (depid, numberofbeds, depname, healthinstid)
values (926, 48, 'Elderly services', 831);
insert into DEPARTMENT_B (depid, numberofbeds, depname, healthinstid)
values (501, 33, 'Finance Department', 121);
insert into DEPARTMENT_B (depid, numberofbeds, depname, healthinstid)
values (953, 11, 'Gastroenterology', 313);
insert into DEPARTMENT_B (depid, numberofbeds, depname, healthinstid)
values (737, 22, 'General Services', 339);
insert into DEPARTMENT_B (depid, numberofbeds, depname, healthinstid)
values (608, 39, 'General Surgery', 942);
insert into DEPARTMENT_B (depid, numberofbeds, depname, healthinstid)
values (886, 46, 'Gynecology', 363);
insert into DEPARTMENT_B (depid, numberofbeds, depname, healthinstid)
values (749, 37, 'Haematology', 572);
insert into DEPARTMENT_B (depid, numberofbeds, depname, healthinstid)
values (130, 49, 'Health & Safety', 111);
insert into DEPARTMENT_B (depid, numberofbeds, depname, healthinstid)
values (155, 49, 'Intensive Care Unit', 555);
insert into DEPARTMENT_B (depid, numberofbeds, depname, healthinstid)
values (189, 39, 'Human Resources', 714);
insert into DEPARTMENT_B (depid, numberofbeds, depname, healthinstid)
values (16, 11, 'Admissions', 584);
insert into DEPARTMENT_B (depid, numberofbeds, depname, healthinstid)
values (780, 11, 'Anesthetics', 854);
insert into DEPARTMENT_B (depid, numberofbeds, depname, healthinstid)
values (731, 39, 'Breast Screening', 892);
insert into DEPARTMENT_B (depid, numberofbeds, depname, healthinstid)
values (880, 10, 'Burn Center', 781);
insert into DEPARTMENT_B (depid, numberofbeds, depname, healthinstid)
values (427, 35, 'Cardiology', 309);
insert into DEPARTMENT_B (depid, numberofbeds, depname, healthinstid)
values (763, 48, 'CSSD', 883);
insert into DEPARTMENT_B (depid, numberofbeds, depname, healthinstid)
values (549, 24, 'Chaplaincy', 319);
insert into DEPARTMENT_B (depid, numberofbeds, depname, healthinstid)
values (29, 42, 'Coronary Care Unit', 174);
insert into DEPARTMENT_B (depid, numberofbeds, depname, healthinstid)
values (75, 41, 'Critical Care', 427);
insert into DEPARTMENT_B (depid, numberofbeds, depname, healthinstid)
values (503, 47, 'Diagnostic Imaging', 455);
insert into DEPARTMENT_B (depid, numberofbeds, depname, healthinstid)
values (491, 17, 'Discharge Lounge', 331);
insert into DEPARTMENT_B (depid, numberofbeds, depname, healthinstid)
values (712, 31, 'Elderly services', 589);
insert into DEPARTMENT_B (depid, numberofbeds, depname, healthinstid)
values (93, 12, 'Finance Department', 759);
insert into DEPARTMENT_B (depid, numberofbeds, depname, healthinstid)
values (682, 17, 'Gastroenterology', 865);
insert into DEPARTMENT_B (depid, numberofbeds, depname, healthinstid)
values (279, 49, 'General Services', 648);
insert into DEPARTMENT_B (depid, numberofbeds, depname, healthinstid)
values (203, 16, 'General Surgery', 547);
insert into DEPARTMENT_B (depid, numberofbeds, depname, healthinstid)
values (735, 42, 'Gynecology', 360);
insert into DEPARTMENT_B (depid, numberofbeds, depname, healthinstid)
values (716, 42, 'Haematology', 435);
insert into DEPARTMENT_B (depid, numberofbeds, depname, healthinstid)
values (838, 36, 'Health & Safety', 861);
insert into DEPARTMENT_B (depid, numberofbeds, depname, healthinstid)
values (473, 38, 'Ophthalmology', 726);
insert into DEPARTMENT_B (depid, numberofbeds, depname, healthinstid)
values (306, 41, 'Orthopaedics', 758);
insert into DEPARTMENT_B (depid, numberofbeds, depname, healthinstid)
values (847, 50, 'Otolaryngology', 224);
insert into DEPARTMENT_B (depid, numberofbeds, depname, healthinstid)
values (356, 32, 'Pain Management', 42);
insert into DEPARTMENT_B (depid, numberofbeds, depname, healthinstid)
values (496, 42, 'Patient Accounts', 116);
insert into DEPARTMENT_B (depid, numberofbeds, depname, healthinstid)
values (767, 42, 'Patient Services', 431);
insert into DEPARTMENT_B (depid, numberofbeds, depname, healthinstid)
values (530, 35, 'Pharmacy', 380);
insert into DEPARTMENT_B (depid, numberofbeds, depname, healthinstid)
values (642, 16, 'Physiotherapy', 426);
insert into DEPARTMENT_B (depid, numberofbeds, depname, healthinstid)
values (471, 39, 'Purchasing & Supplies', 546);
insert into DEPARTMENT_B (depid, numberofbeds, depname, healthinstid)
values (218, 38, 'Radiology', 186);
insert into DEPARTMENT_B (depid, numberofbeds, depname, healthinstid)
values (591, 25, 'Radiotherapy', 632);
insert into DEPARTMENT_B (depid, numberofbeds, depname, healthinstid)
values (526, 32, 'Renal', 789);
insert into DEPARTMENT_B (depid, numberofbeds, depname, healthinstid)
values (406, 48, 'Rheumatology', 860);
insert into DEPARTMENT_B (depid, numberofbeds, depname, healthinstid)
values (81, 35, 'Sexual Health', 74);
insert into DEPARTMENT_B (depid, numberofbeds, depname, healthinstid)
values (67, 41, 'Social Work', 472);
insert into DEPARTMENT_B (depid, numberofbeds, depname, healthinstid)
values (981, 40, 'Urology', 514);
insert into DEPARTMENT_B (depid, numberofbeds, depname, healthinstid)
values (686, 39, 'Occupational Therapy', 680);
insert into DEPARTMENT_B (depid, numberofbeds, depname, healthinstid)
values (87, 47, 'Oncology', 213);
insert into DEPARTMENT_B (depid, numberofbeds, depname, healthinstid)
values (531, 25, 'Ophthalmology', 51);
insert into DEPARTMENT_B (depid, numberofbeds, depname, healthinstid)
values (184, 40, 'Orthopaedics', 581);
insert into DEPARTMENT_B (depid, numberofbeds, depname, healthinstid)
values (619, 27, 'Otolaryngology', 78);
insert into DEPARTMENT_B (depid, numberofbeds, depname, healthinstid)
values (332, 33, 'Pain Management', 895);
insert into DEPARTMENT_B (depid, numberofbeds, depname, healthinstid)
values (26, 24, 'Patient Accounts', 301);
insert into DEPARTMENT_B (depid, numberofbeds, depname, healthinstid)
values (114, 24, 'Patient Services', 151);
insert into DEPARTMENT_B (depid, numberofbeds, depname, healthinstid)
values (512, 47, 'Pharmacy', 170);
insert into DEPARTMENT_B (depid, numberofbeds, depname, healthinstid)
values (433, 14, 'Physiotherapy', 912);
insert into DEPARTMENT_B (depid, numberofbeds, depname, healthinstid)
values (660, 43, 'Purchasing & Supplies', 501);
insert into DEPARTMENT_B (depid, numberofbeds, depname, healthinstid)
values (667, 38, 'Radiology', 893);
insert into DEPARTMENT_B (depid, numberofbeds, depname, healthinstid)
values (460, 39, 'Radiotherapy', 857);
insert into DEPARTMENT_B (depid, numberofbeds, depname, healthinstid)
values (895, 39, 'Renal', 443);
insert into DEPARTMENT_B (depid, numberofbeds, depname, healthinstid)
values (368, 29, 'Rheumatology', 297);
insert into DEPARTMENT_B (depid, numberofbeds, depname, healthinstid)
values (74, 40, 'Sexual Health', 566);
insert into DEPARTMENT_B (depid, numberofbeds, depname, healthinstid)
values (738, 44, 'Social Work', 164);
insert into DEPARTMENT_B (depid, numberofbeds, depname, healthinstid)
values (88, 46, 'Burn Center', 996);
insert into DEPARTMENT_B (depid, numberofbeds, depname, healthinstid)
values (866, 41, 'Cardiology', 652);
insert into DEPARTMENT_B (depid, numberofbeds, depname, healthinstid)
values (205, 16, 'CSSD', 582);
insert into DEPARTMENT_B (depid, numberofbeds, depname, healthinstid)
values (157, 37, 'Chaplaincy', 564);
insert into DEPARTMENT_B (depid, numberofbeds, depname, healthinstid)
values (932, 38, 'Coronary Care Unit', 815);
insert into DEPARTMENT_B (depid, numberofbeds, depname, healthinstid)
values (779, 21, 'Critical Care', 820);
insert into DEPARTMENT_B (depid, numberofbeds, depname, healthinstid)
values (766, 23, 'Diagnostic Imaging', 157);
insert into DEPARTMENT_B (depid, numberofbeds, depname, healthinstid)
values (366, 13, 'Discharge Lounge', 281);
insert into DEPARTMENT_B (depid, numberofbeds, depname, healthinstid)
values (592, 16, 'Elderly services', 420);
insert into DEPARTMENT_B (depid, numberofbeds, depname, healthinstid)
values (438, 12, 'Finance Department', 408);
insert into DEPARTMENT_B (depid, numberofbeds, depname, healthinstid)
values (393, 24, 'Gastroenterology', 279);
insert into DEPARTMENT_B (depid, numberofbeds, depname, healthinstid)
values (760, 43, 'General Services', 423);
insert into DEPARTMENT_B (depid, numberofbeds, depname, healthinstid)
values (791, 44, 'General Surgery', 573);
insert into DEPARTMENT_B (depid, numberofbeds, depname, healthinstid)
values (875, 39, 'Gynecology', 292);
insert into DEPARTMENT_B (depid, numberofbeds, depname, healthinstid)
values (223, 13, 'Purchasing & Supplies', 146);
insert into DEPARTMENT_B (depid, numberofbeds, depname, healthinstid)
values (338, 30, 'Radiology', 338);
insert into DEPARTMENT_B (depid, numberofbeds, depname, healthinstid)
values (219, 46, 'Radiotherapy', 364);
insert into DEPARTMENT_B (depid, numberofbeds, depname, healthinstid)
values (994, 23, 'Renal', 340);
insert into DEPARTMENT_B (depid, numberofbeds, depname, healthinstid)
values (289, 41, 'Rheumatology', 180);
insert into DEPARTMENT_B (depid, numberofbeds, depname, healthinstid)
values (873, 26, 'Sexual Health', 713);
insert into DEPARTMENT_B (depid, numberofbeds, depname, healthinstid)
values (107, 17, 'Social Work', 809);
insert into DEPARTMENT_B (depid, numberofbeds, depname, healthinstid)
values (651, 37, 'Urology', 839);
insert into DEPARTMENT_B (depid, numberofbeds, depname, healthinstid)
values (197, 46, 'Occupational Therapy', 656);
insert into DEPARTMENT_B (depid, numberofbeds, depname, healthinstid)
values (388, 25, 'Oncology', 834);
insert into DEPARTMENT_B (depid, numberofbeds, depname, healthinstid)
values (781, 24, 'Ophthalmology', 34);
insert into DEPARTMENT_B (depid, numberofbeds, depname, healthinstid)
values (161, 37, 'Orthopaedics', 616);
insert into DEPARTMENT_B (depid, numberofbeds, depname, healthinstid)
values (458, 47, 'Otolaryngology', 931);
insert into DEPARTMENT_B (depid, numberofbeds, depname, healthinstid)
values (476, 30, 'Pain Management', 503);
insert into DEPARTMENT_B (depid, numberofbeds, depname, healthinstid)
values (652, 40, 'Patient Accounts', 748);
insert into DEPARTMENT_B (depid, numberofbeds, depname, healthinstid)
values (337, 48, 'Patient Services', 381);
insert into DEPARTMENT_B (depid, numberofbeds, depname, healthinstid)
values (547, 34, 'Pharmacy', 352);
insert into DEPARTMENT_B (depid, numberofbeds, depname, healthinstid)
values (546, 47, 'Physiotherapy', 25);
insert into DEPARTMENT_B (depid, numberofbeds, depname, healthinstid)
values (747, 46, 'Purchasing & Supplies', 31);
insert into DEPARTMENT_B (depid, numberofbeds, depname, healthinstid)
values (967, 46, 'Radiology', 200);
insert into DEPARTMENT_B (depid, numberofbeds, depname, healthinstid)
values (415, 12, 'Radiotherapy', 107);
insert into DEPARTMENT_B (depid, numberofbeds, depname, healthinstid)
values (561, 14, 'Renal', 601);
insert into DEPARTMENT_B (depid, numberofbeds, depname, healthinstid)
values (479, 41, 'Rheumatology', 310);
insert into DEPARTMENT_B (depid, numberofbeds, depname, healthinstid)
values (736, 21, 'Sexual Health', 526);
insert into DEPARTMENT_B (depid, numberofbeds, depname, healthinstid)
values (343, 27, 'Social Work', 831);
insert into DEPARTMENT_B (depid, numberofbeds, depname, healthinstid)
values (882, 31, 'Burn Center', 121);
insert into DEPARTMENT_B (depid, numberofbeds, depname, healthinstid)
values (198, 45, 'Cardiology', 313);
insert into DEPARTMENT_B (depid, numberofbeds, depname, healthinstid)
values (641, 40, 'CSSD', 339);
insert into DEPARTMENT_B (depid, numberofbeds, depname, healthinstid)
values (713, 49, 'Chaplaincy', 942);
insert into DEPARTMENT_B (depid, numberofbeds, depname, healthinstid)
values (353, 36, 'Coronary Care Unit', 363);
insert into DEPARTMENT_B (depid, numberofbeds, depname, healthinstid)
values (797, 35, 'Critical Care', 572);
insert into DEPARTMENT_B (depid, numberofbeds, depname, healthinstid)
values (645, 43, 'Diagnostic Imaging', 111);
insert into DEPARTMENT_B (depid, numberofbeds, depname, healthinstid)
values (811, 17, 'Discharge Lounge', 555);
insert into DEPARTMENT_B (depid, numberofbeds, depname, healthinstid)
values (548, 28, 'Elderly services', 714);
insert into DEPARTMENT_B (depid, numberofbeds, depname, healthinstid)
values (0, 41, 'Finance Department', 584);
insert into DEPARTMENT_B (depid, numberofbeds, depname, healthinstid)
values (472, 25, 'Gastroenterology', 854);
insert into DEPARTMENT_B (depid, numberofbeds, depname, healthinstid)
values (325, 44, 'General Services', 892);
insert into DEPARTMENT_B (depid, numberofbeds, depname, healthinstid)
values (457, 29, 'General Surgery', 781);
insert into DEPARTMENT_B (depid, numberofbeds, depname, healthinstid)
values (522, 13, 'Gynecology', 309);
insert into DEPARTMENT_B (depid, numberofbeds, depname, healthinstid)
values (828, 39, 'Haematology', 883);
insert into DEPARTMENT_B (depid, numberofbeds, depname, healthinstid)
values (922, 44, 'Health & Safety', 319);
insert into DEPARTMENT_B (depid, numberofbeds, depname, healthinstid)
values (756, 36, 'Intensive Care Unit', 174);
insert into DEPARTMENT_B (depid, numberofbeds, depname, healthinstid)
values (2, 29, 'Human Resources', 427);
insert into DEPARTMENT_B (depid, numberofbeds, depname, healthinstid)
values (860, 27, 'Admissions', 455);
insert into DEPARTMENT_B (depid, numberofbeds, depname, healthinstid)
values (806, 34, 'Anesthetics', 331);
insert into DEPARTMENT_B (depid, numberofbeds, depname, healthinstid)
values (952, 17, 'Breast Screening', 589);
insert into DEPARTMENT_B (depid, numberofbeds, depname, healthinstid)
values (517, 35, 'Burn Center', 759);
insert into DEPARTMENT_B (depid, numberofbeds, depname, healthinstid)
values (918, 50, 'Cardiology', 865);
insert into DEPARTMENT_B (depid, numberofbeds, depname, healthinstid)
values (103, 49, 'CSSD', 648);
insert into DEPARTMENT_B (depid, numberofbeds, depname, healthinstid)
values (191, 17, 'Chaplaincy', 547);
insert into DEPARTMENT_B (depid, numberofbeds, depname, healthinstid)
values (32, 29, 'Coronary Care Unit', 360);
insert into DEPARTMENT_B (depid, numberofbeds, depname, healthinstid)
values (68, 37, 'Critical Care', 435);
insert into DEPARTMENT_B (depid, numberofbeds, depname, healthinstid)
values (371, 20, 'Diagnostic Imaging', 861);
insert into DEPARTMENT_B (depid, numberofbeds, depname, healthinstid)
values (173, 27, 'Discharge Lounge', 726);
insert into DEPARTMENT_B (depid, numberofbeds, depname, healthinstid)
values (102, 47, 'Elderly services', 758);
insert into DEPARTMENT_B (depid, numberofbeds, depname, healthinstid)
values (392, 23, 'Finance Department', 224);
insert into DEPARTMENT_B (depid, numberofbeds, depname, healthinstid)
values (344, 19, 'Gastroenterology', 42);
insert into DEPARTMENT_B (depid, numberofbeds, depname, healthinstid)
values (28, 22, 'General Services', 116);
insert into DEPARTMENT_B (depid, numberofbeds, depname, healthinstid)
values (395, 33, 'General Surgery', 431);
insert into DEPARTMENT_B (depid, numberofbeds, depname, healthinstid)
values (674, 18, 'Gynecology', 380);
insert into DEPARTMENT_B (depid, numberofbeds, depname, healthinstid)
values (383, 29, 'Haematology', 426);
insert into DEPARTMENT_B (depid, numberofbeds, depname, healthinstid)
values (677, 43, 'Health & Safety', 546);
insert into DEPARTMENT_B (depid, numberofbeds, depname, healthinstid)
values (840, 46, 'Ophthalmology', 186);
insert into DEPARTMENT_B (depid, numberofbeds, depname, healthinstid)
values (123, 18, 'Orthopaedics', 632);
insert into DEPARTMENT_B (depid, numberofbeds, depname, healthinstid)
values (280, 31, 'Otolaryngology', 789);
insert into DEPARTMENT_B (depid, numberofbeds, depname, healthinstid)
values (584, 32, 'Pain Management', 860);
insert into DEPARTMENT_B (depid, numberofbeds, depname, healthinstid)
values (495, 42, 'Patient Accounts', 74);
insert into DEPARTMENT_B (depid, numberofbeds, depname, healthinstid)
values (76, 38, 'Patient Services', 472);
insert into DEPARTMENT_B (depid, numberofbeds, depname, healthinstid)
values (122, 16, 'Pharmacy', 514);
insert into DEPARTMENT_B (depid, numberofbeds, depname, healthinstid)
values (283, 44, 'Physiotherapy', 680);
insert into DEPARTMENT_B (depid, numberofbeds, depname, healthinstid)
values (949, 46, 'Purchasing & Supplies', 213);
insert into DEPARTMENT_B (depid, numberofbeds, depname, healthinstid)
values (764, 36, 'Radiology', 51);
insert into DEPARTMENT_B (depid, numberofbeds, depname, healthinstid)
values (225, 25, 'Radiotherapy', 581);
insert into DEPARTMENT_B (depid, numberofbeds, depname, healthinstid)
values (580, 17, 'Renal', 78);
insert into DEPARTMENT_B (depid, numberofbeds, depname, healthinstid)
values (300, 45, 'Rheumatology', 895);
insert into DEPARTMENT_B (depid, numberofbeds, depname, healthinstid)
values (511, 41, 'Sexual Health', 301);
insert into DEPARTMENT_B (depid, numberofbeds, depname, healthinstid)
values (762, 16, 'Social Work', 151);
insert into DEPARTMENT_B (depid, numberofbeds, depname, healthinstid)
values (443, 42, 'Urology', 170);
insert into DEPARTMENT_B (depid, numberofbeds, depname, healthinstid)
values (940, 22, 'Occupational Therapy', 912);
insert into DEPARTMENT_B (depid, numberofbeds, depname, healthinstid)
values (378, 49, 'Oncology', 501);
insert into DEPARTMENT_B (depid, numberofbeds, depname, healthinstid)
values (664, 25, 'Ophthalmology', 893);
insert into DEPARTMENT_B (depid, numberofbeds, depname, healthinstid)
values (12, 24, 'Orthopaedics', 857);
insert into DEPARTMENT_B (depid, numberofbeds, depname, healthinstid)
values (562, 38, 'Otolaryngology', 443);
insert into DEPARTMENT_B (depid, numberofbeds, depname, healthinstid)
values (459, 20, 'Pain Management', 297);
insert into DEPARTMENT_B (depid, numberofbeds, depname, healthinstid)
values (15, 21, 'Patient Accounts', 566);
insert into DEPARTMENT_B (depid, numberofbeds, depname, healthinstid)
values (524, 42, 'Patient Services', 164);
insert into DEPARTMENT_B (depid, numberofbeds, depname, healthinstid)
values (852, 31, 'Pharmacy', 996);
insert into DEPARTMENT_B (depid, numberofbeds, depname, healthinstid)
values (941, 43, 'Physiotherapy', 652);
insert into DEPARTMENT_B (depid, numberofbeds, depname, healthinstid)
values (382, 29, 'Purchasing & Supplies', 582);
insert into DEPARTMENT_B (depid, numberofbeds, depname, healthinstid)
values (627, 28, 'Radiology', 564);
insert into DEPARTMENT_B (depid, numberofbeds, depname, healthinstid)
values (390, 27, 'Radiotherapy', 815);
insert into DEPARTMENT_B (depid, numberofbeds, depname, healthinstid)
values (193, 47, 'Renal', 820);
insert into DEPARTMENT_B (depid, numberofbeds, depname, healthinstid)
values (826, 14, 'Rheumatology', 157);
insert into DEPARTMENT_B (depid, numberofbeds, depname, healthinstid)
values (855, 33, 'Sexual Health', 281);
insert into DEPARTMENT_B (depid, numberofbeds, depname, healthinstid)
values (778, 50, 'Social Work', 420);
insert into DEPARTMENT_B (depid, numberofbeds, depname, healthinstid)
values (815, 28, 'Burn Center', 408);
insert into DEPARTMENT_B (depid, numberofbeds, depname, healthinstid)
values (60, 12, 'Cardiology', 279);
insert into DEPARTMENT_B (depid, numberofbeds, depname, healthinstid)
values (84, 25, 'CSSD', 423);
insert into DEPARTMENT_B (depid, numberofbeds, depname, healthinstid)
values (341, 27, 'Chaplaincy', 573);
insert into DEPARTMENT_B (depid, numberofbeds, depname, healthinstid)
values (725, 16, 'Coronary Care Unit', 292);
insert into DEPARTMENT_B (depid, numberofbeds, depname, healthinstid)
values (730, 30, 'Critical Care', 146);
insert into DEPARTMENT_B (depid, numberofbeds, depname, healthinstid)
values (287, 17, 'Diagnostic Imaging', 338);
insert into DEPARTMENT_B (depid, numberofbeds, depname, healthinstid)
values (837, 46, 'Discharge Lounge', 364);
insert into DEPARTMENT_B (depid, numberofbeds, depname, healthinstid)
values (345, 42, 'Elderly services', 340);
insert into DEPARTMENT_B (depid, numberofbeds, depname, healthinstid)
values (625, 44, 'Finance Department', 180);
insert into DEPARTMENT_B (depid, numberofbeds, depname, healthinstid)
values (646, 19, 'Sexual Health', 713);
insert into DEPARTMENT_B (depid, numberofbeds, depname, healthinstid)
values (933, 33, 'Social Work', 809);
insert into DEPARTMENT_B (depid, numberofbeds, depname, healthinstid)
values (164, 21, 'Urology', 839);
insert into DEPARTMENT_B (depid, numberofbeds, depname, healthinstid)
values (217, 27, 'Occupational Therapy', 656);
insert into DEPARTMENT_B (depid, numberofbeds, depname, healthinstid)
values (678, 42, 'Oncology', 834);
insert into DEPARTMENT_B (depid, numberofbeds, depname, healthinstid)
values (41, 16, 'Ophthalmology', 34);
insert into DEPARTMENT_B (depid, numberofbeds, depname, healthinstid)
values (152, 17, 'Orthopaedics', 616);
insert into DEPARTMENT_B (depid, numberofbeds, depname, healthinstid)
values (444, 42, 'Otolaryngology', 931);
insert into DEPARTMENT_B (depid, numberofbeds, depname, healthinstid)
values (65, 47, 'Pain Management', 503);
insert into DEPARTMENT_B (depid, numberofbeds, depname, healthinstid)
values (516, 17, 'Patient Accounts', 748);
prompt 264 records loaded
prompt Enabling foreign key constraints for DEPARTMENT_B...
alter table DEPARTMENT_B enable constraint SYS_C007578;
prompt Enabling triggers for DEPARTMENT_B...
alter table DEPARTMENT_B enable all triggers;

set feedback on
set define on
prompt Done
