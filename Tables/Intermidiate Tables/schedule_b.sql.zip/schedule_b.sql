?��prompt PL/SQL Developer Export Tables for user SYSTEM
prompt Created by Evyatar on יום שני 10 אוגוסט 2020
set feedback off
set define off

prompt Creating SCHEDULE_B...
create table SCHEDULE_B
(
  meetingtime DATE not null,
  clerkid     NUMBER(9) not null,
  citizenid   INTEGER not null
)
tablespace SYSTEM
  pctfree 10
  pctused 40
  initrans 1
  maxtrans 255
  storage
  (
    initial 64K
    next 1M
    minextents 1
    maxextents unlimited
  );
alter table SCHEDULE_B
  add primary key (MEETINGTIME, CLERKID, CITIZENID)
  using index 
  tablespace SYSTEM
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 64K
    next 1M
    minextents 1
    maxextents unlimited
  );
alter table SCHEDULE_B
  add foreign key (CLERKID)
  references CLERK (CLERKID);
alter table SCHEDULE_B
  add foreign key (CITIZENID)
  references CITIZEN (CITIZENID);

prompt Disabling triggers for SCHEDULE_B...
alter table SCHEDULE_B disable all triggers;
prompt Disabling foreign key constraints for SCHEDULE_B...
alter table SCHEDULE_B disable constraint SYS_C007547;
alter table SCHEDULE_B disable constraint SYS_C007548;
prompt Deleting SCHEDULE_B...
delete from SCHEDULE_B;
prompt Loading SCHEDULE_B...
insert into SCHEDULE_B (meetingtime, clerkid, citizenid)
values (to_date('02-01-2020 04:39:47', 'dd-mm-yyyy hh24:mi:ss'), 742868808, 618144212);
insert into SCHEDULE_B (meetingtime, clerkid, citizenid)
values (to_date('08-01-2020 15:56:26', 'dd-mm-yyyy hh24:mi:ss'), 413518592, 55937608);
insert into SCHEDULE_B (meetingtime, clerkid, citizenid)
values (to_date('12-01-2020 18:58:45', 'dd-mm-yyyy hh24:mi:ss'), 797503856, 121670810);
insert into SCHEDULE_B (meetingtime, clerkid, citizenid)
values (to_date('14-01-2020 09:14:49', 'dd-mm-yyyy hh24:mi:ss'), 744958679, 709915279);
insert into SCHEDULE_B (meetingtime, clerkid, citizenid)
values (to_date('16-01-2020 03:28:04', 'dd-mm-yyyy hh24:mi:ss'), 230298738, 49629406);
insert into SCHEDULE_B (meetingtime, clerkid, citizenid)
values (to_date('18-01-2020 15:22:53', 'dd-mm-yyyy hh24:mi:ss'), 89160074, 434940113);
insert into SCHEDULE_B (meetingtime, clerkid, citizenid)
values (to_date('20-01-2020 09:18:00', 'dd-mm-yyyy hh24:mi:ss'), 462438254, 79504732);
insert into SCHEDULE_B (meetingtime, clerkid, citizenid)
values (to_date('28-01-2020 10:30:51', 'dd-mm-yyyy hh24:mi:ss'), 675975458, 784600813);
insert into SCHEDULE_B (meetingtime, clerkid, citizenid)
values (to_date('01-02-2020 04:09:50', 'dd-mm-yyyy hh24:mi:ss'), 358888404, 365963339);
insert into SCHEDULE_B (meetingtime, clerkid, citizenid)
values (to_date('02-02-2020 00:30:31', 'dd-mm-yyyy hh24:mi:ss'), 377845907, 189811489);
insert into SCHEDULE_B (meetingtime, clerkid, citizenid)
values (to_date('02-02-2020 13:22:48', 'dd-mm-yyyy hh24:mi:ss'), 97748603, 156171593);
insert into SCHEDULE_B (meetingtime, clerkid, citizenid)
values (to_date('05-02-2020 08:41:16', 'dd-mm-yyyy hh24:mi:ss'), 50870763, 129407872);
insert into SCHEDULE_B (meetingtime, clerkid, citizenid)
values (to_date('07-02-2020 03:22:53', 'dd-mm-yyyy hh24:mi:ss'), 775027789, 64526097);
insert into SCHEDULE_B (meetingtime, clerkid, citizenid)
values (to_date('12-02-2020 12:26:47', 'dd-mm-yyyy hh24:mi:ss'), 640330926, 426148194);
insert into SCHEDULE_B (meetingtime, clerkid, citizenid)
values (to_date('22-02-2020 05:33:38', 'dd-mm-yyyy hh24:mi:ss'), 48780608, 426148194);
insert into SCHEDULE_B (meetingtime, clerkid, citizenid)
values (to_date('25-02-2020 06:15:41', 'dd-mm-yyyy hh24:mi:ss'), 231962714, 79504732);
insert into SCHEDULE_B (meetingtime, clerkid, citizenid)
values (to_date('03-03-2020 08:06:25', 'dd-mm-yyyy hh24:mi:ss'), 340526675, 591829232);
insert into SCHEDULE_B (meetingtime, clerkid, citizenid)
values (to_date('05-03-2020 13:40:48', 'dd-mm-yyyy hh24:mi:ss'), 216673752, 603338542);
insert into SCHEDULE_B (meetingtime, clerkid, citizenid)
values (to_date('09-03-2020 22:42:14', 'dd-mm-yyyy hh24:mi:ss'), 640574572, 779945885);
insert into SCHEDULE_B (meetingtime, clerkid, citizenid)
values (to_date('21-03-2020 06:58:36', 'dd-mm-yyyy hh24:mi:ss'), 412908680, 897773040);
insert into SCHEDULE_B (meetingtime, clerkid, citizenid)
values (to_date('23-03-2020 15:02:18', 'dd-mm-yyyy hh24:mi:ss'), 999775205, 710935253);
insert into SCHEDULE_B (meetingtime, clerkid, citizenid)
values (to_date('24-03-2020 08:27:10', 'dd-mm-yyyy hh24:mi:ss'), 889893500, 173006051);
insert into SCHEDULE_B (meetingtime, clerkid, citizenid)
values (to_date('24-03-2020 20:17:57', 'dd-mm-yyyy hh24:mi:ss'), 48780608, 996662084);
insert into SCHEDULE_B (meetingtime, clerkid, citizenid)
values (to_date('02-04-2020 08:24:34', 'dd-mm-yyyy hh24:mi:ss'), 50870763, 330927664);
insert into SCHEDULE_B (meetingtime, clerkid, citizenid)
values (to_date('02-04-2020 09:54:51', 'dd-mm-yyyy hh24:mi:ss'), 315265026, 670150291);
insert into SCHEDULE_B (meetingtime, clerkid, citizenid)
values (to_date('07-04-2020 20:28:27', 'dd-mm-yyyy hh24:mi:ss'), 132751178, 955095939);
insert into SCHEDULE_B (meetingtime, clerkid, citizenid)
values (to_date('08-04-2020 08:14:47', 'dd-mm-yyyy hh24:mi:ss'), 552470268, 840454690);
insert into SCHEDULE_B (meetingtime, clerkid, citizenid)
values (to_date('08-04-2020 22:18:28', 'dd-mm-yyyy hh24:mi:ss'), 352326915, 892580017);
insert into SCHEDULE_B (meetingtime, clerkid, citizenid)
values (to_date('12-04-2020 10:16:45', 'dd-mm-yyyy hh24:mi:ss'), 89541503, 55937608);
insert into SCHEDULE_B (meetingtime, clerkid, citizenid)
values (to_date('17-04-2020 02:51:21', 'dd-mm-yyyy hh24:mi:ss'), 62588564, 792958079);
insert into SCHEDULE_B (meetingtime, clerkid, citizenid)
values (to_date('23-04-2020 18:22:45', 'dd-mm-yyyy hh24:mi:ss'), 953496147, 724134639);
insert into SCHEDULE_B (meetingtime, clerkid, citizenid)
values (to_date('25-04-2020 12:59:45', 'dd-mm-yyyy hh24:mi:ss'), 742868808, 79504732);
insert into SCHEDULE_B (meetingtime, clerkid, citizenid)
values (to_date('27-04-2020 06:15:59', 'dd-mm-yyyy hh24:mi:ss'), 640330926, 742852779);
insert into SCHEDULE_B (meetingtime, clerkid, citizenid)
values (to_date('28-04-2020 19:11:25', 'dd-mm-yyyy hh24:mi:ss'), 710604897, 640808719);
insert into SCHEDULE_B (meetingtime, clerkid, citizenid)
values (to_date('07-05-2020 10:09:41', 'dd-mm-yyyy hh24:mi:ss'), 970992503, 434940113);
insert into SCHEDULE_B (meetingtime, clerkid, citizenid)
values (to_date('07-05-2020 19:59:22', 'dd-mm-yyyy hh24:mi:ss'), 470721569, 850636732);
insert into SCHEDULE_B (meetingtime, clerkid, citizenid)
values (to_date('11-05-2020 23:30:20', 'dd-mm-yyyy hh24:mi:ss'), 89541503, 670150291);
insert into SCHEDULE_B (meetingtime, clerkid, citizenid)
values (to_date('18-05-2020 00:48:23', 'dd-mm-yyyy hh24:mi:ss'), 479478250, 724134639);
insert into SCHEDULE_B (meetingtime, clerkid, citizenid)
values (to_date('18-05-2020 05:00:05', 'dd-mm-yyyy hh24:mi:ss'), 50870763, 936814527);
insert into SCHEDULE_B (meetingtime, clerkid, citizenid)
values (to_date('18-05-2020 08:28:27', 'dd-mm-yyyy hh24:mi:ss'), 83705991, 620937216);
insert into SCHEDULE_B (meetingtime, clerkid, citizenid)
values (to_date('18-05-2020 14:13:12', 'dd-mm-yyyy hh24:mi:ss'), 632486887, 996662084);
insert into SCHEDULE_B (meetingtime, clerkid, citizenid)
values (to_date('29-05-2020 04:54:02', 'dd-mm-yyyy hh24:mi:ss'), 744958679, 360147273);
insert into SCHEDULE_B (meetingtime, clerkid, citizenid)
values (to_date('11-06-2020 12:34:24', 'dd-mm-yyyy hh24:mi:ss'), 657042160, 79504732);
insert into SCHEDULE_B (meetingtime, clerkid, citizenid)
values (to_date('16-06-2020 11:32:12', 'dd-mm-yyyy hh24:mi:ss'), 413518592, 452323355);
insert into SCHEDULE_B (meetingtime, clerkid, citizenid)
values (to_date('20-06-2020 00:30:23', 'dd-mm-yyyy hh24:mi:ss'), 775027789, 388283660);
insert into SCHEDULE_B (meetingtime, clerkid, citizenid)
values (to_date('22-06-2020 03:54:00', 'dd-mm-yyyy hh24:mi:ss'), 744958679, 751988735);
insert into SCHEDULE_B (meetingtime, clerkid, citizenid)
values (to_date('28-06-2020 13:30:34', 'dd-mm-yyyy hh24:mi:ss'), 50870763, 719978224);
insert into SCHEDULE_B (meetingtime, clerkid, citizenid)
values (to_date('01-07-2020 00:40:45', 'dd-mm-yyyy hh24:mi:ss'), 177769483, 152874477);
insert into SCHEDULE_B (meetingtime, clerkid, citizenid)
values (to_date('05-07-2020 16:32:44', 'dd-mm-yyyy hh24:mi:ss'), 278216922, 792958079);
insert into SCHEDULE_B (meetingtime, clerkid, citizenid)
values (to_date('15-07-2020 23:19:40', 'dd-mm-yyyy hh24:mi:ss'), 602574296, 834214215);
insert into SCHEDULE_B (meetingtime, clerkid, citizenid)
values (to_date('19-07-2020 22:04:30', 'dd-mm-yyyy hh24:mi:ss'), 224334980, 642196831);
insert into SCHEDULE_B (meetingtime, clerkid, citizenid)
values (to_date('20-07-2020 01:01:20', 'dd-mm-yyyy hh24:mi:ss'), 953496147, 784600813);
insert into SCHEDULE_B (meetingtime, clerkid, citizenid)
values (to_date('26-07-2020 09:11:57', 'dd-mm-yyyy hh24:mi:ss'), 566015263, 708262840);
insert into SCHEDULE_B (meetingtime, clerkid, citizenid)
values (to_date('05-08-2020 02:45:36', 'dd-mm-yyyy hh24:mi:ss'), 688678649, 364323076);
insert into SCHEDULE_B (meetingtime, clerkid, citizenid)
values (to_date('11-08-2020 04:03:47', 'dd-mm-yyyy hh24:mi:ss'), 352326915, 434940113);
insert into SCHEDULE_B (meetingtime, clerkid, citizenid)
values (to_date('13-08-2020 16:09:59', 'dd-mm-yyyy hh24:mi:ss'), 380575697, 592650513);
insert into SCHEDULE_B (meetingtime, clerkid, citizenid)
values (to_date('15-08-2020 02:49:20', 'dd-mm-yyyy hh24:mi:ss'), 536047901, 936814527);
insert into SCHEDULE_B (meetingtime, clerkid, citizenid)
values (to_date('16-08-2020 03:11:57', 'dd-mm-yyyy hh24:mi:ss'), 216673752, 869593414);
insert into SCHEDULE_B (meetingtime, clerkid, citizenid)
values (to_date('17-08-2020 11:19:40', 'dd-mm-yyyy hh24:mi:ss'), 640330926, 156171593);
insert into SCHEDULE_B (meetingtime, clerkid, citizenid)
values (to_date('19-08-2020 03:10:22', 'dd-mm-yyyy hh24:mi:ss'), 632486887, 640808719);
insert into SCHEDULE_B (meetingtime, clerkid, citizenid)
values (to_date('24-08-2020 22:06:31', 'dd-mm-yyyy hh24:mi:ss'), 657042160, 211681471);
insert into SCHEDULE_B (meetingtime, clerkid, citizenid)
values (to_date('26-08-2020 18:28:39', 'dd-mm-yyyy hh24:mi:ss'), 219641402, 191386480);
insert into SCHEDULE_B (meetingtime, clerkid, citizenid)
values (to_date('28-08-2020 08:16:56', 'dd-mm-yyyy hh24:mi:ss'), 58713028, 726919780);
insert into SCHEDULE_B (meetingtime, clerkid, citizenid)
values (to_date('03-09-2020 09:24:46', 'dd-mm-yyyy hh24:mi:ss'), 62588564, 784600813);
insert into SCHEDULE_B (meetingtime, clerkid, citizenid)
values (to_date('08-09-2020 09:51:33', 'dd-mm-yyyy hh24:mi:ss'), 424689583, 482818846);
insert into SCHEDULE_B (meetingtime, clerkid, citizenid)
values (to_date('11-09-2020 05:56:06', 'dd-mm-yyyy hh24:mi:ss'), 230298738, 360147273);
insert into SCHEDULE_B (meetingtime, clerkid, citizenid)
values (to_date('13-09-2020 03:29:31', 'dd-mm-yyyy hh24:mi:ss'), 675975458, 467351472);
insert into SCHEDULE_B (meetingtime, clerkid, citizenid)
values (to_date('23-09-2020 02:18:05', 'dd-mm-yyyy hh24:mi:ss'), 352326915, 360147273);
insert into SCHEDULE_B (meetingtime, clerkid, citizenid)
values (to_date('28-09-2020 08:10:53', 'dd-mm-yyyy hh24:mi:ss'), 889893500, 640808719);
insert into SCHEDULE_B (meetingtime, clerkid, citizenid)
values (to_date('29-09-2020 10:36:20', 'dd-mm-yyyy hh24:mi:ss'), 340526675, 202710130);
insert into SCHEDULE_B (meetingtime, clerkid, citizenid)
values (to_date('05-10-2020 00:47:05', 'dd-mm-yyyy hh24:mi:ss'), 230298738, 908000615);
insert into SCHEDULE_B (meetingtime, clerkid, citizenid)
values (to_date('06-10-2020 13:05:48', 'dd-mm-yyyy hh24:mi:ss'), 710604897, 945582077);
insert into SCHEDULE_B (meetingtime, clerkid, citizenid)
values (to_date('14-10-2020 20:20:32', 'dd-mm-yyyy hh24:mi:ss'), 424689583, 202710130);
insert into SCHEDULE_B (meetingtime, clerkid, citizenid)
values (to_date('17-10-2020 15:53:51', 'dd-mm-yyyy hh24:mi:ss'), 986515397, 742852779);
insert into SCHEDULE_B (meetingtime, clerkid, citizenid)
values (to_date('17-10-2020 23:13:12', 'dd-mm-yyyy hh24:mi:ss'), 769944696, 426148194);
insert into SCHEDULE_B (meetingtime, clerkid, citizenid)
values (to_date('19-10-2020 18:21:27', 'dd-mm-yyyy hh24:mi:ss'), 865215977, 670150291);
insert into SCHEDULE_B (meetingtime, clerkid, citizenid)
values (to_date('26-10-2020 23:41:34', 'dd-mm-yyyy hh24:mi:ss'), 901257019, 486877093);
insert into SCHEDULE_B (meetingtime, clerkid, citizenid)
values (to_date('31-10-2020 16:13:35', 'dd-mm-yyyy hh24:mi:ss'), 985608353, 640808719);
insert into SCHEDULE_B (meetingtime, clerkid, citizenid)
values (to_date('03-11-2020 15:55:52', 'dd-mm-yyyy hh24:mi:ss'), 242059824, 437511476);
insert into SCHEDULE_B (meetingtime, clerkid, citizenid)
values (to_date('04-11-2020 08:59:34', 'dd-mm-yyyy hh24:mi:ss'), 769944696, 364323076);
insert into SCHEDULE_B (meetingtime, clerkid, citizenid)
values (to_date('10-11-2020 22:25:49', 'dd-mm-yyyy hh24:mi:ss'), 198620173, 618144212);
insert into SCHEDULE_B (meetingtime, clerkid, citizenid)
values (to_date('14-11-2020 02:07:43', 'dd-mm-yyyy hh24:mi:ss'), 701642916, 191386480);
insert into SCHEDULE_B (meetingtime, clerkid, citizenid)
values (to_date('15-11-2020 16:27:33', 'dd-mm-yyyy hh24:mi:ss'), 744958679, 503126262);
insert into SCHEDULE_B (meetingtime, clerkid, citizenid)
values (to_date('23-11-2020 08:28:10', 'dd-mm-yyyy hh24:mi:ss'), 37773505, 620937216);
insert into SCHEDULE_B (meetingtime, clerkid, citizenid)
values (to_date('25-11-2020 19:24:31', 'dd-mm-yyyy hh24:mi:ss'), 219641402, 792958079);
insert into SCHEDULE_B (meetingtime, clerkid, citizenid)
values (to_date('29-11-2020 20:37:58', 'dd-mm-yyyy hh24:mi:ss'), 283304585, 365963339);
insert into SCHEDULE_B (meetingtime, clerkid, citizenid)
values (to_date('02-12-2020 11:19:32', 'dd-mm-yyyy hh24:mi:ss'), 657042160, 293713935);
insert into SCHEDULE_B (meetingtime, clerkid, citizenid)
values (to_date('08-12-2020 08:59:25', 'dd-mm-yyyy hh24:mi:ss'), 377845907, 330927664);
insert into SCHEDULE_B (meetingtime, clerkid, citizenid)
values (to_date('09-12-2020 16:58:13', 'dd-mm-yyyy hh24:mi:ss'), 219641402, 869593414);
insert into SCHEDULE_B (meetingtime, clerkid, citizenid)
values (to_date('13-12-2020 01:04:39', 'dd-mm-yyyy hh24:mi:ss'), 398251227, 754030724);
insert into SCHEDULE_B (meetingtime, clerkid, citizenid)
values (to_date('16-12-2020 15:08:03', 'dd-mm-yyyy hh24:mi:ss'), 675975458, 202710130);
insert into SCHEDULE_B (meetingtime, clerkid, citizenid)
values (to_date('19-12-2020 22:45:33', 'dd-mm-yyyy hh24:mi:ss'), 701642916, 293713935);
insert into SCHEDULE_B (meetingtime, clerkid, citizenid)
values (to_date('21-12-2020 20:25:26', 'dd-mm-yyyy hh24:mi:ss'), 56423791, 671660675);
insert into SCHEDULE_B (meetingtime, clerkid, citizenid)
values (to_date('22-12-2020 16:29:34', 'dd-mm-yyyy hh24:mi:ss'), 889893500, 191386480);
insert into SCHEDULE_B (meetingtime, clerkid, citizenid)
values (to_date('23-12-2020 00:55:00', 'dd-mm-yyyy hh24:mi:ss'), 714723836, 972999281);
insert into SCHEDULE_B (meetingtime, clerkid, citizenid)
values (to_date('23-12-2020 09:47:05', 'dd-mm-yyyy hh24:mi:ss'), 468433995, 187988627);
insert into SCHEDULE_B (meetingtime, clerkid, citizenid)
values (to_date('23-12-2020 21:58:19', 'dd-mm-yyyy hh24:mi:ss'), 826448233, 908000615);
insert into SCHEDULE_B (meetingtime, clerkid, citizenid)
values (to_date('26-12-2020 19:36:37', 'dd-mm-yyyy hh24:mi:ss'), 132751178, 156171593);
insert into SCHEDULE_B (meetingtime, clerkid, citizenid)
values (to_date('29-12-2020 04:59:57', 'dd-mm-yyyy hh24:mi:ss'), 520881414, 173006051);
insert into SCHEDULE_B (meetingtime, clerkid, citizenid)
values (to_date('31-12-2020 12:42:54', 'dd-mm-yyyy hh24:mi:ss'), 163989772, 152874477);
prompt 100 records loaded
prompt Enabling foreign key constraints for SCHEDULE_B...
alter table SCHEDULE_B enable constraint SYS_C007547;
alter table SCHEDULE_B enable constraint SYS_C007548;
prompt Enabling triggers for SCHEDULE_B...
alter table SCHEDULE_B enable all triggers;

set feedback on
set define on
prompt Done
