?��prompt PL/SQL Developer Export Tables for user SYSTEM
prompt Created by Evyatar on יום שני 10 אוגוסט 2020
set feedback off
set define off

prompt Creating WORKER_B...
create table WORKER_B
(
  workerid         NUMBER(9) not null,
  workername       VARCHAR2(50) not null,
  birthdate        DATE not null,
  itsboss_workerid NUMBER(9) not null
)
tablespace SYSTEM
  pctfree 10
  pctused 40
  initrans 1
  maxtrans 255
  storage
  (
    initial 64K
    next 1M
    minextents 1
    maxextents unlimited
  );
alter table WORKER_B
  add primary key (WORKERID)
  using index 
  tablespace SYSTEM
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 64K
    next 1M
    minextents 1
    maxextents unlimited
  );
alter table WORKER_B
  add foreign key (ITSBOSS_WORKERID)
  references WORKER_B (WORKERID);

prompt Disabling triggers for WORKER_B...
alter table WORKER_B disable all triggers;
prompt Disabling foreign key constraints for WORKER_B...
alter table WORKER_B disable constraint SYS_C007465;
prompt Deleting WORKER_B...
delete from WORKER_B;
prompt Loading WORKER_B...
insert into WORKER_B (workerid, workername, birthdate, itsboss_workerid)
values (531238815, 'Diamond Olson', to_date('20-01-2000', 'dd-mm-yyyy'), 531238815);
insert into WORKER_B (workerid, workername, birthdate, itsboss_workerid)
values (648956315, 'Maritza Marks', to_date('25-08-1957', 'dd-mm-yyyy'), 648956315);
insert into WORKER_B (workerid, workername, birthdate, itsboss_workerid)
values (71932811, 'Kennedy Chen', to_date('09-09-1992', 'dd-mm-yyyy'), 71932811);
insert into WORKER_B (workerid, workername, birthdate, itsboss_workerid)
values (311466467, 'Anthony Davila', to_date('16-05-1976', 'dd-mm-yyyy'), 311466467);
insert into WORKER_B (workerid, workername, birthdate, itsboss_workerid)
values (214019947, 'Payton Sloan', to_date('02-01-1989', 'dd-mm-yyyy'), 214019947);
insert into WORKER_B (workerid, workername, birthdate, itsboss_workerid)
values (655611592, 'Jeramiah Yu', to_date('22-08-1971', 'dd-mm-yyyy'), 655611592);
insert into WORKER_B (workerid, workername, birthdate, itsboss_workerid)
values (267895569, 'Gloria Hoffman', to_date('22-08-1979', 'dd-mm-yyyy'), 267895569);
insert into WORKER_B (workerid, workername, birthdate, itsboss_workerid)
values (475822438, 'Abel Hansen', to_date('03-06-1960', 'dd-mm-yyyy'), 475822438);
insert into WORKER_B (workerid, workername, birthdate, itsboss_workerid)
values (608832283, 'Amiya Drake', to_date('02-09-1964', 'dd-mm-yyyy'), 608832283);
insert into WORKER_B (workerid, workername, birthdate, itsboss_workerid)
values (871947790, 'Anna Velez', to_date('31-01-1971', 'dd-mm-yyyy'), 871947790);
insert into WORKER_B (workerid, workername, birthdate, itsboss_workerid)
values (156552498, 'Iyana Meza', to_date('16-10-1977', 'dd-mm-yyyy'), 871947790);
insert into WORKER_B (workerid, workername, birthdate, itsboss_workerid)
values (154508569, 'Johnathon Barnes', to_date('07-06-1964', 'dd-mm-yyyy'), 531238815);
insert into WORKER_B (workerid, workername, birthdate, itsboss_workerid)
values (918926951, 'Shaniya Dominguez', to_date('04-06-1987', 'dd-mm-yyyy'), 531238815);
insert into WORKER_B (workerid, workername, birthdate, itsboss_workerid)
values (867688554, 'Bentley Hunter', to_date('28-12-1956', 'dd-mm-yyyy'), 648956315);
insert into WORKER_B (workerid, workername, birthdate, itsboss_workerid)
values (684228936, 'Madyson Bradley', to_date('30-01-1969', 'dd-mm-yyyy'), 648956315);
insert into WORKER_B (workerid, workername, birthdate, itsboss_workerid)
values (518625103, 'Aiyana Hahn', to_date('10-06-1961', 'dd-mm-yyyy'), 71932811);
insert into WORKER_B (workerid, workername, birthdate, itsboss_workerid)
values (950758028, 'Zechariah Moran', to_date('30-11-1983', 'dd-mm-yyyy'), 71932811);
insert into WORKER_B (workerid, workername, birthdate, itsboss_workerid)
values (520553314, 'Eliza Smith', to_date('18-06-1963', 'dd-mm-yyyy'), 311466467);
insert into WORKER_B (workerid, workername, birthdate, itsboss_workerid)
values (505111071, 'Janae Nicholson', to_date('27-03-1996', 'dd-mm-yyyy'), 311466467);
insert into WORKER_B (workerid, workername, birthdate, itsboss_workerid)
values (65914345, 'Sarahi Wagner', to_date('22-05-1961', 'dd-mm-yyyy'), 214019947);
insert into WORKER_B (workerid, workername, birthdate, itsboss_workerid)
values (102975751, 'Fatima Livingston', to_date('30-04-1985', 'dd-mm-yyyy'), 214019947);
insert into WORKER_B (workerid, workername, birthdate, itsboss_workerid)
values (97370635, 'Ashleigh Winters', to_date('08-12-1989', 'dd-mm-yyyy'), 655611592);
insert into WORKER_B (workerid, workername, birthdate, itsboss_workerid)
values (157985841, 'Clayton Shah', to_date('25-07-1997', 'dd-mm-yyyy'), 655611592);
insert into WORKER_B (workerid, workername, birthdate, itsboss_workerid)
values (702948713, 'Emilia Bautista', to_date('20-02-1963', 'dd-mm-yyyy'), 267895569);
insert into WORKER_B (workerid, workername, birthdate, itsboss_workerid)
values (167848962, 'Martin Hodges', to_date('31-08-1973', 'dd-mm-yyyy'), 267895569);
insert into WORKER_B (workerid, workername, birthdate, itsboss_workerid)
values (477713169, 'Carlie Avery', to_date('12-12-1989', 'dd-mm-yyyy'), 475822438);
insert into WORKER_B (workerid, workername, birthdate, itsboss_workerid)
values (475432614, 'Mayra Mcgee', to_date('11-04-1985', 'dd-mm-yyyy'), 475822438);
insert into WORKER_B (workerid, workername, birthdate, itsboss_workerid)
values (978976997, 'Kelly Murphy', to_date('03-06-1983', 'dd-mm-yyyy'), 608832283);
insert into WORKER_B (workerid, workername, birthdate, itsboss_workerid)
values (960371044, 'Messiah Mercer', to_date('12-09-1956', 'dd-mm-yyyy'), 608832283);
insert into WORKER_B (workerid, workername, birthdate, itsboss_workerid)
values (125805491, 'Libby Brady', to_date('18-01-2000', 'dd-mm-yyyy'), 871947790);
insert into WORKER_B (workerid, workername, birthdate, itsboss_workerid)
values (882503173, 'Reynaldo Lucero', to_date('27-06-1961', 'dd-mm-yyyy'), 871947790);
insert into WORKER_B (workerid, workername, birthdate, itsboss_workerid)
values (90523324, 'Rowan Walters', to_date('15-04-1952', 'dd-mm-yyyy'), 531238815);
insert into WORKER_B (workerid, workername, birthdate, itsboss_workerid)
values (62842027, 'Rohan Patel', to_date('19-03-1993', 'dd-mm-yyyy'), 531238815);
insert into WORKER_B (workerid, workername, birthdate, itsboss_workerid)
values (85099344, 'Paxton Rogers', to_date('14-04-1982', 'dd-mm-yyyy'), 648956315);
insert into WORKER_B (workerid, workername, birthdate, itsboss_workerid)
values (585949230, 'Alexis Bean', to_date('03-02-1958', 'dd-mm-yyyy'), 648956315);
insert into WORKER_B (workerid, workername, birthdate, itsboss_workerid)
values (663022089, 'Tiara Wilkinson', to_date('04-03-1987', 'dd-mm-yyyy'), 71932811);
insert into WORKER_B (workerid, workername, birthdate, itsboss_workerid)
values (138808687, 'Taniya Best', to_date('24-08-1965', 'dd-mm-yyyy'), 71932811);
insert into WORKER_B (workerid, workername, birthdate, itsboss_workerid)
values (115866959, 'Kristian Perkins', to_date('18-05-1989', 'dd-mm-yyyy'), 311466467);
insert into WORKER_B (workerid, workername, birthdate, itsboss_workerid)
values (67162927, 'Daniella Ballard', to_date('24-12-1984', 'dd-mm-yyyy'), 311466467);
insert into WORKER_B (workerid, workername, birthdate, itsboss_workerid)
values (726182643, 'Bridger Nicholson', to_date('19-11-1985', 'dd-mm-yyyy'), 214019947);
insert into WORKER_B (workerid, workername, birthdate, itsboss_workerid)
values (867117574, 'Tanner Velazquez', to_date('16-07-1966', 'dd-mm-yyyy'), 214019947);
insert into WORKER_B (workerid, workername, birthdate, itsboss_workerid)
values (468320988, 'Kadyn Parker', to_date('18-02-1984', 'dd-mm-yyyy'), 655611592);
insert into WORKER_B (workerid, workername, birthdate, itsboss_workerid)
values (845532748, 'Ernesto Crane', to_date('21-10-1962', 'dd-mm-yyyy'), 655611592);
insert into WORKER_B (workerid, workername, birthdate, itsboss_workerid)
values (979100171, 'Alma Benson', to_date('16-07-1986', 'dd-mm-yyyy'), 267895569);
insert into WORKER_B (workerid, workername, birthdate, itsboss_workerid)
values (202306184, 'Marie Barton', to_date('20-09-1961', 'dd-mm-yyyy'), 267895569);
insert into WORKER_B (workerid, workername, birthdate, itsboss_workerid)
values (660108450, 'Lilyana Lamb', to_date('06-07-1999', 'dd-mm-yyyy'), 475822438);
insert into WORKER_B (workerid, workername, birthdate, itsboss_workerid)
values (481022444, 'Lewis Stewart', to_date('06-06-1983', 'dd-mm-yyyy'), 475822438);
insert into WORKER_B (workerid, workername, birthdate, itsboss_workerid)
values (41216358, 'Alonso Washington', to_date('28-11-1994', 'dd-mm-yyyy'), 608832283);
insert into WORKER_B (workerid, workername, birthdate, itsboss_workerid)
values (325294143, 'Aiyana Russo', to_date('18-09-1991', 'dd-mm-yyyy'), 608832283);
insert into WORKER_B (workerid, workername, birthdate, itsboss_workerid)
values (803833678, 'Jaylon Mills', to_date('02-05-1971', 'dd-mm-yyyy'), 871947790);
insert into WORKER_B (workerid, workername, birthdate, itsboss_workerid)
values (608473425, 'Drew Love', to_date('12-01-1966', 'dd-mm-yyyy'), 871947790);
insert into WORKER_B (workerid, workername, birthdate, itsboss_workerid)
values (109416098, 'Denisse Ball', to_date('10-07-1982', 'dd-mm-yyyy'), 531238815);
insert into WORKER_B (workerid, workername, birthdate, itsboss_workerid)
values (881549786, 'Lia Michael', to_date('14-04-1973', 'dd-mm-yyyy'), 531238815);
insert into WORKER_B (workerid, workername, birthdate, itsboss_workerid)
values (869554266, 'Esteban Frederick', to_date('11-09-1990', 'dd-mm-yyyy'), 648956315);
insert into WORKER_B (workerid, workername, birthdate, itsboss_workerid)
values (325939163, 'Addyson Farley', to_date('16-11-1961', 'dd-mm-yyyy'), 648956315);
insert into WORKER_B (workerid, workername, birthdate, itsboss_workerid)
values (599701445, 'Peyton Griffith', to_date('22-10-1951', 'dd-mm-yyyy'), 71932811);
insert into WORKER_B (workerid, workername, birthdate, itsboss_workerid)
values (720256910, 'Ronan Holmes', to_date('23-02-1956', 'dd-mm-yyyy'), 71932811);
insert into WORKER_B (workerid, workername, birthdate, itsboss_workerid)
values (42734252, 'Heidy Cruz', to_date('15-03-1986', 'dd-mm-yyyy'), 311466467);
insert into WORKER_B (workerid, workername, birthdate, itsboss_workerid)
values (371691541, 'Miracle Gould', to_date('30-11-1984', 'dd-mm-yyyy'), 311466467);
insert into WORKER_B (workerid, workername, birthdate, itsboss_workerid)
values (42464775, 'Gunnar Barr', to_date('09-06-1997', 'dd-mm-yyyy'), 214019947);
insert into WORKER_B (workerid, workername, birthdate, itsboss_workerid)
values (212036071, 'Chana Meadows', to_date('18-01-1959', 'dd-mm-yyyy'), 214019947);
insert into WORKER_B (workerid, workername, birthdate, itsboss_workerid)
values (558483801, 'Olivia Duncan', to_date('09-08-1973', 'dd-mm-yyyy'), 655611592);
insert into WORKER_B (workerid, workername, birthdate, itsboss_workerid)
values (833381050, 'Kolten Clarke', to_date('27-02-1964', 'dd-mm-yyyy'), 655611592);
insert into WORKER_B (workerid, workername, birthdate, itsboss_workerid)
values (944474945, 'Milagros Hill', to_date('05-01-1994', 'dd-mm-yyyy'), 267895569);
insert into WORKER_B (workerid, workername, birthdate, itsboss_workerid)
values (948300705, 'Libby Dickson', to_date('03-02-1961', 'dd-mm-yyyy'), 267895569);
insert into WORKER_B (workerid, workername, birthdate, itsboss_workerid)
values (572710466, 'Kiley Compton', to_date('25-02-1989', 'dd-mm-yyyy'), 475822438);
insert into WORKER_B (workerid, workername, birthdate, itsboss_workerid)
values (151713573, 'Phoenix Mcdowell', to_date('20-11-1994', 'dd-mm-yyyy'), 475822438);
insert into WORKER_B (workerid, workername, birthdate, itsboss_workerid)
values (36653768, 'Taryn Bridges', to_date('19-08-1968', 'dd-mm-yyyy'), 608832283);
insert into WORKER_B (workerid, workername, birthdate, itsboss_workerid)
values (609838404, 'Elsie Black', to_date('19-11-1971', 'dd-mm-yyyy'), 608832283);
insert into WORKER_B (workerid, workername, birthdate, itsboss_workerid)
values (74246556, 'Bruce Meyer', to_date('18-03-1996', 'dd-mm-yyyy'), 871947790);
insert into WORKER_B (workerid, workername, birthdate, itsboss_workerid)
values (69683187, 'Teagan Fritz', to_date('22-09-1951', 'dd-mm-yyyy'), 871947790);
insert into WORKER_B (workerid, workername, birthdate, itsboss_workerid)
values (772049123, 'Alfredo Cline', to_date('16-06-1994', 'dd-mm-yyyy'), 531238815);
insert into WORKER_B (workerid, workername, birthdate, itsboss_workerid)
values (9637682, 'Alvin Alvarez', to_date('06-02-1994', 'dd-mm-yyyy'), 531238815);
insert into WORKER_B (workerid, workername, birthdate, itsboss_workerid)
values (894659176, 'Cayden Henry', to_date('16-04-1968', 'dd-mm-yyyy'), 648956315);
insert into WORKER_B (workerid, workername, birthdate, itsboss_workerid)
values (694973824, 'Iyana Paul', to_date('15-08-1953', 'dd-mm-yyyy'), 648956315);
insert into WORKER_B (workerid, workername, birthdate, itsboss_workerid)
values (420691439, 'Haiden Shepard', to_date('17-06-1964', 'dd-mm-yyyy'), 71932811);
insert into WORKER_B (workerid, workername, birthdate, itsboss_workerid)
values (93706212, 'Braden Summers', to_date('06-07-1993', 'dd-mm-yyyy'), 71932811);
insert into WORKER_B (workerid, workername, birthdate, itsboss_workerid)
values (227081707, 'James Nichols', to_date('03-02-1960', 'dd-mm-yyyy'), 311466467);
insert into WORKER_B (workerid, workername, birthdate, itsboss_workerid)
values (460241027, 'Damien Hess', to_date('22-12-1968', 'dd-mm-yyyy'), 311466467);
insert into WORKER_B (workerid, workername, birthdate, itsboss_workerid)
values (670519313, 'Joselyn Chan', to_date('22-04-1964', 'dd-mm-yyyy'), 214019947);
insert into WORKER_B (workerid, workername, birthdate, itsboss_workerid)
values (135594200, 'Serena Klein', to_date('14-12-1970', 'dd-mm-yyyy'), 214019947);
insert into WORKER_B (workerid, workername, birthdate, itsboss_workerid)
values (390209868, 'Sammy Bonilla', to_date('04-11-1956', 'dd-mm-yyyy'), 655611592);
insert into WORKER_B (workerid, workername, birthdate, itsboss_workerid)
values (829823516, 'Kiana Jimenez', to_date('24-09-1993', 'dd-mm-yyyy'), 655611592);
insert into WORKER_B (workerid, workername, birthdate, itsboss_workerid)
values (163199704, 'Tamia Mercado', to_date('03-11-1951', 'dd-mm-yyyy'), 267895569);
insert into WORKER_B (workerid, workername, birthdate, itsboss_workerid)
values (47750333, 'Chanel Raymond', to_date('27-04-1973', 'dd-mm-yyyy'), 267895569);
insert into WORKER_B (workerid, workername, birthdate, itsboss_workerid)
values (651653039, 'Ariel Little', to_date('26-04-1955', 'dd-mm-yyyy'), 475822438);
insert into WORKER_B (workerid, workername, birthdate, itsboss_workerid)
values (334482803, 'Nolan Orozco', to_date('18-05-1988', 'dd-mm-yyyy'), 475822438);
insert into WORKER_B (workerid, workername, birthdate, itsboss_workerid)
values (590390539, 'George Maldonado', to_date('05-11-1984', 'dd-mm-yyyy'), 608832283);
insert into WORKER_B (workerid, workername, birthdate, itsboss_workerid)
values (777271072, 'Valery Leach', to_date('17-06-1959', 'dd-mm-yyyy'), 608832283);
insert into WORKER_B (workerid, workername, birthdate, itsboss_workerid)
values (930997789, 'Leonel Joseph', to_date('07-03-1963', 'dd-mm-yyyy'), 871947790);
insert into WORKER_B (workerid, workername, birthdate, itsboss_workerid)
values (264181465, 'Koen Finley', to_date('09-02-1999', 'dd-mm-yyyy'), 871947790);
insert into WORKER_B (workerid, workername, birthdate, itsboss_workerid)
values (904309366, 'Marshall Barton', to_date('24-11-1993', 'dd-mm-yyyy'), 531238815);
insert into WORKER_B (workerid, workername, birthdate, itsboss_workerid)
values (675443623, 'Noelle Butler', to_date('22-10-1999', 'dd-mm-yyyy'), 531238815);
insert into WORKER_B (workerid, workername, birthdate, itsboss_workerid)
values (98795350, 'Saul Leonard', to_date('22-09-1962', 'dd-mm-yyyy'), 648956315);
insert into WORKER_B (workerid, workername, birthdate, itsboss_workerid)
values (291975656, 'Haley Howe', to_date('25-08-1989', 'dd-mm-yyyy'), 648956315);
insert into WORKER_B (workerid, workername, birthdate, itsboss_workerid)
values (659346126, 'Emmy Strong', to_date('09-09-1973', 'dd-mm-yyyy'), 71932811);
insert into WORKER_B (workerid, workername, birthdate, itsboss_workerid)
values (832411481, 'Josie Mcfarland', to_date('19-04-1978', 'dd-mm-yyyy'), 71932811);
insert into WORKER_B (workerid, workername, birthdate, itsboss_workerid)
values (821772864, 'Yazmin Oconnell', to_date('31-10-1963', 'dd-mm-yyyy'), 311466467);
insert into WORKER_B (workerid, workername, birthdate, itsboss_workerid)
values (813408967, 'Zaniyah Reese', to_date('19-01-1997', 'dd-mm-yyyy'), 311466467);
insert into WORKER_B (workerid, workername, birthdate, itsboss_workerid)
values (927420065, 'Declan Wilson', to_date('09-09-1990', 'dd-mm-yyyy'), 214019947);
prompt 100 records loaded
prompt Enabling foreign key constraints for WORKER_B...
alter table WORKER_B enable constraint SYS_C007465;
prompt Enabling triggers for WORKER_B...
alter table WORKER_B enable all triggers;

set feedback on
set define on
prompt Done
