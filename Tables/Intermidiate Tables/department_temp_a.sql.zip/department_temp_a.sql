?��prompt PL/SQL Developer Export Tables for user SYSTEM
prompt Created by Evyatar on יום שני 10 אוגוסט 2020
set feedback off
set define off

prompt Creating DEPARTMENT_TEMP_A...
create table DEPARTMENT_TEMP_A
(
  depid        INTEGER not null,
  healthinstid NUMBER(3),
  depname      VARCHAR2(50) not null,
  cityid       INTEGER not null,
  numberofbeds NUMBER(4)
)
tablespace SYSTEM
  pctfree 10
  pctused 40
  initrans 1
  maxtrans 255
  storage
  (
    initial 64K
    next 1M
    minextents 1
    maxextents unlimited
  );
alter table DEPARTMENT_TEMP_A
  add primary key (DEPID, HEALTHINSTID)
  disable
  novalidate;
alter table DEPARTMENT_TEMP_A
  add foreign key (HEALTHINSTID)
  references HEALTHINSTITUTION (HEALTHINSTID)
  disable
  novalidate;
alter table DEPARTMENT_TEMP_A
  add foreign key (CITYID)
  references CITY (CITYID)
  disable
  novalidate;

prompt Disabling triggers for DEPARTMENT_TEMP_A...
alter table DEPARTMENT_TEMP_A disable all triggers;
prompt Deleting DEPARTMENT_TEMP_A...
delete from DEPARTMENT_TEMP_A;
prompt Loading DEPARTMENT_TEMP_A...
insert into DEPARTMENT_TEMP_A (depid, healthinstid, depname, cityid, numberofbeds)
values (1, 435, 'Admissions', 18, 32);
insert into DEPARTMENT_TEMP_A (depid, healthinstid, depname, cityid, numberofbeds)
values (2, 427, 'Human Resources', 8, 29);
insert into DEPARTMENT_TEMP_A (depid, healthinstid, depname, cityid, numberofbeds)
values (3, 861, 'Pharmacy', 20, 11);
insert into DEPARTMENT_TEMP_A (depid, healthinstid, depname, cityid, numberofbeds)
values (4, 726, 'Nephrology', 15, 21);
insert into DEPARTMENT_TEMP_A (depid, healthinstid, depname, cityid, numberofbeds)
values (5, 758, 'Admissions', 15, 34);
insert into DEPARTMENT_TEMP_A (depid, healthinstid, depname, cityid, numberofbeds)
values (6, 224, 'Critical Care', 19, 23);
insert into DEPARTMENT_TEMP_A (depid, healthinstid, depname, cityid, numberofbeds)
values (7, 42, 'Human Resources', 15, 7);
insert into DEPARTMENT_TEMP_A (depid, healthinstid, depname, cityid, numberofbeds)
values (8, 116, 'Pharmacy', 4, 14);
insert into DEPARTMENT_TEMP_A (depid, healthinstid, depname, cityid, numberofbeds)
values (9, 131, 'General Surgery', 15, 17);
insert into DEPARTMENT_TEMP_A (depid, healthinstid, depname, cityid, numberofbeds)
values (10, 380, 'Pharmacy', 6, 9);
insert into DEPARTMENT_TEMP_A (depid, healthinstid, depname, cityid, numberofbeds)
values (11, 426, 'Oncology', 2, 25);
prompt 11 records loaded
prompt Enabling triggers for DEPARTMENT_TEMP_A...
alter table DEPARTMENT_TEMP_A enable all triggers;

set feedback on
set define on
prompt Done
