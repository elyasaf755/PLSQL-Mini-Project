?��prompt PL/SQL Developer Export Tables for user SYSTEM
prompt Created by Evyatar on יום שני 10 אוגוסט 2020
set feedback off
set define off

prompt Creating CLERK_B...
create table CLERK_B
(
  clerkid   NUMBER(9) not null,
  rating    NUMBER(2) not null,
  hireyear  NUMBER(4) not null,
  bossid    NUMBER(9) not null,
  salary    FLOAT not null,
  clerkname VARCHAR2(50) not null,
  areaid    NUMBER(3)
)
tablespace SYSTEM
  pctfree 10
  pctused 40
  initrans 1
  maxtrans 255
  storage
  (
    initial 64K
    next 1M
    minextents 1
    maxextents unlimited
  );
alter table CLERK_B
  add primary key (CLERKID)
  using index 
  tablespace SYSTEM
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 64K
    next 1M
    minextents 1
    maxextents unlimited
  );

prompt Disabling triggers for CLERK_B...
alter table CLERK_B disable all triggers;
prompt Deleting CLERK_B...
delete from CLERK_B;
prompt Loading CLERK_B...
insert into CLERK_B (clerkid, rating, hireyear, bossid, salary, clerkname, areaid)
values (985608353, 76, 2019, 728586501, 6259, 'Aaron Robbins', 6);
insert into CLERK_B (clerkid, rating, hireyear, bossid, salary, clerkname, areaid)
values (216673752, 60, 2010, 611912795, 3588, 'Regina Hicks', 9);
insert into CLERK_B (clerkid, rating, hireyear, bossid, salary, clerkname, areaid)
values (616839114, 84, 2015, 82463116, 3575, 'Vivian Rhodes', 8);
insert into CLERK_B (clerkid, rating, hireyear, bossid, salary, clerkname, areaid)
values (56423791, 30, 2008, 13621976, 6554, 'Vicente Robles', 17);
insert into CLERK_B (clerkid, rating, hireyear, bossid, salary, clerkname, areaid)
values (715357972, 32, 2012, 178536762, 7322, 'Riley Vang', 8);
insert into CLERK_B (clerkid, rating, hireyear, bossid, salary, clerkname, areaid)
values (769944696, 57, 2011, 835856510, 5472, 'Ashton Maldonado', 4);
insert into CLERK_B (clerkid, rating, hireyear, bossid, salary, clerkname, areaid)
values (106947896, 33, 2014, 951674376, 6255, 'Erin Raymond', 12);
insert into CLERK_B (clerkid, rating, hireyear, bossid, salary, clerkname, areaid)
values (701642916, 35, 2007, 192952482, 4323, 'Emma Terrell', 17);
insert into CLERK_B (clerkid, rating, hireyear, bossid, salary, clerkname, areaid)
values (230298738, 74, 2006, 747768908, 8522, 'Mallory Burnett', 10);
insert into CLERK_B (clerkid, rating, hireyear, bossid, salary, clerkname, areaid)
values (536047901, 55, 2007, 359153629, 4907, 'Alice Rojas', 2);
insert into CLERK_B (clerkid, rating, hireyear, bossid, salary, clerkname, areaid)
values (688678649, 60, 2011, 754058532, 8450, 'Daniela Bradshaw', 14);
insert into CLERK_B (clerkid, rating, hireyear, bossid, salary, clerkname, areaid)
values (45172409, 70, 2013, 116713838, 8161, 'Carlos Crane', 15);
insert into CLERK_B (clerkid, rating, hireyear, bossid, salary, clerkname, areaid)
values (261999697, 29, 2018, 351427476, 3376, 'Marisa Blackburn', 15);
insert into CLERK_B (clerkid, rating, hireyear, bossid, salary, clerkname, areaid)
values (533844976, 52, 2008, 871371068, 5303, 'Lacey Wright', 18);
insert into CLERK_B (clerkid, rating, hireyear, bossid, salary, clerkname, areaid)
values (439153011, 76, 2014, 636986649, 3182, 'Aliana Munoz', 10);
insert into CLERK_B (clerkid, rating, hireyear, bossid, salary, clerkname, areaid)
values (742868808, 33, 2017, 644517151, 6253, 'Juliet Day', 15);
insert into CLERK_B (clerkid, rating, hireyear, bossid, salary, clerkname, areaid)
values (89160074, 45, 2015, 129040934, 8855, 'Isabell Brock', 5);
insert into CLERK_B (clerkid, rating, hireyear, bossid, salary, clerkname, areaid)
values (908621892, 80, 2011, 338392591, 7171, 'Janiya James', 16);
insert into CLERK_B (clerkid, rating, hireyear, bossid, salary, clerkname, areaid)
values (727320134, 42, 2010, 730255019, 4750, 'Brittany Nielsen', 2);
insert into CLERK_B (clerkid, rating, hireyear, bossid, salary, clerkname, areaid)
values (889893500, 60, 2019, 169525232, 4145, 'Dustin Terrell', 9);
insert into CLERK_B (clerkid, rating, hireyear, bossid, salary, clerkname, areaid)
values (97748603, 86, 2017, 503531033, 5199, 'Yasmin Steele', 15);
insert into CLERK_B (clerkid, rating, hireyear, bossid, salary, clerkname, areaid)
values (621893021, 70, 2020, 536832758, 8996, 'Jacey Stephens', 11);
insert into CLERK_B (clerkid, rating, hireyear, bossid, salary, clerkname, areaid)
values (50870763, 77, 2014, 881497689, 4197, 'Judith Kramer', 6);
insert into CLERK_B (clerkid, rating, hireyear, bossid, salary, clerkname, areaid)
values (231962714, 48, 2016, 888871238, 7656, 'Aliana Warren', 11);
insert into CLERK_B (clerkid, rating, hireyear, bossid, salary, clerkname, areaid)
values (3266076, 36, 2017, 288561006, 4629, 'Jerimiah Richardson', 2);
insert into CLERK_B (clerkid, rating, hireyear, bossid, salary, clerkname, areaid)
values (242059824, 30, 2006, 653257004, 9931, 'Kimora Bruce', 17);
insert into CLERK_B (clerkid, rating, hireyear, bossid, salary, clerkname, areaid)
values (986515397, 90, 2016, 561974294, 3060, 'Matilda Mills', 4);
insert into CLERK_B (clerkid, rating, hireyear, bossid, salary, clerkname, areaid)
values (640574572, 69, 2014, 683069173, 5642, 'Jon Hanna', 3);
insert into CLERK_B (clerkid, rating, hireyear, bossid, salary, clerkname, areaid)
values (381434132, 84, 2011, 632061896, 8346, 'Jadiel Nichols', 15);
insert into CLERK_B (clerkid, rating, hireyear, bossid, salary, clerkname, areaid)
values (58713028, 76, 2011, 282805064, 5877, 'Aliza Johnston', 8);
insert into CLERK_B (clerkid, rating, hireyear, bossid, salary, clerkname, areaid)
values (413518592, 64, 2007, 210526370, 3139, 'Kymani Atkins', 16);
insert into CLERK_B (clerkid, rating, hireyear, bossid, salary, clerkname, areaid)
values (89541503, 72, 2010, 35100364, 9279, 'Jayda Booker', 15);
insert into CLERK_B (clerkid, rating, hireyear, bossid, salary, clerkname, areaid)
values (675975458, 72, 2015, 386211345, 6900, 'Jamiya Cox', 7);
insert into CLERK_B (clerkid, rating, hireyear, bossid, salary, clerkname, areaid)
values (953496147, 39, 2016, 53215943, 8060, 'Jonah Mckay', 13);
insert into CLERK_B (clerkid, rating, hireyear, bossid, salary, clerkname, areaid)
values (763143179, 43, 2008, 571651713, 7809, 'Campbell Manning', 15);
insert into CLERK_B (clerkid, rating, hireyear, bossid, salary, clerkname, areaid)
values (640330926, 95, 2014, 887279443, 7253, 'Ivy Sutton', 9);
insert into CLERK_B (clerkid, rating, hireyear, bossid, salary, clerkname, areaid)
values (219641402, 36, 2009, 348994280, 9481, 'Zaniyah Dominguez', 20);
insert into CLERK_B (clerkid, rating, hireyear, bossid, salary, clerkname, areaid)
values (797503856, 99, 2007, 596091330, 6734, 'Fernanda Stanton', 8);
insert into CLERK_B (clerkid, rating, hireyear, bossid, salary, clerkname, areaid)
values (714723836, 77, 2008, 654058322, 7181, 'Maddison Bright', 8);
insert into CLERK_B (clerkid, rating, hireyear, bossid, salary, clerkname, areaid)
values (962919031, 42, 2007, 467458799, 6323, 'Annie Lozano', 5);
insert into CLERK_B (clerkid, rating, hireyear, bossid, salary, clerkname, areaid)
values (804709291, 97, 2012, 482185653, 8052, 'Dominique Pollard', 13);
insert into CLERK_B (clerkid, rating, hireyear, bossid, salary, clerkname, areaid)
values (177769483, 69, 2016, 679505128, 9664, 'Brynlee Whitaker', 14);
insert into CLERK_B (clerkid, rating, hireyear, bossid, salary, clerkname, areaid)
values (901257019, 86, 2020, 189682273, 6748, 'Aedan Ramos', 8);
insert into CLERK_B (clerkid, rating, hireyear, bossid, salary, clerkname, areaid)
values (857760109, 81, 2015, 747715581, 3646, 'Kiley Gillespie', 4);
insert into CLERK_B (clerkid, rating, hireyear, bossid, salary, clerkname, areaid)
values (744958679, 36, 2006, 290166400, 8599, 'Maxwell Huffman', 3);
insert into CLERK_B (clerkid, rating, hireyear, bossid, salary, clerkname, areaid)
values (563871338, 47, 2018, 815005240, 9063, 'Sidney Mcdowell', 12);
insert into CLERK_B (clerkid, rating, hireyear, bossid, salary, clerkname, areaid)
values (566015263, 83, 2011, 853047389, 6153, 'Abraham Waller', 7);
insert into CLERK_B (clerkid, rating, hireyear, bossid, salary, clerkname, areaid)
values (278216922, 96, 2007, 975381784, 5014, 'Jonas Ayala', 6);
insert into CLERK_B (clerkid, rating, hireyear, bossid, salary, clerkname, areaid)
values (479478250, 40, 2008, 7375540, 3072, 'Yoselin Allen', 1);
insert into CLERK_B (clerkid, rating, hireyear, bossid, salary, clerkname, areaid)
values (340526675, 64, 2011, 866019935, 8808, 'Darius Dunn', 19);
insert into CLERK_B (clerkid, rating, hireyear, bossid, salary, clerkname, areaid)
values (578494275, 65, 2019, 253823707, 6361, 'Osvaldo Sparks', 16);
insert into CLERK_B (clerkid, rating, hireyear, bossid, salary, clerkname, areaid)
values (470721569, 27, 2010, 578436469, 6112, 'Adrianna Norman', 14);
insert into CLERK_B (clerkid, rating, hireyear, bossid, salary, clerkname, areaid)
values (625260228, 80, 2015, 63966459, 5552, 'Celia Cowan', 4);
insert into CLERK_B (clerkid, rating, hireyear, bossid, salary, clerkname, areaid)
values (602574296, 77, 2008, 775632110, 8881, 'Kyra Howell', 15);
insert into CLERK_B (clerkid, rating, hireyear, bossid, salary, clerkname, areaid)
values (141169429, 55, 2012, 849549339, 8108, 'Aden Nash', 12);
insert into CLERK_B (clerkid, rating, hireyear, bossid, salary, clerkname, areaid)
values (657042160, 96, 2011, 595482475, 8155, 'Haven Dominguez', 7);
insert into CLERK_B (clerkid, rating, hireyear, bossid, salary, clerkname, areaid)
values (111959269, 41, 2014, 196953292, 3323, 'Micah Singh', 6);
insert into CLERK_B (clerkid, rating, hireyear, bossid, salary, clerkname, areaid)
values (116034120, 77, 2007, 655805639, 5681, 'Mariah Hampton', 11);
insert into CLERK_B (clerkid, rating, hireyear, bossid, salary, clerkname, areaid)
values (568167932, 81, 2006, 577025006, 5638, 'Jeremy Lutz', 19);
insert into CLERK_B (clerkid, rating, hireyear, bossid, salary, clerkname, areaid)
values (775027789, 74, 2007, 675210639, 7284, 'Jaxson Robertson', 2);
insert into CLERK_B (clerkid, rating, hireyear, bossid, salary, clerkname, areaid)
values (533397741, 64, 2011, 919044101, 6241, 'Marquise Horne', 11);
insert into CLERK_B (clerkid, rating, hireyear, bossid, salary, clerkname, areaid)
values (462438254, 93, 2013, 462929801, 6205, 'Autumn Joseph', 8);
insert into CLERK_B (clerkid, rating, hireyear, bossid, salary, clerkname, areaid)
values (412908680, 66, 2018, 150609347, 9603, 'Melina Morales', 12);
insert into CLERK_B (clerkid, rating, hireyear, bossid, salary, clerkname, areaid)
values (999775205, 59, 2008, 510596727, 8121, 'Jaelyn Baxter', 16);
insert into CLERK_B (clerkid, rating, hireyear, bossid, salary, clerkname, areaid)
values (377845907, 40, 2014, 71840651, 3885, 'Luz Mcintyre', 14);
insert into CLERK_B (clerkid, rating, hireyear, bossid, salary, clerkname, areaid)
values (358888404, 42, 2017, 544243390, 8564, 'Rigoberto Stafford', 9);
insert into CLERK_B (clerkid, rating, hireyear, bossid, salary, clerkname, areaid)
values (508028509, 43, 2015, 962334883, 8019, 'Lila Shields', 4);
insert into CLERK_B (clerkid, rating, hireyear, bossid, salary, clerkname, areaid)
values (935116002, 90, 2011, 248278494, 6271, 'Brooke Mayo', 15);
insert into CLERK_B (clerkid, rating, hireyear, bossid, salary, clerkname, areaid)
values (826448233, 45, 2010, 332180403, 5020, 'Karly Cooke', 6);
insert into CLERK_B (clerkid, rating, hireyear, bossid, salary, clerkname, areaid)
values (62588564, 46, 2019, 861989291, 9752, 'Joanna Nichols', 17);
insert into CLERK_B (clerkid, rating, hireyear, bossid, salary, clerkname, areaid)
values (37773505, 60, 2017, 340695319, 5345, 'Elizabeth Booth', 18);
insert into CLERK_B (clerkid, rating, hireyear, bossid, salary, clerkname, areaid)
values (224334980, 84, 2020, 412463694, 4504, 'John Mcmahon', 17);
insert into CLERK_B (clerkid, rating, hireyear, bossid, salary, clerkname, areaid)
values (725061585, 62, 2014, 520949281, 8672, 'Roman Martin', 10);
insert into CLERK_B (clerkid, rating, hireyear, bossid, salary, clerkname, areaid)
values (380575697, 49, 2016, 297954194, 5738, 'Dakota Lindsey', 8);
insert into CLERK_B (clerkid, rating, hireyear, bossid, salary, clerkname, areaid)
values (443090391, 39, 2017, 588792612, 9339, 'Donald Romero', 13);
insert into CLERK_B (clerkid, rating, hireyear, bossid, salary, clerkname, areaid)
values (102056465, 25, 2006, 759442973, 6564, 'Seth Mercado', 17);
insert into CLERK_B (clerkid, rating, hireyear, bossid, salary, clerkname, areaid)
values (132751178, 86, 2016, 513758036, 4058, 'Maxwell Calderon', 3);
insert into CLERK_B (clerkid, rating, hireyear, bossid, salary, clerkname, areaid)
values (459089952, 90, 2014, 811969949, 4276, 'Amelia Mills', 12);
insert into CLERK_B (clerkid, rating, hireyear, bossid, salary, clerkname, areaid)
values (352326915, 35, 2011, 65786836, 7722, 'Stacy Savage', 16);
insert into CLERK_B (clerkid, rating, hireyear, bossid, salary, clerkname, areaid)
values (398251227, 31, 2011, 111324755, 5795, 'Lola Vaughan', 2);
insert into CLERK_B (clerkid, rating, hireyear, bossid, salary, clerkname, areaid)
values (198620173, 61, 2007, 441864276, 5570, 'Autumn Oneal', 16);
insert into CLERK_B (clerkid, rating, hireyear, bossid, salary, clerkname, areaid)
values (468433995, 85, 2010, 422387569, 9366, 'Jacquelyn Alvarez', 20);
insert into CLERK_B (clerkid, rating, hireyear, bossid, salary, clerkname, areaid)
values (169418156, 42, 2015, 920606814, 4919, 'Maddison Francis', 16);
insert into CLERK_B (clerkid, rating, hireyear, bossid, salary, clerkname, areaid)
values (48780608, 55, 2016, 623443858, 5001, 'Lukas Powers', 17);
insert into CLERK_B (clerkid, rating, hireyear, bossid, salary, clerkname, areaid)
values (245602759, 88, 2008, 153201103, 7808, 'Landon Moody', 3);
insert into CLERK_B (clerkid, rating, hireyear, bossid, salary, clerkname, areaid)
values (865215977, 29, 2014, 247598093, 3237, 'Judah Solis', 8);
insert into CLERK_B (clerkid, rating, hireyear, bossid, salary, clerkname, areaid)
values (613154169, 75, 2009, 487998812, 3505, 'Carina Todd', 2);
insert into CLERK_B (clerkid, rating, hireyear, bossid, salary, clerkname, areaid)
values (710604897, 74, 2007, 969419112, 8100, 'Trinity Cochran', 12);
insert into CLERK_B (clerkid, rating, hireyear, bossid, salary, clerkname, areaid)
values (903631899, 79, 2008, 764532349, 3065, 'Terrence Owens', 4);
insert into CLERK_B (clerkid, rating, hireyear, bossid, salary, clerkname, areaid)
values (163989772, 97, 2007, 162100909, 9168, 'Clinton Ochoa', 14);
insert into CLERK_B (clerkid, rating, hireyear, bossid, salary, clerkname, areaid)
values (424689583, 88, 2012, 963939156, 7690, 'Jaylee Carpenter', 10);
insert into CLERK_B (clerkid, rating, hireyear, bossid, salary, clerkname, areaid)
values (251645553, 48, 2016, 848997346, 9457, 'Kyan Fuentes', 11);
insert into CLERK_B (clerkid, rating, hireyear, bossid, salary, clerkname, areaid)
values (520881414, 85, 2020, 596236364, 6804, 'Brodie Murphy', 14);
insert into CLERK_B (clerkid, rating, hireyear, bossid, salary, clerkname, areaid)
values (740053775, 58, 2015, 376869355, 5188, 'Mike Pham', 18);
insert into CLERK_B (clerkid, rating, hireyear, bossid, salary, clerkname, areaid)
values (970992503, 56, 2006, 932521110, 5899, 'Iliana Zuniga', 20);
insert into CLERK_B (clerkid, rating, hireyear, bossid, salary, clerkname, areaid)
values (552470268, 89, 2018, 168148868, 5387, 'Maverick Klein', 8);
insert into CLERK_B (clerkid, rating, hireyear, bossid, salary, clerkname, areaid)
values (283304585, 42, 2011, 467598885, 4620, 'Brianna Munoz', 3);
insert into CLERK_B (clerkid, rating, hireyear, bossid, salary, clerkname, areaid)
values (315265026, 92, 2007, 964843484, 8858, 'Aryana Mcintyre', 11);
insert into CLERK_B (clerkid, rating, hireyear, bossid, salary, clerkname, areaid)
values (83705991, 62, 2008, 812109096, 4153, 'Kira Pope', 18);
insert into CLERK_B (clerkid, rating, hireyear, bossid, salary, clerkname, areaid)
values (632486887, 37, 2011, 484427206, 6570, 'Mathew Schneider', 7);
prompt 100 records loaded
prompt Enabling triggers for CLERK_B...
alter table CLERK_B enable all triggers;

set feedback on
set define on
prompt Done
