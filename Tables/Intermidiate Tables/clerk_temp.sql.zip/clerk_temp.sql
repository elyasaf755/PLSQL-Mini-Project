?��prompt PL/SQL Developer Export Tables for user SYSTEM
prompt Created by Evyatar on יום שני 10 אוגוסט 2020
set feedback off
set define off

prompt Creating CLERK_TEMP...
create table CLERK_TEMP
(
  clerkid   INTEGER,
  clerkname VARCHAR2(32),
  bossid    INTEGER,
  areaid    INTEGER,
  salary    FLOAT,
  hireyear  INTEGER,
  rating    INTEGER
)
tablespace SYSTEM
  pctfree 10
  pctused 40
  initrans 1
  maxtrans 255
  storage
  (
    initial 64K
    next 1M
    minextents 1
    maxextents unlimited
  );

prompt Disabling triggers for CLERK_TEMP...
alter table CLERK_TEMP disable all triggers;
prompt Deleting CLERK_TEMP...
delete from CLERK_TEMP;
prompt Loading CLERK_TEMP...
insert into CLERK_TEMP (clerkid, clerkname, bossid, areaid, salary, hireyear, rating)
values (1, 'Emily Farrow', 20006, 21, 7293, 2008, 6);
insert into CLERK_TEMP (clerkid, clerkname, bossid, areaid, salary, hireyear, rating)
values (2, 'Arnold Singletary', 20009, 22, 7866, 2018, 6);
insert into CLERK_TEMP (clerkid, clerkname, bossid, areaid, salary, hireyear, rating)
values (3, 'Rose Mraz', 20001, 23, 11702, 2008, 6);
insert into CLERK_TEMP (clerkid, clerkname, bossid, areaid, salary, hireyear, rating)
values (4, 'Melanie Michael', 20001, 24, 9295, 2018, 10);
insert into CLERK_TEMP (clerkid, clerkname, bossid, areaid, salary, hireyear, rating)
values (5, 'Bobbi Loveless', 20001, 25, 10445, 2011, 6);
insert into CLERK_TEMP (clerkid, clerkname, bossid, areaid, salary, hireyear, rating)
values (6, 'Ernie Parm', 20004, 26, 7531, 2012, 4);
insert into CLERK_TEMP (clerkid, clerkname, bossid, areaid, salary, hireyear, rating)
values (7, 'Spike Stiles', 20008, 27, 8295, 2018, 7);
insert into CLERK_TEMP (clerkid, clerkname, bossid, areaid, salary, hireyear, rating)
values (8, 'Danni Santana', 20003, 28, 5737, 2012, 4);
insert into CLERK_TEMP (clerkid, clerkname, bossid, areaid, salary, hireyear, rating)
values (9, 'Billy Schwimmer', 20005, 29, 9848, 2011, 5);
insert into CLERK_TEMP (clerkid, clerkname, bossid, areaid, salary, hireyear, rating)
values (10, 'Daryle Downie', 20010, 30, 5766, 2015, 4);
insert into CLERK_TEMP (clerkid, clerkname, bossid, areaid, salary, hireyear, rating)
values (985608353, 'Aaron Robbins', 728586501, 65, 6259, 2019, 76);
insert into CLERK_TEMP (clerkid, clerkname, bossid, areaid, salary, hireyear, rating)
values (216673752, 'Regina Hicks', 611912795, 11, 3588, 2010, 60);
insert into CLERK_TEMP (clerkid, clerkname, bossid, areaid, salary, hireyear, rating)
values (616839114, 'Vivian Rhodes', 82463116, 90, 3575, 2015, 84);
insert into CLERK_TEMP (clerkid, clerkname, bossid, areaid, salary, hireyear, rating)
values (56423791, 'Vicente Robles', 13621976, 70, 6554, 2008, 30);
insert into CLERK_TEMP (clerkid, clerkname, bossid, areaid, salary, hireyear, rating)
values (715357972, 'Riley Vang', 178536762, 62, 7322, 2012, 32);
insert into CLERK_TEMP (clerkid, clerkname, bossid, areaid, salary, hireyear, rating)
values (769944696, 'Ashton Maldonado', 835856510, 41, 5472, 2011, 57);
insert into CLERK_TEMP (clerkid, clerkname, bossid, areaid, salary, hireyear, rating)
values (106947896, 'Erin Raymond', 951674376, 14, 6255, 2014, 33);
insert into CLERK_TEMP (clerkid, clerkname, bossid, areaid, salary, hireyear, rating)
values (701642916, 'Emma Terrell', 192952482, 66, 4323, 2007, 35);
insert into CLERK_TEMP (clerkid, clerkname, bossid, areaid, salary, hireyear, rating)
values (230298738, 'Mallory Burnett', 747768908, 21, 8522, 2006, 74);
insert into CLERK_TEMP (clerkid, clerkname, bossid, areaid, salary, hireyear, rating)
values (536047901, 'Alice Rojas', 359153629, 52, 4907, 2007, 55);
insert into CLERK_TEMP (clerkid, clerkname, bossid, areaid, salary, hireyear, rating)
values (688678649, 'Daniela Bradshaw', 754058532, 1, 8450, 2011, 60);
insert into CLERK_TEMP (clerkid, clerkname, bossid, areaid, salary, hireyear, rating)
values (45172409, 'Carlos Crane', 116713838, 20, 8161, 2013, 70);
insert into CLERK_TEMP (clerkid, clerkname, bossid, areaid, salary, hireyear, rating)
values (261999697, 'Marisa Blackburn', 351427476, 73, 3376, 2018, 29);
insert into CLERK_TEMP (clerkid, clerkname, bossid, areaid, salary, hireyear, rating)
values (533844976, 'Lacey Wright', 871371068, 93, 5303, 2008, 52);
insert into CLERK_TEMP (clerkid, clerkname, bossid, areaid, salary, hireyear, rating)
values (439153011, 'Aliana Munoz', 636986649, 82, 3182, 2014, 76);
insert into CLERK_TEMP (clerkid, clerkname, bossid, areaid, salary, hireyear, rating)
values (742868808, 'Juliet Day', 644517151, 84, 6253, 2017, 33);
insert into CLERK_TEMP (clerkid, clerkname, bossid, areaid, salary, hireyear, rating)
values (89160074, 'Isabell Brock', 129040934, 32, 8855, 2015, 45);
insert into CLERK_TEMP (clerkid, clerkname, bossid, areaid, salary, hireyear, rating)
values (908621892, 'Janiya James', 338392591, 89, 7171, 2011, 80);
insert into CLERK_TEMP (clerkid, clerkname, bossid, areaid, salary, hireyear, rating)
values (727320134, 'Brittany Nielsen', 730255019, 60, 4750, 2010, 42);
insert into CLERK_TEMP (clerkid, clerkname, bossid, areaid, salary, hireyear, rating)
values (889893500, 'Dustin Terrell', 169525232, 87, 4145, 2019, 60);
insert into CLERK_TEMP (clerkid, clerkname, bossid, areaid, salary, hireyear, rating)
values (97748603, 'Yasmin Steele', 503531033, 16, 5199, 2017, 86);
insert into CLERK_TEMP (clerkid, clerkname, bossid, areaid, salary, hireyear, rating)
values (621893021, 'Jacey Stephens', 536832758, 7, 8996, 2020, 70);
insert into CLERK_TEMP (clerkid, clerkname, bossid, areaid, salary, hireyear, rating)
values (50870763, 'Judith Kramer', 881497689, 5, 4197, 2014, 77);
insert into CLERK_TEMP (clerkid, clerkname, bossid, areaid, salary, hireyear, rating)
values (231962714, 'Aliana Warren', 888871238, 23, 7656, 2016, 48);
insert into CLERK_TEMP (clerkid, clerkname, bossid, areaid, salary, hireyear, rating)
values (3266076, 'Jerimiah Richardson', 288561006, 58, 4629, 2017, 36);
insert into CLERK_TEMP (clerkid, clerkname, bossid, areaid, salary, hireyear, rating)
values (242059824, 'Kimora Bruce', 653257004, 10, 9931, 2006, 30);
insert into CLERK_TEMP (clerkid, clerkname, bossid, areaid, salary, hireyear, rating)
values (986515397, 'Matilda Mills', 561974294, 51, 3060, 2016, 90);
insert into CLERK_TEMP (clerkid, clerkname, bossid, areaid, salary, hireyear, rating)
values (640574572, 'Jon Hanna', 683069173, 56, 5642, 2014, 69);
insert into CLERK_TEMP (clerkid, clerkname, bossid, areaid, salary, hireyear, rating)
values (381434132, 'Jadiel Nichols', 632061896, 43, 8346, 2011, 84);
insert into CLERK_TEMP (clerkid, clerkname, bossid, areaid, salary, hireyear, rating)
values (58713028, 'Aliza Johnston', 282805064, 8, 5877, 2011, 76);
insert into CLERK_TEMP (clerkid, clerkname, bossid, areaid, salary, hireyear, rating)
values (413518592, 'Kymani Atkins', 210526370, 9, 3139, 2007, 64);
insert into CLERK_TEMP (clerkid, clerkname, bossid, areaid, salary, hireyear, rating)
values (89541503, 'Jayda Booker', 35100364, 85, 9279, 2010, 72);
insert into CLERK_TEMP (clerkid, clerkname, bossid, areaid, salary, hireyear, rating)
values (675975458, 'Jamiya Cox', 386211345, 38, 6900, 2015, 72);
insert into CLERK_TEMP (clerkid, clerkname, bossid, areaid, salary, hireyear, rating)
values (953496147, 'Jonah Mckay', 53215943, 76, 8060, 2016, 39);
insert into CLERK_TEMP (clerkid, clerkname, bossid, areaid, salary, hireyear, rating)
values (763143179, 'Campbell Manning', 571651713, 79, 7809, 2008, 43);
insert into CLERK_TEMP (clerkid, clerkname, bossid, areaid, salary, hireyear, rating)
values (640330926, 'Ivy Sutton', 887279443, 49, 7253, 2014, 95);
insert into CLERK_TEMP (clerkid, clerkname, bossid, areaid, salary, hireyear, rating)
values (219641402, 'Zaniyah Dominguez', 348994280, 55, 9481, 2009, 36);
insert into CLERK_TEMP (clerkid, clerkname, bossid, areaid, salary, hireyear, rating)
values (797503856, 'Fernanda Stanton', 596091330, 57, 6734, 2007, 99);
insert into CLERK_TEMP (clerkid, clerkname, bossid, areaid, salary, hireyear, rating)
values (714723836, 'Maddison Bright', 654058322, 2, 7181, 2008, 77);
insert into CLERK_TEMP (clerkid, clerkname, bossid, areaid, salary, hireyear, rating)
values (962919031, 'Annie Lozano', 467458799, 83, 6323, 2007, 42);
insert into CLERK_TEMP (clerkid, clerkname, bossid, areaid, salary, hireyear, rating)
values (804709291, 'Dominique Pollard', 482185653, 75, 8052, 2012, 97);
insert into CLERK_TEMP (clerkid, clerkname, bossid, areaid, salary, hireyear, rating)
values (177769483, 'Brynlee Whitaker', 679505128, 54, 9664, 2016, 69);
insert into CLERK_TEMP (clerkid, clerkname, bossid, areaid, salary, hireyear, rating)
values (901257019, 'Aedan Ramos', 189682273, 69, 6748, 2020, 86);
insert into CLERK_TEMP (clerkid, clerkname, bossid, areaid, salary, hireyear, rating)
values (857760109, 'Kiley Gillespie', 747715581, 48, 3646, 2015, 81);
insert into CLERK_TEMP (clerkid, clerkname, bossid, areaid, salary, hireyear, rating)
values (744958679, 'Maxwell Huffman', 290166400, 50, 8599, 2006, 36);
insert into CLERK_TEMP (clerkid, clerkname, bossid, areaid, salary, hireyear, rating)
values (563871338, 'Sidney Mcdowell', 815005240, 81, 9063, 2018, 47);
insert into CLERK_TEMP (clerkid, clerkname, bossid, areaid, salary, hireyear, rating)
values (566015263, 'Abraham Waller', 853047389, 68, 6153, 2011, 83);
insert into CLERK_TEMP (clerkid, clerkname, bossid, areaid, salary, hireyear, rating)
values (278216922, 'Jonas Ayala', 975381784, 71, 5014, 2007, 96);
insert into CLERK_TEMP (clerkid, clerkname, bossid, areaid, salary, hireyear, rating)
values (479478250, 'Yoselin Allen', 7375540, 96, 3072, 2008, 40);
insert into CLERK_TEMP (clerkid, clerkname, bossid, areaid, salary, hireyear, rating)
values (340526675, 'Darius Dunn', 866019935, 6, 8808, 2011, 64);
insert into CLERK_TEMP (clerkid, clerkname, bossid, areaid, salary, hireyear, rating)
values (578494275, 'Osvaldo Sparks', 253823707, 97, 6361, 2019, 65);
insert into CLERK_TEMP (clerkid, clerkname, bossid, areaid, salary, hireyear, rating)
values (470721569, 'Adrianna Norman', 578436469, 86, 6112, 2010, 27);
insert into CLERK_TEMP (clerkid, clerkname, bossid, areaid, salary, hireyear, rating)
values (625260228, 'Celia Cowan', 63966459, 25, 5552, 2015, 80);
insert into CLERK_TEMP (clerkid, clerkname, bossid, areaid, salary, hireyear, rating)
values (602574296, 'Kyra Howell', 775632110, 22, 8881, 2008, 77);
insert into CLERK_TEMP (clerkid, clerkname, bossid, areaid, salary, hireyear, rating)
values (141169429, 'Aden Nash', 849549339, 78, 8108, 2012, 55);
insert into CLERK_TEMP (clerkid, clerkname, bossid, areaid, salary, hireyear, rating)
values (657042160, 'Haven Dominguez', 595482475, 26, 8155, 2011, 96);
insert into CLERK_TEMP (clerkid, clerkname, bossid, areaid, salary, hireyear, rating)
values (111959269, 'Micah Singh', 196953292, 31, 3323, 2014, 41);
insert into CLERK_TEMP (clerkid, clerkname, bossid, areaid, salary, hireyear, rating)
values (116034120, 'Mariah Hampton', 655805639, 88, 5681, 2007, 77);
insert into CLERK_TEMP (clerkid, clerkname, bossid, areaid, salary, hireyear, rating)
values (568167932, 'Jeremy Lutz', 577025006, 29, 5638, 2006, 81);
insert into CLERK_TEMP (clerkid, clerkname, bossid, areaid, salary, hireyear, rating)
values (775027789, 'Jaxson Robertson', 675210639, 45, 7284, 2007, 74);
insert into CLERK_TEMP (clerkid, clerkname, bossid, areaid, salary, hireyear, rating)
values (533397741, 'Marquise Horne', 919044101, 36, 6241, 2011, 64);
insert into CLERK_TEMP (clerkid, clerkname, bossid, areaid, salary, hireyear, rating)
values (462438254, 'Autumn Joseph', 462929801, 19, 6205, 2013, 93);
insert into CLERK_TEMP (clerkid, clerkname, bossid, areaid, salary, hireyear, rating)
values (412908680, 'Melina Morales', 150609347, 12, 9603, 2018, 66);
insert into CLERK_TEMP (clerkid, clerkname, bossid, areaid, salary, hireyear, rating)
values (999775205, 'Jaelyn Baxter', 510596727, 35, 8121, 2008, 59);
insert into CLERK_TEMP (clerkid, clerkname, bossid, areaid, salary, hireyear, rating)
values (377845907, 'Luz Mcintyre', 71840651, 4, 3885, 2014, 40);
insert into CLERK_TEMP (clerkid, clerkname, bossid, areaid, salary, hireyear, rating)
values (358888404, 'Rigoberto Stafford', 544243390, 39, 8564, 2017, 42);
insert into CLERK_TEMP (clerkid, clerkname, bossid, areaid, salary, hireyear, rating)
values (508028509, 'Lila Shields', 962334883, 17, 8019, 2015, 43);
insert into CLERK_TEMP (clerkid, clerkname, bossid, areaid, salary, hireyear, rating)
values (935116002, 'Brooke Mayo', 248278494, 74, 6271, 2011, 90);
insert into CLERK_TEMP (clerkid, clerkname, bossid, areaid, salary, hireyear, rating)
values (826448233, 'Karly Cooke', 332180403, 67, 5020, 2010, 45);
insert into CLERK_TEMP (clerkid, clerkname, bossid, areaid, salary, hireyear, rating)
values (62588564, 'Joanna Nichols', 861989291, 34, 9752, 2019, 46);
insert into CLERK_TEMP (clerkid, clerkname, bossid, areaid, salary, hireyear, rating)
values (37773505, 'Elizabeth Booth', 340695319, 80, 5345, 2017, 60);
insert into CLERK_TEMP (clerkid, clerkname, bossid, areaid, salary, hireyear, rating)
values (224334980, 'John Mcmahon', 412463694, 13, 4504, 2020, 84);
insert into CLERK_TEMP (clerkid, clerkname, bossid, areaid, salary, hireyear, rating)
values (725061585, 'Roman Martin', 520949281, 42, 8672, 2014, 62);
insert into CLERK_TEMP (clerkid, clerkname, bossid, areaid, salary, hireyear, rating)
values (380575697, 'Dakota Lindsey', 297954194, 24, 5738, 2016, 49);
insert into CLERK_TEMP (clerkid, clerkname, bossid, areaid, salary, hireyear, rating)
values (443090391, 'Donald Romero', 588792612, 92, 9339, 2017, 39);
insert into CLERK_TEMP (clerkid, clerkname, bossid, areaid, salary, hireyear, rating)
values (102056465, 'Seth Mercado', 759442973, 27, 6564, 2006, 25);
insert into CLERK_TEMP (clerkid, clerkname, bossid, areaid, salary, hireyear, rating)
values (132751178, 'Maxwell Calderon', 513758036, 100, 4058, 2016, 86);
insert into CLERK_TEMP (clerkid, clerkname, bossid, areaid, salary, hireyear, rating)
values (459089952, 'Amelia Mills', 811969949, 98, 4276, 2014, 90);
insert into CLERK_TEMP (clerkid, clerkname, bossid, areaid, salary, hireyear, rating)
values (352326915, 'Stacy Savage', 65786836, 28, 7722, 2011, 35);
insert into CLERK_TEMP (clerkid, clerkname, bossid, areaid, salary, hireyear, rating)
values (398251227, 'Lola Vaughan', 111324755, 47, 5795, 2011, 31);
insert into CLERK_TEMP (clerkid, clerkname, bossid, areaid, salary, hireyear, rating)
values (198620173, 'Autumn Oneal', 441864276, 33, 5570, 2007, 61);
insert into CLERK_TEMP (clerkid, clerkname, bossid, areaid, salary, hireyear, rating)
values (468433995, 'Jacquelyn Alvarez', 422387569, 30, 9366, 2010, 85);
insert into CLERK_TEMP (clerkid, clerkname, bossid, areaid, salary, hireyear, rating)
values (169418156, 'Maddison Francis', 920606814, 99, 4919, 2015, 42);
insert into CLERK_TEMP (clerkid, clerkname, bossid, areaid, salary, hireyear, rating)
values (48780608, 'Lukas Powers', 623443858, 15, 5001, 2016, 55);
insert into CLERK_TEMP (clerkid, clerkname, bossid, areaid, salary, hireyear, rating)
values (245602759, 'Landon Moody', 153201103, 63, 7808, 2008, 88);
insert into CLERK_TEMP (clerkid, clerkname, bossid, areaid, salary, hireyear, rating)
values (865215977, 'Judah Solis', 247598093, 46, 3237, 2014, 29);
insert into CLERK_TEMP (clerkid, clerkname, bossid, areaid, salary, hireyear, rating)
values (613154169, 'Carina Todd', 487998812, 37, 3505, 2009, 75);
insert into CLERK_TEMP (clerkid, clerkname, bossid, areaid, salary, hireyear, rating)
values (710604897, 'Trinity Cochran', 969419112, 40, 8100, 2007, 74);
insert into CLERK_TEMP (clerkid, clerkname, bossid, areaid, salary, hireyear, rating)
values (903631899, 'Terrence Owens', 764532349, 77, 3065, 2008, 79);
insert into CLERK_TEMP (clerkid, clerkname, bossid, areaid, salary, hireyear, rating)
values (163989772, 'Clinton Ochoa', 162100909, 95, 9168, 2007, 97);
insert into CLERK_TEMP (clerkid, clerkname, bossid, areaid, salary, hireyear, rating)
values (424689583, 'Jaylee Carpenter', 963939156, 3, 7690, 2012, 88);
insert into CLERK_TEMP (clerkid, clerkname, bossid, areaid, salary, hireyear, rating)
values (251645553, 'Kyan Fuentes', 848997346, 94, 9457, 2016, 48);
insert into CLERK_TEMP (clerkid, clerkname, bossid, areaid, salary, hireyear, rating)
values (520881414, 'Brodie Murphy', 596236364, 61, 6804, 2020, 85);
insert into CLERK_TEMP (clerkid, clerkname, bossid, areaid, salary, hireyear, rating)
values (740053775, 'Mike Pham', 376869355, 59, 5188, 2015, 58);
insert into CLERK_TEMP (clerkid, clerkname, bossid, areaid, salary, hireyear, rating)
values (970992503, 'Iliana Zuniga', 932521110, 44, 5899, 2006, 56);
insert into CLERK_TEMP (clerkid, clerkname, bossid, areaid, salary, hireyear, rating)
values (552470268, 'Maverick Klein', 168148868, 53, 5387, 2018, 89);
insert into CLERK_TEMP (clerkid, clerkname, bossid, areaid, salary, hireyear, rating)
values (283304585, 'Brianna Munoz', 467598885, 72, 4620, 2011, 42);
insert into CLERK_TEMP (clerkid, clerkname, bossid, areaid, salary, hireyear, rating)
values (315265026, 'Aryana Mcintyre', 964843484, 64, 8858, 2007, 92);
insert into CLERK_TEMP (clerkid, clerkname, bossid, areaid, salary, hireyear, rating)
values (83705991, 'Kira Pope', 812109096, 18, 4153, 2008, 62);
insert into CLERK_TEMP (clerkid, clerkname, bossid, areaid, salary, hireyear, rating)
values (632486887, 'Mathew Schneider', 484427206, 91, 6570, 2011, 37);
insert into CLERK_TEMP (clerkid, clerkname, bossid, areaid, salary, hireyear, rating)
values (1, 'Emily Farrow', 20006, 21, 7293, 2008, 6);
insert into CLERK_TEMP (clerkid, clerkname, bossid, areaid, salary, hireyear, rating)
values (2, 'Arnold Singletary', 20009, 22, 7866, 2018, 6);
insert into CLERK_TEMP (clerkid, clerkname, bossid, areaid, salary, hireyear, rating)
values (3, 'Rose Mraz', 20001, 23, 11702, 2008, 6);
insert into CLERK_TEMP (clerkid, clerkname, bossid, areaid, salary, hireyear, rating)
values (4, 'Melanie Michael', 20001, 24, 9295, 2018, 10);
insert into CLERK_TEMP (clerkid, clerkname, bossid, areaid, salary, hireyear, rating)
values (5, 'Bobbi Loveless', 20001, 25, 10445, 2011, 6);
insert into CLERK_TEMP (clerkid, clerkname, bossid, areaid, salary, hireyear, rating)
values (6, 'Ernie Parm', 20004, 26, 7531, 2012, 4);
insert into CLERK_TEMP (clerkid, clerkname, bossid, areaid, salary, hireyear, rating)
values (7, 'Spike Stiles', 20008, 27, 8295, 2018, 7);
insert into CLERK_TEMP (clerkid, clerkname, bossid, areaid, salary, hireyear, rating)
values (8, 'Danni Santana', 20003, 28, 5737, 2012, 4);
insert into CLERK_TEMP (clerkid, clerkname, bossid, areaid, salary, hireyear, rating)
values (9, 'Billy Schwimmer', 20005, 29, 9848, 2011, 5);
insert into CLERK_TEMP (clerkid, clerkname, bossid, areaid, salary, hireyear, rating)
values (10, 'Daryle Downie', 20010, 30, 5766, 2015, 4);
insert into CLERK_TEMP (clerkid, clerkname, bossid, areaid, salary, hireyear, rating)
values (985608353, 'Aaron Robbins', 728586501, 65, 6259, 2019, 76);
insert into CLERK_TEMP (clerkid, clerkname, bossid, areaid, salary, hireyear, rating)
values (216673752, 'Regina Hicks', 611912795, 11, 3588, 2010, 60);
insert into CLERK_TEMP (clerkid, clerkname, bossid, areaid, salary, hireyear, rating)
values (616839114, 'Vivian Rhodes', 82463116, 90, 3575, 2015, 84);
insert into CLERK_TEMP (clerkid, clerkname, bossid, areaid, salary, hireyear, rating)
values (56423791, 'Vicente Robles', 13621976, 70, 6554, 2008, 30);
insert into CLERK_TEMP (clerkid, clerkname, bossid, areaid, salary, hireyear, rating)
values (715357972, 'Riley Vang', 178536762, 62, 7322, 2012, 32);
insert into CLERK_TEMP (clerkid, clerkname, bossid, areaid, salary, hireyear, rating)
values (769944696, 'Ashton Maldonado', 835856510, 41, 5472, 2011, 57);
insert into CLERK_TEMP (clerkid, clerkname, bossid, areaid, salary, hireyear, rating)
values (106947896, 'Erin Raymond', 951674376, 14, 6255, 2014, 33);
insert into CLERK_TEMP (clerkid, clerkname, bossid, areaid, salary, hireyear, rating)
values (701642916, 'Emma Terrell', 192952482, 66, 4323, 2007, 35);
insert into CLERK_TEMP (clerkid, clerkname, bossid, areaid, salary, hireyear, rating)
values (230298738, 'Mallory Burnett', 747768908, 21, 8522, 2006, 74);
insert into CLERK_TEMP (clerkid, clerkname, bossid, areaid, salary, hireyear, rating)
values (536047901, 'Alice Rojas', 359153629, 52, 4907, 2007, 55);
insert into CLERK_TEMP (clerkid, clerkname, bossid, areaid, salary, hireyear, rating)
values (688678649, 'Daniela Bradshaw', 754058532, 1, 8450, 2011, 60);
insert into CLERK_TEMP (clerkid, clerkname, bossid, areaid, salary, hireyear, rating)
values (45172409, 'Carlos Crane', 116713838, 20, 8161, 2013, 70);
insert into CLERK_TEMP (clerkid, clerkname, bossid, areaid, salary, hireyear, rating)
values (261999697, 'Marisa Blackburn', 351427476, 73, 3376, 2018, 29);
insert into CLERK_TEMP (clerkid, clerkname, bossid, areaid, salary, hireyear, rating)
values (533844976, 'Lacey Wright', 871371068, 93, 5303, 2008, 52);
insert into CLERK_TEMP (clerkid, clerkname, bossid, areaid, salary, hireyear, rating)
values (439153011, 'Aliana Munoz', 636986649, 82, 3182, 2014, 76);
insert into CLERK_TEMP (clerkid, clerkname, bossid, areaid, salary, hireyear, rating)
values (742868808, 'Juliet Day', 644517151, 84, 6253, 2017, 33);
insert into CLERK_TEMP (clerkid, clerkname, bossid, areaid, salary, hireyear, rating)
values (89160074, 'Isabell Brock', 129040934, 32, 8855, 2015, 45);
insert into CLERK_TEMP (clerkid, clerkname, bossid, areaid, salary, hireyear, rating)
values (908621892, 'Janiya James', 338392591, 89, 7171, 2011, 80);
insert into CLERK_TEMP (clerkid, clerkname, bossid, areaid, salary, hireyear, rating)
values (727320134, 'Brittany Nielsen', 730255019, 60, 4750, 2010, 42);
insert into CLERK_TEMP (clerkid, clerkname, bossid, areaid, salary, hireyear, rating)
values (889893500, 'Dustin Terrell', 169525232, 87, 4145, 2019, 60);
insert into CLERK_TEMP (clerkid, clerkname, bossid, areaid, salary, hireyear, rating)
values (97748603, 'Yasmin Steele', 503531033, 16, 5199, 2017, 86);
insert into CLERK_TEMP (clerkid, clerkname, bossid, areaid, salary, hireyear, rating)
values (621893021, 'Jacey Stephens', 536832758, 7, 8996, 2020, 70);
insert into CLERK_TEMP (clerkid, clerkname, bossid, areaid, salary, hireyear, rating)
values (50870763, 'Judith Kramer', 881497689, 5, 4197, 2014, 77);
insert into CLERK_TEMP (clerkid, clerkname, bossid, areaid, salary, hireyear, rating)
values (231962714, 'Aliana Warren', 888871238, 23, 7656, 2016, 48);
insert into CLERK_TEMP (clerkid, clerkname, bossid, areaid, salary, hireyear, rating)
values (3266076, 'Jerimiah Richardson', 288561006, 58, 4629, 2017, 36);
insert into CLERK_TEMP (clerkid, clerkname, bossid, areaid, salary, hireyear, rating)
values (242059824, 'Kimora Bruce', 653257004, 10, 9931, 2006, 30);
insert into CLERK_TEMP (clerkid, clerkname, bossid, areaid, salary, hireyear, rating)
values (986515397, 'Matilda Mills', 561974294, 51, 3060, 2016, 90);
insert into CLERK_TEMP (clerkid, clerkname, bossid, areaid, salary, hireyear, rating)
values (640574572, 'Jon Hanna', 683069173, 56, 5642, 2014, 69);
insert into CLERK_TEMP (clerkid, clerkname, bossid, areaid, salary, hireyear, rating)
values (381434132, 'Jadiel Nichols', 632061896, 43, 8346, 2011, 84);
insert into CLERK_TEMP (clerkid, clerkname, bossid, areaid, salary, hireyear, rating)
values (58713028, 'Aliza Johnston', 282805064, 8, 5877, 2011, 76);
insert into CLERK_TEMP (clerkid, clerkname, bossid, areaid, salary, hireyear, rating)
values (413518592, 'Kymani Atkins', 210526370, 9, 3139, 2007, 64);
insert into CLERK_TEMP (clerkid, clerkname, bossid, areaid, salary, hireyear, rating)
values (89541503, 'Jayda Booker', 35100364, 85, 9279, 2010, 72);
insert into CLERK_TEMP (clerkid, clerkname, bossid, areaid, salary, hireyear, rating)
values (675975458, 'Jamiya Cox', 386211345, 38, 6900, 2015, 72);
insert into CLERK_TEMP (clerkid, clerkname, bossid, areaid, salary, hireyear, rating)
values (953496147, 'Jonah Mckay', 53215943, 76, 8060, 2016, 39);
insert into CLERK_TEMP (clerkid, clerkname, bossid, areaid, salary, hireyear, rating)
values (763143179, 'Campbell Manning', 571651713, 79, 7809, 2008, 43);
insert into CLERK_TEMP (clerkid, clerkname, bossid, areaid, salary, hireyear, rating)
values (640330926, 'Ivy Sutton', 887279443, 49, 7253, 2014, 95);
insert into CLERK_TEMP (clerkid, clerkname, bossid, areaid, salary, hireyear, rating)
values (219641402, 'Zaniyah Dominguez', 348994280, 55, 9481, 2009, 36);
insert into CLERK_TEMP (clerkid, clerkname, bossid, areaid, salary, hireyear, rating)
values (797503856, 'Fernanda Stanton', 596091330, 57, 6734, 2007, 99);
insert into CLERK_TEMP (clerkid, clerkname, bossid, areaid, salary, hireyear, rating)
values (714723836, 'Maddison Bright', 654058322, 2, 7181, 2008, 77);
insert into CLERK_TEMP (clerkid, clerkname, bossid, areaid, salary, hireyear, rating)
values (962919031, 'Annie Lozano', 467458799, 83, 6323, 2007, 42);
insert into CLERK_TEMP (clerkid, clerkname, bossid, areaid, salary, hireyear, rating)
values (804709291, 'Dominique Pollard', 482185653, 75, 8052, 2012, 97);
insert into CLERK_TEMP (clerkid, clerkname, bossid, areaid, salary, hireyear, rating)
values (177769483, 'Brynlee Whitaker', 679505128, 54, 9664, 2016, 69);
insert into CLERK_TEMP (clerkid, clerkname, bossid, areaid, salary, hireyear, rating)
values (901257019, 'Aedan Ramos', 189682273, 69, 6748, 2020, 86);
insert into CLERK_TEMP (clerkid, clerkname, bossid, areaid, salary, hireyear, rating)
values (857760109, 'Kiley Gillespie', 747715581, 48, 3646, 2015, 81);
insert into CLERK_TEMP (clerkid, clerkname, bossid, areaid, salary, hireyear, rating)
values (744958679, 'Maxwell Huffman', 290166400, 50, 8599, 2006, 36);
insert into CLERK_TEMP (clerkid, clerkname, bossid, areaid, salary, hireyear, rating)
values (563871338, 'Sidney Mcdowell', 815005240, 81, 9063, 2018, 47);
insert into CLERK_TEMP (clerkid, clerkname, bossid, areaid, salary, hireyear, rating)
values (566015263, 'Abraham Waller', 853047389, 68, 6153, 2011, 83);
insert into CLERK_TEMP (clerkid, clerkname, bossid, areaid, salary, hireyear, rating)
values (278216922, 'Jonas Ayala', 975381784, 71, 5014, 2007, 96);
insert into CLERK_TEMP (clerkid, clerkname, bossid, areaid, salary, hireyear, rating)
values (479478250, 'Yoselin Allen', 7375540, 96, 3072, 2008, 40);
insert into CLERK_TEMP (clerkid, clerkname, bossid, areaid, salary, hireyear, rating)
values (340526675, 'Darius Dunn', 866019935, 6, 8808, 2011, 64);
insert into CLERK_TEMP (clerkid, clerkname, bossid, areaid, salary, hireyear, rating)
values (578494275, 'Osvaldo Sparks', 253823707, 97, 6361, 2019, 65);
insert into CLERK_TEMP (clerkid, clerkname, bossid, areaid, salary, hireyear, rating)
values (470721569, 'Adrianna Norman', 578436469, 86, 6112, 2010, 27);
insert into CLERK_TEMP (clerkid, clerkname, bossid, areaid, salary, hireyear, rating)
values (625260228, 'Celia Cowan', 63966459, 25, 5552, 2015, 80);
insert into CLERK_TEMP (clerkid, clerkname, bossid, areaid, salary, hireyear, rating)
values (602574296, 'Kyra Howell', 775632110, 22, 8881, 2008, 77);
insert into CLERK_TEMP (clerkid, clerkname, bossid, areaid, salary, hireyear, rating)
values (141169429, 'Aden Nash', 849549339, 78, 8108, 2012, 55);
insert into CLERK_TEMP (clerkid, clerkname, bossid, areaid, salary, hireyear, rating)
values (657042160, 'Haven Dominguez', 595482475, 26, 8155, 2011, 96);
insert into CLERK_TEMP (clerkid, clerkname, bossid, areaid, salary, hireyear, rating)
values (111959269, 'Micah Singh', 196953292, 31, 3323, 2014, 41);
insert into CLERK_TEMP (clerkid, clerkname, bossid, areaid, salary, hireyear, rating)
values (116034120, 'Mariah Hampton', 655805639, 88, 5681, 2007, 77);
insert into CLERK_TEMP (clerkid, clerkname, bossid, areaid, salary, hireyear, rating)
values (568167932, 'Jeremy Lutz', 577025006, 29, 5638, 2006, 81);
insert into CLERK_TEMP (clerkid, clerkname, bossid, areaid, salary, hireyear, rating)
values (775027789, 'Jaxson Robertson', 675210639, 45, 7284, 2007, 74);
insert into CLERK_TEMP (clerkid, clerkname, bossid, areaid, salary, hireyear, rating)
values (533397741, 'Marquise Horne', 919044101, 36, 6241, 2011, 64);
insert into CLERK_TEMP (clerkid, clerkname, bossid, areaid, salary, hireyear, rating)
values (462438254, 'Autumn Joseph', 462929801, 19, 6205, 2013, 93);
insert into CLERK_TEMP (clerkid, clerkname, bossid, areaid, salary, hireyear, rating)
values (412908680, 'Melina Morales', 150609347, 12, 9603, 2018, 66);
insert into CLERK_TEMP (clerkid, clerkname, bossid, areaid, salary, hireyear, rating)
values (999775205, 'Jaelyn Baxter', 510596727, 35, 8121, 2008, 59);
insert into CLERK_TEMP (clerkid, clerkname, bossid, areaid, salary, hireyear, rating)
values (377845907, 'Luz Mcintyre', 71840651, 4, 3885, 2014, 40);
insert into CLERK_TEMP (clerkid, clerkname, bossid, areaid, salary, hireyear, rating)
values (358888404, 'Rigoberto Stafford', 544243390, 39, 8564, 2017, 42);
insert into CLERK_TEMP (clerkid, clerkname, bossid, areaid, salary, hireyear, rating)
values (508028509, 'Lila Shields', 962334883, 17, 8019, 2015, 43);
insert into CLERK_TEMP (clerkid, clerkname, bossid, areaid, salary, hireyear, rating)
values (935116002, 'Brooke Mayo', 248278494, 74, 6271, 2011, 90);
insert into CLERK_TEMP (clerkid, clerkname, bossid, areaid, salary, hireyear, rating)
values (826448233, 'Karly Cooke', 332180403, 67, 5020, 2010, 45);
insert into CLERK_TEMP (clerkid, clerkname, bossid, areaid, salary, hireyear, rating)
values (62588564, 'Joanna Nichols', 861989291, 34, 9752, 2019, 46);
insert into CLERK_TEMP (clerkid, clerkname, bossid, areaid, salary, hireyear, rating)
values (37773505, 'Elizabeth Booth', 340695319, 80, 5345, 2017, 60);
insert into CLERK_TEMP (clerkid, clerkname, bossid, areaid, salary, hireyear, rating)
values (224334980, 'John Mcmahon', 412463694, 13, 4504, 2020, 84);
insert into CLERK_TEMP (clerkid, clerkname, bossid, areaid, salary, hireyear, rating)
values (725061585, 'Roman Martin', 520949281, 42, 8672, 2014, 62);
insert into CLERK_TEMP (clerkid, clerkname, bossid, areaid, salary, hireyear, rating)
values (380575697, 'Dakota Lindsey', 297954194, 24, 5738, 2016, 49);
insert into CLERK_TEMP (clerkid, clerkname, bossid, areaid, salary, hireyear, rating)
values (443090391, 'Donald Romero', 588792612, 92, 9339, 2017, 39);
insert into CLERK_TEMP (clerkid, clerkname, bossid, areaid, salary, hireyear, rating)
values (102056465, 'Seth Mercado', 759442973, 27, 6564, 2006, 25);
insert into CLERK_TEMP (clerkid, clerkname, bossid, areaid, salary, hireyear, rating)
values (132751178, 'Maxwell Calderon', 513758036, 100, 4058, 2016, 86);
insert into CLERK_TEMP (clerkid, clerkname, bossid, areaid, salary, hireyear, rating)
values (459089952, 'Amelia Mills', 811969949, 98, 4276, 2014, 90);
insert into CLERK_TEMP (clerkid, clerkname, bossid, areaid, salary, hireyear, rating)
values (352326915, 'Stacy Savage', 65786836, 28, 7722, 2011, 35);
insert into CLERK_TEMP (clerkid, clerkname, bossid, areaid, salary, hireyear, rating)
values (398251227, 'Lola Vaughan', 111324755, 47, 5795, 2011, 31);
insert into CLERK_TEMP (clerkid, clerkname, bossid, areaid, salary, hireyear, rating)
values (198620173, 'Autumn Oneal', 441864276, 33, 5570, 2007, 61);
insert into CLERK_TEMP (clerkid, clerkname, bossid, areaid, salary, hireyear, rating)
values (468433995, 'Jacquelyn Alvarez', 422387569, 30, 9366, 2010, 85);
insert into CLERK_TEMP (clerkid, clerkname, bossid, areaid, salary, hireyear, rating)
values (169418156, 'Maddison Francis', 920606814, 99, 4919, 2015, 42);
insert into CLERK_TEMP (clerkid, clerkname, bossid, areaid, salary, hireyear, rating)
values (48780608, 'Lukas Powers', 623443858, 15, 5001, 2016, 55);
insert into CLERK_TEMP (clerkid, clerkname, bossid, areaid, salary, hireyear, rating)
values (245602759, 'Landon Moody', 153201103, 63, 7808, 2008, 88);
insert into CLERK_TEMP (clerkid, clerkname, bossid, areaid, salary, hireyear, rating)
values (865215977, 'Judah Solis', 247598093, 46, 3237, 2014, 29);
insert into CLERK_TEMP (clerkid, clerkname, bossid, areaid, salary, hireyear, rating)
values (613154169, 'Carina Todd', 487998812, 37, 3505, 2009, 75);
insert into CLERK_TEMP (clerkid, clerkname, bossid, areaid, salary, hireyear, rating)
values (710604897, 'Trinity Cochran', 969419112, 40, 8100, 2007, 74);
insert into CLERK_TEMP (clerkid, clerkname, bossid, areaid, salary, hireyear, rating)
values (903631899, 'Terrence Owens', 764532349, 77, 3065, 2008, 79);
insert into CLERK_TEMP (clerkid, clerkname, bossid, areaid, salary, hireyear, rating)
values (163989772, 'Clinton Ochoa', 162100909, 95, 9168, 2007, 97);
insert into CLERK_TEMP (clerkid, clerkname, bossid, areaid, salary, hireyear, rating)
values (424689583, 'Jaylee Carpenter', 963939156, 3, 7690, 2012, 88);
insert into CLERK_TEMP (clerkid, clerkname, bossid, areaid, salary, hireyear, rating)
values (251645553, 'Kyan Fuentes', 848997346, 94, 9457, 2016, 48);
insert into CLERK_TEMP (clerkid, clerkname, bossid, areaid, salary, hireyear, rating)
values (520881414, 'Brodie Murphy', 596236364, 61, 6804, 2020, 85);
insert into CLERK_TEMP (clerkid, clerkname, bossid, areaid, salary, hireyear, rating)
values (740053775, 'Mike Pham', 376869355, 59, 5188, 2015, 58);
insert into CLERK_TEMP (clerkid, clerkname, bossid, areaid, salary, hireyear, rating)
values (970992503, 'Iliana Zuniga', 932521110, 44, 5899, 2006, 56);
insert into CLERK_TEMP (clerkid, clerkname, bossid, areaid, salary, hireyear, rating)
values (552470268, 'Maverick Klein', 168148868, 53, 5387, 2018, 89);
insert into CLERK_TEMP (clerkid, clerkname, bossid, areaid, salary, hireyear, rating)
values (283304585, 'Brianna Munoz', 467598885, 72, 4620, 2011, 42);
insert into CLERK_TEMP (clerkid, clerkname, bossid, areaid, salary, hireyear, rating)
values (315265026, 'Aryana Mcintyre', 964843484, 64, 8858, 2007, 92);
insert into CLERK_TEMP (clerkid, clerkname, bossid, areaid, salary, hireyear, rating)
values (83705991, 'Kira Pope', 812109096, 18, 4153, 2008, 62);
insert into CLERK_TEMP (clerkid, clerkname, bossid, areaid, salary, hireyear, rating)
values (632486887, 'Mathew Schneider', 484427206, 91, 6570, 2011, 37);
insert into CLERK_TEMP (clerkid, clerkname, bossid, areaid, salary, hireyear, rating)
values (985608353, 'Aaron Robbins', 728586501, 65, 6259, 2019, 76);
insert into CLERK_TEMP (clerkid, clerkname, bossid, areaid, salary, hireyear, rating)
values (216673752, 'Regina Hicks', 611912795, 11, 3588, 2010, 60);
insert into CLERK_TEMP (clerkid, clerkname, bossid, areaid, salary, hireyear, rating)
values (616839114, 'Vivian Rhodes', 82463116, 90, 3575, 2015, 84);
insert into CLERK_TEMP (clerkid, clerkname, bossid, areaid, salary, hireyear, rating)
values (56423791, 'Vicente Robles', 13621976, 70, 6554, 2008, 30);
insert into CLERK_TEMP (clerkid, clerkname, bossid, areaid, salary, hireyear, rating)
values (715357972, 'Riley Vang', 178536762, 62, 7322, 2012, 32);
insert into CLERK_TEMP (clerkid, clerkname, bossid, areaid, salary, hireyear, rating)
values (769944696, 'Ashton Maldonado', 835856510, 41, 5472, 2011, 57);
insert into CLERK_TEMP (clerkid, clerkname, bossid, areaid, salary, hireyear, rating)
values (106947896, 'Erin Raymond', 951674376, 14, 6255, 2014, 33);
insert into CLERK_TEMP (clerkid, clerkname, bossid, areaid, salary, hireyear, rating)
values (701642916, 'Emma Terrell', 192952482, 66, 4323, 2007, 35);
insert into CLERK_TEMP (clerkid, clerkname, bossid, areaid, salary, hireyear, rating)
values (230298738, 'Mallory Burnett', 747768908, 21, 8522, 2006, 74);
insert into CLERK_TEMP (clerkid, clerkname, bossid, areaid, salary, hireyear, rating)
values (536047901, 'Alice Rojas', 359153629, 52, 4907, 2007, 55);
insert into CLERK_TEMP (clerkid, clerkname, bossid, areaid, salary, hireyear, rating)
values (688678649, 'Daniela Bradshaw', 754058532, 1, 8450, 2011, 60);
insert into CLERK_TEMP (clerkid, clerkname, bossid, areaid, salary, hireyear, rating)
values (45172409, 'Carlos Crane', 116713838, 20, 8161, 2013, 70);
insert into CLERK_TEMP (clerkid, clerkname, bossid, areaid, salary, hireyear, rating)
values (261999697, 'Marisa Blackburn', 351427476, 73, 3376, 2018, 29);
insert into CLERK_TEMP (clerkid, clerkname, bossid, areaid, salary, hireyear, rating)
values (533844976, 'Lacey Wright', 871371068, 93, 5303, 2008, 52);
insert into CLERK_TEMP (clerkid, clerkname, bossid, areaid, salary, hireyear, rating)
values (439153011, 'Aliana Munoz', 636986649, 82, 3182, 2014, 76);
insert into CLERK_TEMP (clerkid, clerkname, bossid, areaid, salary, hireyear, rating)
values (742868808, 'Juliet Day', 644517151, 84, 6253, 2017, 33);
insert into CLERK_TEMP (clerkid, clerkname, bossid, areaid, salary, hireyear, rating)
values (89160074, 'Isabell Brock', 129040934, 32, 8855, 2015, 45);
insert into CLERK_TEMP (clerkid, clerkname, bossid, areaid, salary, hireyear, rating)
values (908621892, 'Janiya James', 338392591, 89, 7171, 2011, 80);
insert into CLERK_TEMP (clerkid, clerkname, bossid, areaid, salary, hireyear, rating)
values (727320134, 'Brittany Nielsen', 730255019, 60, 4750, 2010, 42);
insert into CLERK_TEMP (clerkid, clerkname, bossid, areaid, salary, hireyear, rating)
values (889893500, 'Dustin Terrell', 169525232, 87, 4145, 2019, 60);
insert into CLERK_TEMP (clerkid, clerkname, bossid, areaid, salary, hireyear, rating)
values (97748603, 'Yasmin Steele', 503531033, 16, 5199, 2017, 86);
insert into CLERK_TEMP (clerkid, clerkname, bossid, areaid, salary, hireyear, rating)
values (621893021, 'Jacey Stephens', 536832758, 7, 8996, 2020, 70);
insert into CLERK_TEMP (clerkid, clerkname, bossid, areaid, salary, hireyear, rating)
values (50870763, 'Judith Kramer', 881497689, 5, 4197, 2014, 77);
insert into CLERK_TEMP (clerkid, clerkname, bossid, areaid, salary, hireyear, rating)
values (231962714, 'Aliana Warren', 888871238, 23, 7656, 2016, 48);
insert into CLERK_TEMP (clerkid, clerkname, bossid, areaid, salary, hireyear, rating)
values (3266076, 'Jerimiah Richardson', 288561006, 58, 4629, 2017, 36);
insert into CLERK_TEMP (clerkid, clerkname, bossid, areaid, salary, hireyear, rating)
values (242059824, 'Kimora Bruce', 653257004, 10, 9931, 2006, 30);
insert into CLERK_TEMP (clerkid, clerkname, bossid, areaid, salary, hireyear, rating)
values (986515397, 'Matilda Mills', 561974294, 51, 3060, 2016, 90);
insert into CLERK_TEMP (clerkid, clerkname, bossid, areaid, salary, hireyear, rating)
values (640574572, 'Jon Hanna', 683069173, 56, 5642, 2014, 69);
insert into CLERK_TEMP (clerkid, clerkname, bossid, areaid, salary, hireyear, rating)
values (381434132, 'Jadiel Nichols', 632061896, 43, 8346, 2011, 84);
insert into CLERK_TEMP (clerkid, clerkname, bossid, areaid, salary, hireyear, rating)
values (58713028, 'Aliza Johnston', 282805064, 8, 5877, 2011, 76);
insert into CLERK_TEMP (clerkid, clerkname, bossid, areaid, salary, hireyear, rating)
values (413518592, 'Kymani Atkins', 210526370, 9, 3139, 2007, 64);
insert into CLERK_TEMP (clerkid, clerkname, bossid, areaid, salary, hireyear, rating)
values (89541503, 'Jayda Booker', 35100364, 85, 9279, 2010, 72);
insert into CLERK_TEMP (clerkid, clerkname, bossid, areaid, salary, hireyear, rating)
values (675975458, 'Jamiya Cox', 386211345, 38, 6900, 2015, 72);
insert into CLERK_TEMP (clerkid, clerkname, bossid, areaid, salary, hireyear, rating)
values (953496147, 'Jonah Mckay', 53215943, 76, 8060, 2016, 39);
insert into CLERK_TEMP (clerkid, clerkname, bossid, areaid, salary, hireyear, rating)
values (763143179, 'Campbell Manning', 571651713, 79, 7809, 2008, 43);
insert into CLERK_TEMP (clerkid, clerkname, bossid, areaid, salary, hireyear, rating)
values (640330926, 'Ivy Sutton', 887279443, 49, 7253, 2014, 95);
insert into CLERK_TEMP (clerkid, clerkname, bossid, areaid, salary, hireyear, rating)
values (219641402, 'Zaniyah Dominguez', 348994280, 55, 9481, 2009, 36);
insert into CLERK_TEMP (clerkid, clerkname, bossid, areaid, salary, hireyear, rating)
values (797503856, 'Fernanda Stanton', 596091330, 57, 6734, 2007, 99);
insert into CLERK_TEMP (clerkid, clerkname, bossid, areaid, salary, hireyear, rating)
values (714723836, 'Maddison Bright', 654058322, 2, 7181, 2008, 77);
insert into CLERK_TEMP (clerkid, clerkname, bossid, areaid, salary, hireyear, rating)
values (962919031, 'Annie Lozano', 467458799, 83, 6323, 2007, 42);
insert into CLERK_TEMP (clerkid, clerkname, bossid, areaid, salary, hireyear, rating)
values (804709291, 'Dominique Pollard', 482185653, 75, 8052, 2012, 97);
insert into CLERK_TEMP (clerkid, clerkname, bossid, areaid, salary, hireyear, rating)
values (177769483, 'Brynlee Whitaker', 679505128, 54, 9664, 2016, 69);
insert into CLERK_TEMP (clerkid, clerkname, bossid, areaid, salary, hireyear, rating)
values (901257019, 'Aedan Ramos', 189682273, 69, 6748, 2020, 86);
insert into CLERK_TEMP (clerkid, clerkname, bossid, areaid, salary, hireyear, rating)
values (857760109, 'Kiley Gillespie', 747715581, 48, 3646, 2015, 81);
insert into CLERK_TEMP (clerkid, clerkname, bossid, areaid, salary, hireyear, rating)
values (744958679, 'Maxwell Huffman', 290166400, 50, 8599, 2006, 36);
insert into CLERK_TEMP (clerkid, clerkname, bossid, areaid, salary, hireyear, rating)
values (563871338, 'Sidney Mcdowell', 815005240, 81, 9063, 2018, 47);
insert into CLERK_TEMP (clerkid, clerkname, bossid, areaid, salary, hireyear, rating)
values (566015263, 'Abraham Waller', 853047389, 68, 6153, 2011, 83);
insert into CLERK_TEMP (clerkid, clerkname, bossid, areaid, salary, hireyear, rating)
values (278216922, 'Jonas Ayala', 975381784, 71, 5014, 2007, 96);
insert into CLERK_TEMP (clerkid, clerkname, bossid, areaid, salary, hireyear, rating)
values (479478250, 'Yoselin Allen', 7375540, 96, 3072, 2008, 40);
insert into CLERK_TEMP (clerkid, clerkname, bossid, areaid, salary, hireyear, rating)
values (340526675, 'Darius Dunn', 866019935, 6, 8808, 2011, 64);
insert into CLERK_TEMP (clerkid, clerkname, bossid, areaid, salary, hireyear, rating)
values (578494275, 'Osvaldo Sparks', 253823707, 97, 6361, 2019, 65);
insert into CLERK_TEMP (clerkid, clerkname, bossid, areaid, salary, hireyear, rating)
values (470721569, 'Adrianna Norman', 578436469, 86, 6112, 2010, 27);
insert into CLERK_TEMP (clerkid, clerkname, bossid, areaid, salary, hireyear, rating)
values (625260228, 'Celia Cowan', 63966459, 25, 5552, 2015, 80);
insert into CLERK_TEMP (clerkid, clerkname, bossid, areaid, salary, hireyear, rating)
values (602574296, 'Kyra Howell', 775632110, 22, 8881, 2008, 77);
insert into CLERK_TEMP (clerkid, clerkname, bossid, areaid, salary, hireyear, rating)
values (141169429, 'Aden Nash', 849549339, 78, 8108, 2012, 55);
insert into CLERK_TEMP (clerkid, clerkname, bossid, areaid, salary, hireyear, rating)
values (657042160, 'Haven Dominguez', 595482475, 26, 8155, 2011, 96);
insert into CLERK_TEMP (clerkid, clerkname, bossid, areaid, salary, hireyear, rating)
values (111959269, 'Micah Singh', 196953292, 31, 3323, 2014, 41);
insert into CLERK_TEMP (clerkid, clerkname, bossid, areaid, salary, hireyear, rating)
values (116034120, 'Mariah Hampton', 655805639, 88, 5681, 2007, 77);
insert into CLERK_TEMP (clerkid, clerkname, bossid, areaid, salary, hireyear, rating)
values (568167932, 'Jeremy Lutz', 577025006, 29, 5638, 2006, 81);
insert into CLERK_TEMP (clerkid, clerkname, bossid, areaid, salary, hireyear, rating)
values (775027789, 'Jaxson Robertson', 675210639, 45, 7284, 2007, 74);
insert into CLERK_TEMP (clerkid, clerkname, bossid, areaid, salary, hireyear, rating)
values (533397741, 'Marquise Horne', 919044101, 36, 6241, 2011, 64);
insert into CLERK_TEMP (clerkid, clerkname, bossid, areaid, salary, hireyear, rating)
values (462438254, 'Autumn Joseph', 462929801, 19, 6205, 2013, 93);
insert into CLERK_TEMP (clerkid, clerkname, bossid, areaid, salary, hireyear, rating)
values (412908680, 'Melina Morales', 150609347, 12, 9603, 2018, 66);
insert into CLERK_TEMP (clerkid, clerkname, bossid, areaid, salary, hireyear, rating)
values (999775205, 'Jaelyn Baxter', 510596727, 35, 8121, 2008, 59);
insert into CLERK_TEMP (clerkid, clerkname, bossid, areaid, salary, hireyear, rating)
values (377845907, 'Luz Mcintyre', 71840651, 4, 3885, 2014, 40);
insert into CLERK_TEMP (clerkid, clerkname, bossid, areaid, salary, hireyear, rating)
values (358888404, 'Rigoberto Stafford', 544243390, 39, 8564, 2017, 42);
insert into CLERK_TEMP (clerkid, clerkname, bossid, areaid, salary, hireyear, rating)
values (508028509, 'Lila Shields', 962334883, 17, 8019, 2015, 43);
insert into CLERK_TEMP (clerkid, clerkname, bossid, areaid, salary, hireyear, rating)
values (935116002, 'Brooke Mayo', 248278494, 74, 6271, 2011, 90);
insert into CLERK_TEMP (clerkid, clerkname, bossid, areaid, salary, hireyear, rating)
values (826448233, 'Karly Cooke', 332180403, 67, 5020, 2010, 45);
insert into CLERK_TEMP (clerkid, clerkname, bossid, areaid, salary, hireyear, rating)
values (62588564, 'Joanna Nichols', 861989291, 34, 9752, 2019, 46);
insert into CLERK_TEMP (clerkid, clerkname, bossid, areaid, salary, hireyear, rating)
values (37773505, 'Elizabeth Booth', 340695319, 80, 5345, 2017, 60);
insert into CLERK_TEMP (clerkid, clerkname, bossid, areaid, salary, hireyear, rating)
values (224334980, 'John Mcmahon', 412463694, 13, 4504, 2020, 84);
insert into CLERK_TEMP (clerkid, clerkname, bossid, areaid, salary, hireyear, rating)
values (725061585, 'Roman Martin', 520949281, 42, 8672, 2014, 62);
insert into CLERK_TEMP (clerkid, clerkname, bossid, areaid, salary, hireyear, rating)
values (380575697, 'Dakota Lindsey', 297954194, 24, 5738, 2016, 49);
insert into CLERK_TEMP (clerkid, clerkname, bossid, areaid, salary, hireyear, rating)
values (443090391, 'Donald Romero', 588792612, 92, 9339, 2017, 39);
insert into CLERK_TEMP (clerkid, clerkname, bossid, areaid, salary, hireyear, rating)
values (102056465, 'Seth Mercado', 759442973, 27, 6564, 2006, 25);
insert into CLERK_TEMP (clerkid, clerkname, bossid, areaid, salary, hireyear, rating)
values (132751178, 'Maxwell Calderon', 513758036, 100, 4058, 2016, 86);
insert into CLERK_TEMP (clerkid, clerkname, bossid, areaid, salary, hireyear, rating)
values (459089952, 'Amelia Mills', 811969949, 98, 4276, 2014, 90);
insert into CLERK_TEMP (clerkid, clerkname, bossid, areaid, salary, hireyear, rating)
values (352326915, 'Stacy Savage', 65786836, 28, 7722, 2011, 35);
insert into CLERK_TEMP (clerkid, clerkname, bossid, areaid, salary, hireyear, rating)
values (398251227, 'Lola Vaughan', 111324755, 47, 5795, 2011, 31);
insert into CLERK_TEMP (clerkid, clerkname, bossid, areaid, salary, hireyear, rating)
values (198620173, 'Autumn Oneal', 441864276, 33, 5570, 2007, 61);
insert into CLERK_TEMP (clerkid, clerkname, bossid, areaid, salary, hireyear, rating)
values (468433995, 'Jacquelyn Alvarez', 422387569, 30, 9366, 2010, 85);
insert into CLERK_TEMP (clerkid, clerkname, bossid, areaid, salary, hireyear, rating)
values (169418156, 'Maddison Francis', 920606814, 99, 4919, 2015, 42);
insert into CLERK_TEMP (clerkid, clerkname, bossid, areaid, salary, hireyear, rating)
values (48780608, 'Lukas Powers', 623443858, 15, 5001, 2016, 55);
insert into CLERK_TEMP (clerkid, clerkname, bossid, areaid, salary, hireyear, rating)
values (245602759, 'Landon Moody', 153201103, 63, 7808, 2008, 88);
insert into CLERK_TEMP (clerkid, clerkname, bossid, areaid, salary, hireyear, rating)
values (865215977, 'Judah Solis', 247598093, 46, 3237, 2014, 29);
insert into CLERK_TEMP (clerkid, clerkname, bossid, areaid, salary, hireyear, rating)
values (613154169, 'Carina Todd', 487998812, 37, 3505, 2009, 75);
insert into CLERK_TEMP (clerkid, clerkname, bossid, areaid, salary, hireyear, rating)
values (710604897, 'Trinity Cochran', 969419112, 40, 8100, 2007, 74);
insert into CLERK_TEMP (clerkid, clerkname, bossid, areaid, salary, hireyear, rating)
values (903631899, 'Terrence Owens', 764532349, 77, 3065, 2008, 79);
insert into CLERK_TEMP (clerkid, clerkname, bossid, areaid, salary, hireyear, rating)
values (163989772, 'Clinton Ochoa', 162100909, 95, 9168, 2007, 97);
insert into CLERK_TEMP (clerkid, clerkname, bossid, areaid, salary, hireyear, rating)
values (424689583, 'Jaylee Carpenter', 963939156, 3, 7690, 2012, 88);
insert into CLERK_TEMP (clerkid, clerkname, bossid, areaid, salary, hireyear, rating)
values (251645553, 'Kyan Fuentes', 848997346, 94, 9457, 2016, 48);
insert into CLERK_TEMP (clerkid, clerkname, bossid, areaid, salary, hireyear, rating)
values (520881414, 'Brodie Murphy', 596236364, 61, 6804, 2020, 85);
insert into CLERK_TEMP (clerkid, clerkname, bossid, areaid, salary, hireyear, rating)
values (740053775, 'Mike Pham', 376869355, 59, 5188, 2015, 58);
insert into CLERK_TEMP (clerkid, clerkname, bossid, areaid, salary, hireyear, rating)
values (970992503, 'Iliana Zuniga', 932521110, 44, 5899, 2006, 56);
insert into CLERK_TEMP (clerkid, clerkname, bossid, areaid, salary, hireyear, rating)
values (552470268, 'Maverick Klein', 168148868, 53, 5387, 2018, 89);
insert into CLERK_TEMP (clerkid, clerkname, bossid, areaid, salary, hireyear, rating)
values (283304585, 'Brianna Munoz', 467598885, 72, 4620, 2011, 42);
insert into CLERK_TEMP (clerkid, clerkname, bossid, areaid, salary, hireyear, rating)
values (315265026, 'Aryana Mcintyre', 964843484, 64, 8858, 2007, 92);
insert into CLERK_TEMP (clerkid, clerkname, bossid, areaid, salary, hireyear, rating)
values (83705991, 'Kira Pope', 812109096, 18, 4153, 2008, 62);
insert into CLERK_TEMP (clerkid, clerkname, bossid, areaid, salary, hireyear, rating)
values (632486887, 'Mathew Schneider', 484427206, 91, 6570, 2011, 37);
prompt 320 records loaded
prompt Enabling triggers for CLERK_TEMP...
alter table CLERK_TEMP enable all triggers;

set feedback on
set define on
prompt Done
