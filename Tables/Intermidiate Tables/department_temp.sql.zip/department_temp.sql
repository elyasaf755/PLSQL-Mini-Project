?��prompt PL/SQL Developer Export Tables for user SYSTEM
prompt Created by Evyatar on יום שני 10 אוגוסט 2020
set feedback off
set define off

prompt Creating DEPARTMENT_TEMP...
create table DEPARTMENT_TEMP
(
  depid        INTEGER not null,
  numberofbeds NUMBER(4) not null,
  depname      VARCHAR2(50) not null,
  healthinstid NUMBER(3) not null,
  cityid       INTEGER
)
tablespace SYSTEM
  pctfree 10
  pctused 40
  initrans 1
  maxtrans 255
  storage
  (
    initial 64K
    next 1M
    minextents 1
    maxextents unlimited
  );
alter table DEPARTMENT_TEMP
  add primary key (DEPID, HEALTHINSTID)
  using index 
  tablespace SYSTEM
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 64K
    next 1M
    minextents 1
    maxextents unlimited
  );

prompt Disabling triggers for DEPARTMENT_TEMP...
alter table DEPARTMENT_TEMP disable all triggers;
prompt Deleting DEPARTMENT_TEMP...
delete from DEPARTMENT_TEMP;
prompt Loading DEPARTMENT_TEMP...
insert into DEPARTMENT_TEMP (depid, numberofbeds, depname, healthinstid, cityid)
values (321, 32, 'Social Work', 121, 7);
insert into DEPARTMENT_TEMP (depid, numberofbeds, depname, healthinstid, cityid)
values (579, 46, 'Maternity', 319, 12);
insert into DEPARTMENT_TEMP (depid, numberofbeds, depname, healthinstid, cityid)
values (431, 50, 'Pharmacy', 360, 7);
insert into DEPARTMENT_TEMP (depid, numberofbeds, depname, healthinstid, cityid)
values (693, 31, 'Radiotherapy', 861, 3);
insert into DEPARTMENT_TEMP (depid, numberofbeds, depname, healthinstid, cityid)
values (250, 41, 'Rheumatology', 435, 17);
insert into DEPARTMENT_TEMP (depid, numberofbeds, depname, healthinstid, cityid)
values (40, 34, 'Urology', 423, 7);
insert into DEPARTMENT_TEMP (depid, numberofbeds, depname, healthinstid, cityid)
values (425, 28, 'Breast Screening', 42, 19);
insert into DEPARTMENT_TEMP (depid, numberofbeds, depname, healthinstid, cityid)
values (61, 41, 'Elderly services', 503, 6);
insert into DEPARTMENT_TEMP (depid, numberofbeds, depname, healthinstid, cityid)
values (647, 33, 'Obstetrics/Gynecology', 860, 4);
insert into DEPARTMENT_TEMP (depid, numberofbeds, depname, healthinstid, cityid)
values (219, 38, 'Ophthalmology', 331, 14);
insert into DEPARTMENT_TEMP (depid, numberofbeds, depname, healthinstid, cityid)
values (669, 47, 'Patient Accounts', 996, 16);
insert into DEPARTMENT_TEMP (depid, numberofbeds, depname, healthinstid, cityid)
values (483, 25, 'Obstetrics/Gynecology', 408, 8);
insert into DEPARTMENT_TEMP (depid, numberofbeds, depname, healthinstid, cityid)
values (67, 27, 'Rheumatology', 503, 8);
insert into DEPARTMENT_TEMP (depid, numberofbeds, depname, healthinstid, cityid)
values (905, 47, 'Admissions', 431, 15);
insert into DEPARTMENT_TEMP (depid, numberofbeds, depname, healthinstid, cityid)
values (440, 38, 'Occupational Therapy', 713, 9);
insert into DEPARTMENT_TEMP (depid, numberofbeds, depname, healthinstid, cityid)
values (359, 47, 'Human Resources', 34, 18);
insert into DEPARTMENT_TEMP (depid, numberofbeds, depname, healthinstid, cityid)
values (103, 30, 'Coronary Care Unit', 883, 1);
insert into DEPARTMENT_TEMP (depid, numberofbeds, depname, healthinstid, cityid)
values (25, 29, 'Obstetrics/Gynecology', 931, 15);
insert into DEPARTMENT_TEMP (depid, numberofbeds, depname, healthinstid, cityid)
values (101, 24, 'Rheumatology', 942, 15);
insert into DEPARTMENT_TEMP (depid, numberofbeds, depname, healthinstid, cityid)
values (73, 39, 'Cardiology', 431, 20);
insert into DEPARTMENT_TEMP (depid, numberofbeds, depname, healthinstid, cityid)
values (546, 32, 'Human Resources', 865, 19);
insert into DEPARTMENT_TEMP (depid, numberofbeds, depname, healthinstid, cityid)
values (790, 57, 'Infection Control', 501, 2);
insert into DEPARTMENT_TEMP (depid, numberofbeds, depname, healthinstid, cityid)
values (771, 40, 'Occupational Therapy', 883, 20);
insert into DEPARTMENT_TEMP (depid, numberofbeds, depname, healthinstid, cityid)
values (96, 58, 'CSSD', 170, 9);
insert into DEPARTMENT_TEMP (depid, numberofbeds, depname, healthinstid, cityid)
values (597, 35, 'Rheumatology', 996, 2);
insert into DEPARTMENT_TEMP (depid, numberofbeds, depname, healthinstid, cityid)
values (175, 38, 'Diagnostic Imaging', 427, 17);
insert into DEPARTMENT_TEMP (depid, numberofbeds, depname, healthinstid, cityid)
values (772, 20, 'Medical Records', 74, 12);
insert into DEPARTMENT_TEMP (depid, numberofbeds, depname, healthinstid, cityid)
values (40, 55, 'Otolaryngology', 632, 7);
insert into DEPARTMENT_TEMP (depid, numberofbeds, depname, healthinstid, cityid)
values (654, 54, 'Pharmacy', 340, 3);
insert into DEPARTMENT_TEMP (depid, numberofbeds, depname, healthinstid, cityid)
values (110, 40, 'Breast Screening', 435, 4);
insert into DEPARTMENT_TEMP (depid, numberofbeds, depname, healthinstid, cityid)
values (562, 27, 'Renal', 170, 7);
insert into DEPARTMENT_TEMP (depid, numberofbeds, depname, healthinstid, cityid)
values (1, 42, 'Admissions', 435, 18);
insert into DEPARTMENT_TEMP (depid, numberofbeds, depname, healthinstid, cityid)
values (2, 39, 'Cardiology', 427, 8);
insert into DEPARTMENT_TEMP (depid, numberofbeds, depname, healthinstid, cityid)
values (3, 21, 'Pharmacy', 861, 20);
insert into DEPARTMENT_TEMP (depid, numberofbeds, depname, healthinstid, cityid)
values (4, 31, 'Nephrology', 726, 15);
insert into DEPARTMENT_TEMP (depid, numberofbeds, depname, healthinstid, cityid)
values (5, 44, 'Admissions', 758, 15);
insert into DEPARTMENT_TEMP (depid, numberofbeds, depname, healthinstid, cityid)
values (6, 33, 'Critical Care', 224, 19);
insert into DEPARTMENT_TEMP (depid, numberofbeds, depname, healthinstid, cityid)
values (7, 17, 'Human Resources', 42, 15);
insert into DEPARTMENT_TEMP (depid, numberofbeds, depname, healthinstid, cityid)
values (8, 24, 'Pharmacy', 116, 4);
insert into DEPARTMENT_TEMP (depid, numberofbeds, depname, healthinstid, cityid)
values (9, 27, 'General Surgery', 431, 15);
insert into DEPARTMENT_TEMP (depid, numberofbeds, depname, healthinstid, cityid)
values (10, 19, 'Pharmacy', 380, 6);
insert into DEPARTMENT_TEMP (depid, numberofbeds, depname, healthinstid, cityid)
values (11, 35, 'Oncology', 426, 2);
prompt 42 records loaded
prompt Enabling triggers for DEPARTMENT_TEMP...
alter table DEPARTMENT_TEMP enable all triggers;

set feedback on
set define on
prompt Done
